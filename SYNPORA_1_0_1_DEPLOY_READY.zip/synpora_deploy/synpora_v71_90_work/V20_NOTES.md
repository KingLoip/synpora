# v20 — Portfolio Optimization
Adds multi-farm portfolio snapshots and a simulation-only allocator for a portfolio power budget. No miner control commands are sent.
