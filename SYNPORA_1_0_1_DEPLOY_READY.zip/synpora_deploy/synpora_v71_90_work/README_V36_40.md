# SYNPORA v36–v40

The platform now extends from energy telemetry to a recommendation-grade AI decision layer:

v36 Energy Telemetry → v37 Battery Optimization → v38 Learning Feedback → v39 Profitability → v40 AI Decision.

All new control paths remain read-only/recommendation-only. No automatic inverter, battery, miner or GPU command is issued.

Main endpoints:
- POST/GET `/api/v1/farms/{farm_id}/energy/meter`
- GET `/api/v1/farms/{farm_id}/energy/live-state`
- POST `/api/v1/farms/{farm_id}/battery/optimize`
- POST/GET `/api/v1/farms/{farm_id}/learning/feedback` and `/learning/summary`
- GET `/api/v1/farms/{farm_id}/profitability`
- GET `/api/v1/farms/{farm_id}/ai/decision`
