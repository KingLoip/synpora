# SYNPORA v27.0 — Live Market Connected

## v25 Mining Forecast
- Live BTC price + network hashrate from Mempool.
- Live fee-inclusive hashprice from D-Central keyless API.
- 1–168h scenario forecast with explicit low/base/high assumptions.
- No invented live data.

## v26 AI/GPU Compute Market
- Live public GPU asking-price snapshot via GridCompute.
- GridCompute aggregates public Vast.ai listings and provider rate cards.
- Prices are asking/rate-card prices, not guaranteed realized revenue.
- Vast.ai direct authenticated API can be added later for account-specific offers.

## v27 Portfolio Allocator
- 24–168h energy allocation across BTC mining and AI compute.
- Uses live market anchors, electricity price, farm power limits and risk adjustment.
- Simulation only. Approval is required and no control commands are sent.

## Data sources
Mempool REST API: BTC price and network hashrate.
D-Central Bitcoin Mining API: live hashprice.
GridCompute GPU Price API: public GPU market/rate-card snapshot.
