# SYNPORA v33 — Realized Compute Revenue
- Added estimated vs realized compute revenue records.
- Gross revenue uses rate × utilization × uptime.
- Net revenue subtracts hosting, variable and energy costs.
- Revenue summary tracks realized-vs-booked ratio and utilization.
