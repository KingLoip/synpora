# SYNPORA v35 — Energy/Compute Control Center
- Aggregates optimizer, asset registry, telemetry freshness, compute revenue and data quality.
- Added `/api/v1/farms/{farm_id}/control-center` and `/summary`.
- UI/API remains read-only; control commands are explicitly disabled.
