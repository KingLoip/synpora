# v23 – AI/GPU Compute Revenue Engine
- Per-compute workload economics from configured power, gross revenue, availability and variable cost.
- Net €/h and €/kWh.
- Risk discount support.
- Uses verified configured workload economics; does not invent market revenue.
