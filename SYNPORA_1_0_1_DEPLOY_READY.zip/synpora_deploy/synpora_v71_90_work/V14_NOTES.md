# SYNPORA v14.0 — Learned Provider Ensemble

- Combines multiple stored forecast providers per hourly slot.
- Uses v13 learned provider weights, bias correction and confidence.
- Adds same-hour historical performance weighting (time-of-day adaptation).
- Penalizes disagreement between providers in ensemble confidence.
- Keeps graceful fallbacks for missing providers.
- Forecast-aware and probabilistic dispatch now consumes the ensemble through `_forecast_slots`.
- New API: `GET /api/v1/farms/{farm_id}/energy/forecast-ensemble?hours=168`.
- Miner control remains read-only.
