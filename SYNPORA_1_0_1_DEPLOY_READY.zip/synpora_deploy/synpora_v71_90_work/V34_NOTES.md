# SYNPORA v34 — Live Mining vs Compute Optimizer
- Combines mining economics, public GPU market economics and stored energy/PV forecast slots.
- Produces hourly recommendation with value €/kWh, expected margin, downside and confidence.
- Recommendation-only: approval required, no control commands.
