# SYNPORA v32 — GPU Telemetry
- Added compute telemetry table and ingestion API.
- Read-only NVIDIA `nvidia-smi` probe is optional via `SYNPORA_NVIDIA_TELEMETRY_ENABLED=true`.
- Generic HTTP/API telemetry can be posted to `/api/v1/farms/{farm_id}/compute/telemetry`.
- Freshness scoring added; no automatic hardware control.
