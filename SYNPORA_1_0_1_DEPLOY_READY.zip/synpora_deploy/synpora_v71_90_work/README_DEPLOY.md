# SYNPORA 1.0 — Deployment Ready

SYNPORA is a FastAPI + PostgreSQL-ready Energy & Compute Intelligence platform.

### Production architecture
Browser → FastAPI/Dashboard → PostgreSQL

The same service serves the dashboard and `/api` endpoints. Railway can build `backend/Dockerfile` directly from GitHub and provision PostgreSQL as a managed service.

See `RAILWAY_SETUP.md` for the non-technical setup steps.
