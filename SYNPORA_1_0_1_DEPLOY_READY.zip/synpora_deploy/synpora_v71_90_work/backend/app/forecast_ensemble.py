from datetime import datetime, timedelta, timezone
from statistics import pstdev
from sqlalchemy.orm import Session
from .models import EnergyForecastSlot, EnergyObservation, ForecastAccuracy, EnergyProfile
from .energy import current_energy_price
from .forecast_learning import provider_calibration
from .condition_learning import condition_calibration, season_for, condition_for


def _utc(dt):
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def _hour_profile(db: Session, farm_id: int, metric: str, provider: str, hour: int, lookback_days: int = 60):
    """Recent same-hour performance. This gives the ensemble a light time-of-day adaptation."""
    since = datetime.now(timezone.utc) - timedelta(days=lookback_days)
    fs = db.query(EnergyForecastSlot).filter(
        EnergyForecastSlot.farm_id == farm_id,
        EnergyForecastSlot.timestamp >= since,
        EnergyForecastSlot.provider == provider,
    ).all()
    obs = db.query(EnergyObservation).filter(
        EnergyObservation.farm_id == farm_id,
        EnergyObservation.timestamp >= since,
    ).all()
    by = {_utc(o.timestamp): o for o in obs}
    errors = []
    for f in fs:
        ts = _utc(f.timestamp)
        if ts.hour != hour:
            continue
        o = by.get(ts)
        if not o:
            continue
        actual = o.grid_price_eur_kwh if metric == 'price' else o.pv_kw
        pred = f.grid_price_eur_kwh if metric == 'price' else f.pv_kw
        if actual is None or pred is None:
            continue
        denom = max(abs(float(actual)), 0.0001)
        errors.append(abs(float(actual)-float(pred))/denom*100)
    if not errors:
        return {'samples': 0, 'mae_pct': None, 'weight_factor': 1.0, 'confidence_pct': None}
    mae = sum(errors)/len(errors)
    # Same-hour evidence is intentionally capped so it cannot overpower the global score.
    factor = max(0.35, min(1.65, 1/(1+mae/12)))
    factor = 0.55 + 0.45*factor if len(errors) < 12 else factor
    conf = max(10, min(99, 100-mae))
    return {'samples': len(errors), 'mae_pct': mae, 'weight_factor': factor, 'confidence_pct': conf}


def _metric_value(row, metric):
    return row.grid_price_eur_kwh if metric == 'price' else row.pv_kw


def _combine_metric(db, farm_id, timestamp, rows, metric):
    candidates=[]
    for r in rows:
        value=_metric_value(r, metric)
        if value is None:
            continue
        provider=r.provider or r.source or 'unknown'
        cal=provider_calibration(db, farm_id, metric, provider)
        hp=_hour_profile(db, farm_id, metric, provider, timestamp.hour)
        season=season_for(timestamp)
        cap=max([float(getattr(r,'pv_kw',0) or 0) for r in rows] + [0.0])
        cond=condition_for(getattr(r,'pv_kw',0) if metric=='pv' else 0, cap, timestamp.hour) if metric=='pv' else 'all'
        cc=condition_calibration(db,farm_id,metric,provider,season,cond) or condition_calibration(db,farm_id,metric,provider,'all','all')
        base=max(0.05, float(cal.get('weight') or 1.0))
        if cc: base*=max(0.35,min(1.65,float(cc.get('weight') or 1.0)))
        # Apply learned bias only after sufficient samples. Bias is signed actual-vs-forecast.
        corrected=float(value)
        if cal.get('samples',0) >= 8:
            corrected *= max(0.0, 1.0 + float(cal.get('bias_pct') or 0)/100.0)
        weight=base*float(hp['weight_factor'])
        confidence=min(float(r.confidence_pct or 70), float(cal.get('confidence_pct') or 70), float(hp.get('confidence_pct') or 99))
        candidates.append({'provider':provider,'value':corrected,'weight':weight,'confidence':confidence,'samples':cal.get('samples',0),'hour_samples':hp['samples']})
    if not candidates:
        return None
    total=sum(x['weight'] for x in candidates)
    value=sum(x['value']*x['weight'] for x in candidates)/max(total,0.0001)
    dispersion=0.0
    if len(candidates)>1:
        dispersion=(sum(x['weight']*(x['value']-value)**2 for x in candidates)/max(total,0.0001))**0.5
    conf=sum(x['confidence']*x['weight'] for x in candidates)/max(total,0.0001)
    # Agreement between providers is a confidence boost; disagreement is penalized.
    if candidates:
        scale=max(abs(value),0.0001)
        conf=max(10,min(99,conf - min(35, dispersion/scale*100)))
    return {'value': max(0.0,value) if metric in ('price','pv') else value,
            'providers':[x['provider'] for x in candidates], 'confidence':conf,
            'dispersion':dispersion,'weights':{x['provider']:round(x['weight'],4) for x in candidates}}


def ensemble_forecast(db: Session, farm, horizon: int = 168):
    horizon=max(1,min(int(horizon),168))
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    end=now+timedelta(hours=horizon)
    rows=db.query(EnergyForecastSlot).filter(
        EnergyForecastSlot.farm_id==farm.id,
        EnergyForecastSlot.timestamp>=now,
        EnergyForecastSlot.timestamp<end,
    ).order_by(EnergyForecastSlot.timestamp).all()
    grouped={}
    for r in rows: grouped.setdefault(_utc(r.timestamp),[]).append(r)
    profile=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    out=[]
    for i in range(horizon):
        ts=now+timedelta(hours=i); rs=grouped.get(ts,[])
        price=_combine_metric(db,farm.id,ts,rs,'price')
        pv=_combine_metric(db,farm.id,ts,rs,'pv')
        if price is None:
            price={'value':current_energy_price(db,farm),'providers':['tariff-fallback'],'confidence':45,'dispersion':0,'weights':{'tariff-fallback':1}}
        if pv is None:
            cap=float(profile.pv_capacity_kw if profile else 0)
            local_h=ts.astimezone().hour
            pvkw=0.0
            if cap and 6<=local_h<=20:
                x=(local_h-13)/7; pvkw=max(0.0,cap*(1-x*x))
            pv={'value':pvkw,'providers':['fallback-model'],'confidence':45,'dispersion':0,'weights':{'fallback-model':1}}
        providers=sorted(set(price['providers']+pv['providers']))
        confidence=min(price['confidence'],pv['confidence'])
        out.append({'timestamp':ts,'grid_price_eur_kwh':float(price['value']),'pv_kw':float(pv['value']),
                    'source':'ensemble','provider':'ensemble','providers':providers,
                    'confidence_pct':round(confidence,1),
                    'ensemble':{'price':price,'pv':pv}})
    return out
