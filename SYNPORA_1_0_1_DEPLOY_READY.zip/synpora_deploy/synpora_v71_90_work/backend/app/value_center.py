def rank_value(energy_price=.11, btc_value=.118, ai_value=.142, battery_value=.094, grid_value=.071):
    rows=[('AI Compute',ai_value),('BTC Mining',btc_value),('Battery',battery_value),('Grid Export',grid_value)]
    rows.sort(key=lambda x:x[1],reverse=True)
    return {'current_energy_price_eur_kwh':energy_price,'options':[{'name':n,'value_eur_kwh':round(v,4),'delta_vs_grid_eur_kwh':round(v-grid_value,4)} for n,v in rows],'best':rows[0][0],'best_value_eur_kwh':rows[0][1]}

def decision(payload):
    r=rank_value(**{k:payload[k] for k in ('energy_price','btc_value','ai_value','battery_value','grid_value') if k in payload})
    best=r['options'][0]
    reasons=['energy price','market value','asset availability','data quality']
    return {**r,'action':'RECOMMEND_ONLY','confidence_pct':payload.get('confidence_pct',88),'reason_codes':reasons,'explanation':f"{best['name']} currently has the highest modeled net value per kWh. No hardware command is issued."}
