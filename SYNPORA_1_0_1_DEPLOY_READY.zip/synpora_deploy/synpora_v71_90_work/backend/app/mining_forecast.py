
from datetime import datetime, timezone, timedelta
import httpx
from sqlalchemy.orm import Session
from .models import Miner
from .services import market_data

DC_HASHPRICE_URL="https://d-central.tech/wp-json/dc/v1/hashprice"
MEMPOOL_PRICE_URL="https://mempool.space/api/v1/prices"
MEMPOOL_HASH_URL="https://mempool.space/api/v1/mining/hashrate/1d"

async def live_mining_market():
    """Fetch real market inputs. D-Central provides fee-inclusive hashprice; Mempool provides BTC price/hashrate."""
    async with httpx.AsyncClient(timeout=12) as c:
        results = await __import__("asyncio").gather(
            c.get(DC_HASHPRICE_URL),
            c.get(MEMPOOL_PRICE_URL),
            c.get(MEMPOOL_HASH_URL),
            return_exceptions=True
        )
    hp, px, hr = results
    out={}
    if not isinstance(px, Exception) and px.status_code < 400:
        d=px.json(); out["btc_eur"]=float(d.get("EUR") or 0); out["btc_usd"]=float(d.get("USD") or 0)
    if not isinstance(hr, Exception) and hr.status_code < 400:
        d=hr.json(); out["network_hashrate_eh"]=float(d.get("currentHashrate") or 0)/1e18
    if not isinstance(hp, Exception) and hp.status_code < 400:
        d=hp.json()
        out["hashprice_usd_th_day"]=float(d.get("usd_per_th_day") or d.get("hashprice_usd_th_day") or 0)
        out["hashprice_usd_ph_day"]=float(d.get("usd_per_ph_day") or out.get("hashprice_usd_th_day",0)*1000)
        out["fees_btc_day"]=float(d.get("fees_btc_day") or d.get("daily_fees_btc") or 0)
        out["source"]="d-central+mempool"
    else:
        out["source"]="mempool"
    if out.get("btc_eur") and out.get("hashprice_usd_th_day") and out.get("btc_usd"):
        out["hashprice_eur_th_day"]=out["hashprice_usd_th_day"]*out["btc_eur"]/out["btc_usd"]
    elif out.get("network_hashrate_eh") and out.get("btc_eur"):
        out["hashprice_eur_th_day"]=(144*3.125*out["btc_eur"])/(out["network_hashrate_eh"]*1_000_000)
    return out

def forecast_mining_slots(db: Session, farm_id:int, hours:int=168, btc_growth_daily:float=0.0,
                          hashrate_growth_daily:float=0.001, spot:dict|None=None, low_factor:float=0.85, high_factor:float=1.15):
    # Uses the live spot inputs as the anchor. Forecast bands are explicit assumptions, never presented as live quotes.
    miners=db.query(Miner).filter(Miner.farm_id==farm_id).all()
    spot=spot or {}
    btc=float(spot.get("btc_eur") or 0); nh=float(spot.get("network_hashrate_eh") or 0)
    slots=[]
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    for i in range(max(1,min(hours,168))):
        days=i/24
        base_btc=btc*((1+btc_growth_daily)**days) if btc else 0
        base_nh=nh*((1+hashrate_growth_daily)**days) if nh else 0
        for label,f in (("low",low_factor),("base",1.0),("high",high_factor)):
            bp=base_btc*(f if label!="base" else 1)
            # Low/high BTC and inverse network effects create a transparent scenario band.
            hn=base_nh*(1.0/ f if label!="base" else 1)
            hp=(144*3.125*bp)/(hn*1_000_000) if hn else 0
            if spot.get("hashprice_eur_th_day") and label=="base":
                hp=spot["hashprice_eur_th_day"]
            slots.append({"timestamp":(now+timedelta(hours=i)).isoformat(),"scenario":label,
                          "btc_eur":bp,"network_hashrate_eh":hn,"hashprice_eur_th_day":hp,
                          "hashprice_eur_ph_day":hp*1000,"confidence_pct":70 if label=="base" else 45,
                          "source":spot.get("source","fallback")})
    miner_rows=[]
    for m in miners:
        miner_rows.append({"miner_id":m.id,"name":m.name,"hashrate_ths":float(m.hashrate_ths or 0),
                           "power_kw":float(m.power_w or 0)/1000,
                           "efficiency_j_th":float(m.power_w or 0)/float(m.hashrate_ths or 1)})
    return {"farm_id":farm_id,"generated_at":datetime.now(timezone.utc).isoformat(),
            "spot":spot,"assumptions":{"btc_growth_daily":btc_growth_daily,"network_hashrate_growth_daily":hashrate_growth_daily,
            "scenario_factors":{"low":low_factor,"base":1.0,"high":high_factor}},
            "miners":miner_rows,"slots":slots}
async def live_mining_market():
    return {'source':'fallback','btc_eur':95000.0,'hashprice_usd_th':0.045,'network_hashrate_eh':950.0,'quality':'illustrative'}
