def compare_prediction_to_actual(predicted, actual):
    keys=("pv_power_kw","grid_power_kw","battery_power_kw","load_power_kw")
    errors={}
    for k in keys:
        if predicted.get(k) is not None and actual.get(k) is not None:
            p=float(predicted[k]); a=float(actual[k])
            errors[k]={"absolute_error":abs(a-p),"signed_error":a-p}
    vals=[v["absolute_error"] for v in errors.values()]
    return {"errors":errors,"mae":sum(vals)/len(vals) if vals else None,
            "samples":len(vals)}

def calibration_factor(mae, scale=1.0):
    if mae is None: return 1.0
    return max(0.5,min(1.5,1.0/(1.0+float(mae)/max(scale,0.001))))
