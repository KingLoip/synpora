def score_option(value_eur_kwh, probability, data_quality, downside_eur_kwh, opportunity_cost=0):
    return (value_eur_kwh*probability*data_quality) - downside_eur_kwh - opportunity_cost

def optimize(options):
    ranked=[]
    for o in options:
        x=dict(o)
        x["score"]=score_option(float(o.get("value_eur_kwh",0)),
                                float(o.get("probability",1)),
                                float(o.get("data_quality",1)),
                                float(o.get("downside_eur_kwh",0)),
                                float(o.get("opportunity_cost",0)))
        ranked.append(x)
    return sorted(ranked,key=lambda x:x["score"],reverse=True)

def autonomous_proposal(options, min_confidence=0.70):
    ranked=optimize(options)
    if not ranked: return {"action":"HOLD","confidence":0,"reason":"NO_OPTIONS"}
    best=ranked[0]
    conf=float(best.get("confidence",0))
    if conf < min_confidence:
        return {"action":"HOLD","confidence":conf,"reason":"CONFIDENCE_GATE","ranked":ranked}
    return {"action":best.get("action","HOLD"),"confidence":conf,
            "reason":"BEST_RISK_ADJUSTED_SCORE","ranked":ranked}
