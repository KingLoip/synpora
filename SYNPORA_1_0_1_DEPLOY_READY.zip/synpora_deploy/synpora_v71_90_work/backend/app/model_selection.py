from .backtest import run_backtest

def select_model(rows):
    candidates=['btc','ai','value_rank']; results=[run_backtest(rows,m) for m in candidates]
    best=max(results,key=lambda x:(x['mean_realized']-abs(x['mean_error']))) if results else {'model':'hold'}
    return {'selected_model':best.get('model'),'candidates':[{k:v for k,v in r.items() if k!='rows'} for r in results],'selection_rule':'mean realized value minus absolute prediction error'}

def confidence(score,quality,error_pct,spread):
    c=0.45*score+0.25*quality+0.2*max(0,100-error_pct)+0.1*min(100,spread*1000)
    return round(max(0,min(100,c)),2)
