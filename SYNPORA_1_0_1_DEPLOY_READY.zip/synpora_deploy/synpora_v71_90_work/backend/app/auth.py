import base64,hmac,hashlib,json,os,time,secrets
from fastapi import Header,HTTPException
from .config import JWT_SECRET,JWT_EXPIRE_HOURS,API_KEY

def _b64(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def _unb64(s): return base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4))
def hash_password(password:str)->str:
    salt=secrets.token_bytes(16); rounds=210000
    digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,rounds)
    return f'pbkdf2_sha256${rounds}${_b64(salt)}${_b64(digest)}'
def verify_password(password,stored):
    try:
        alg,rounds,salt,digest=stored.split('$'); calc=hashlib.pbkdf2_hmac('sha256',password.encode(),_unb64(salt),int(rounds)); return hmac.compare_digest(_b64(calc),digest)
    except Exception:return False
def create_token(user_id:int,email:str,role:str):
    header={'alg':'HS256','typ':'JWT'}; payload={'sub':str(user_id),'email':email,'role':role,'iat':int(time.time()),'exp':int(time.time()+JWT_EXPIRE_HOURS*3600)}
    a=_b64(json.dumps(header,separators=(',',':')).encode()); b=_b64(json.dumps(payload,separators=(',',':')).encode()); sig=_b64(hmac.new(JWT_SECRET.encode(),f'{a}.{b}'.encode(),hashlib.sha256).digest()); return f'{a}.{b}.{sig}'
def decode_token(token:str):
    try:
        a,b,s=token.split('.'); expected=_b64(hmac.new(JWT_SECRET.encode(),f'{a}.{b}'.encode(),hashlib.sha256).digest())
        if not hmac.compare_digest(s,expected):raise ValueError()
        p=json.loads(_unb64(b))
        if int(p['exp'])<int(time.time()):raise ValueError()
        return p
    except Exception: raise HTTPException(401,'Invalid or expired access token')
def principal(x_api_key:str|None=None,authorization:str|None=None):
    if authorization and authorization.lower().startswith('bearer '): return decode_token(authorization.split(' ',1)[1])
    if API_KEY!='change-me' and x_api_key==API_KEY: return {'sub':'api-key','email':'api-key','role':'owner','api_key':True}
    raise HTTPException(401,'Authentication required')

def auth(x_api_key:str|None=Header(default=None),authorization:str|None=Header(default=None)):
    return principal(x_api_key,authorization)
