SUPPORTED_API=("v1",)
def compatibility(client_version):
    return {"client_version":client_version,"compatible":client_version in SUPPORTED_API,
            "supported":list(SUPPORTED_API)}
