from datetime import datetime, timezone
from sqlalchemy.orm import Session
from .models import ComputeOption

def compute_economics(db: Session, farm_id: int, risk_discount_pct: float=0.0):
    opts=db.query(ComputeOption).filter(ComputeOption.farm_id==farm_id,ComputeOption.enabled==1).all(); rows=[]
    discount=max(0,min(90,risk_discount_pct))/100
    for x in opts:
        power=float(x.power_kw or 0); avail=float(x.availability_pct or 0)/100
        gross=float(x.gross_revenue_eur_hour or 0)*avail; variable=float(x.variable_cost_eur_hour or 0)*avail
        net=max(0,gross-variable); kwh=power
        rows.append({'compute_id':x.id,'name':x.name,'workload':x.workload,'power_kw':power,'availability_pct':x.availability_pct,'gross_revenue_eur_hour':gross,'variable_cost_eur_hour':variable,'net_revenue_eur_hour':net,'gross_value_eur_kwh':gross/kwh if kwh else 0,'net_value_eur_kwh':net/kwh if kwh else 0,'risk_adjusted_value_eur_kwh':(net/kwh if kwh else 0)*(1-discount)})
    return {'farm_id':farm_id,'generated_at':datetime.now(timezone.utc).isoformat(),'risk_discount_pct':risk_discount_pct,'options':rows}
