import sqlite3
from datetime import datetime, timezone

def ensure_pilot_table(db):
    db.execute("""CREATE TABLE IF NOT EXISTS pilot_samples(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        farm_id TEXT, source TEXT, timestamp TEXT,
        pv_power_kw REAL, grid_power_kw REAL, battery_power_kw REAL,
        battery_soc_pct REAL, load_power_kw REAL,
        quality TEXT, payload_json TEXT
    )""")
    db.execute("CREATE INDEX IF NOT EXISTS idx_pilot_farm_time ON pilot_samples(farm_id,timestamp)")
    db.commit()

def store_sample(db, farm_id, sample):
    import json
    ensure_pilot_table(db)
    db.execute("""INSERT INTO pilot_samples
      (farm_id,source,timestamp,pv_power_kw,grid_power_kw,battery_power_kw,
       battery_soc_pct,load_power_kw,quality,payload_json)
      VALUES(?,?,?,?,?,?,?,?,?,?)""",
      (farm_id,sample.get("source"),sample.get("timestamp"),
       sample.get("pv_power_kw"),sample.get("grid_power_kw"),
       sample.get("battery_power_kw"),sample.get("battery_soc_pct"),
       sample.get("load_power_kw"),sample.get("quality"),json.dumps(sample)))
    db.commit()

def recent_samples(db,farm_id,limit=100):
    ensure_pilot_table(db)
    rows=db.execute("""SELECT timestamp,pv_power_kw,grid_power_kw,battery_power_kw,
      battery_soc_pct,load_power_kw,quality FROM pilot_samples
      WHERE farm_id=? ORDER BY timestamp DESC LIMIT ?""",(farm_id,int(limit))).fetchall()
    return [dict(zip(["timestamp","pv_power_kw","grid_power_kw","battery_power_kw",
                      "battery_soc_pct","load_power_kw","quality"],r)) for r in rows]
