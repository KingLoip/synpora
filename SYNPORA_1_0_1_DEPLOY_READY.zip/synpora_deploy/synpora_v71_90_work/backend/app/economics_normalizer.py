def normalize(value, unit="eur_kwh"):
    v=float(value)
    if unit=="eur_kwh": return v
    if unit=="eur_mwh": return v/1000
    if unit=="usd_kwh": return v*0.92
    if unit=="usd_mwh": return v*0.92/1000
    raise ValueError("unsupported_unit")
def net_value(gross, energy_cost, variable_cost=0, risk_discount=0):
    return float(gross)-float(energy_cost)-float(variable_cost)-float(risk_discount)
