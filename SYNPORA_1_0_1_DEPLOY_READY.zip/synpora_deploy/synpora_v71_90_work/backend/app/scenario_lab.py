from datetime import datetime, timezone
from .portfolio_optimizer import portfolio_snapshot

def run_scenarios(db, scenarios=None):
    base=portfolio_snapshot(db); scenarios=scenarios or [{'name':'Base','price_mult':1,'compute_mult':1},{'name':'Cheap Power','price_mult':.75,'compute_mult':1},{'name':'Expensive Power','price_mult':1.5,'compute_mult':1},{'name':'High Compute Demand','price_mult':1,'compute_mult':1.25}]
    results=[]
    for s in scenarios:
        rows=[]; margin=0
        for f in base:
            cost=f['power_kw']*f['electricity_price_eur_kwh']*s.get('price_mult',1)
            proxy_revenue=f['power_kw']*0.14*s.get('compute_mult',1)
            m=proxy_revenue-cost; margin+=m; rows.append({'farm_id':f['farm_id'],'name':f['name'],'estimated_hourly_margin_eur':round(m,2)})
        results.append({'name':s['name'],'estimated_portfolio_hourly_margin_eur':round(margin,2),'farms':rows,'inputs':s})
    return {'generated_at':datetime.now(timezone.utc).isoformat(),'scenarios':results,'disclaimer':'Scenario estimates are decision-support proxies; connect verified workload revenue and live market data before production decisions.'}
