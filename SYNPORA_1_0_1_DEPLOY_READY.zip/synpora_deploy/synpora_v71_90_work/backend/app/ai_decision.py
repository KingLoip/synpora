def decide(candidates,confidence=70,minimum_spread=.01):
    ranked=sorted(candidates,key=lambda x:float(x.get('risk_adjusted_eur_kwh') or -999),reverse=True)
    if not ranked:return {'decision':'NO_DATA','confidence_pct':0,'reason':'No usable candidate data.'}
    best=ranked[0]; second=ranked[1] if len(ranked)>1 else None; spread=float(best.get('risk_adjusted_eur_kwh') or 0)-(float(second.get('risk_adjusted_eur_kwh') or 0) if second else 0); conf=max(0,min(100,float(confidence or 0)))
    if conf<50 or (second and spread<minimum_spread): return {'decision':'HOLD','chosen_source':None,'confidence_pct':conf,'spread_eur_kwh':spread,'reason':'Insufficient confidence or economic separation; gather more data.','candidates':ranked,'approval_required':True,'control_commands_sent':False}
    return {'decision':best.get('source'),'chosen_source':best.get('source'),'value_eur_kwh':best.get('risk_adjusted_eur_kwh'),'confidence_pct':conf,'spread_eur_kwh':spread,'reason':'Highest risk-adjusted value with sufficient confidence.','candidates':ranked,'approval_required':True,'control_commands_sent':False}
