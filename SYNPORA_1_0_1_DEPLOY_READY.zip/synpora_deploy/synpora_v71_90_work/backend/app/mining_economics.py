from datetime import datetime, timezone
from sqlalchemy.orm import Session
from .models import Miner


def mining_economics(db: Session, farm_id: int, market: dict, pool_fee_pct: float = 2.0, uptime_pct: float = 98.0):
    btc_eur=float(market.get('btc_eur') or 0)
    network_eh=float(market.get('network_hashrate_eh') or 0)
    reward=float(market.get('block_reward_btc') or 3.125)
    if not reward: reward=3.125
    fee=max(0,min(100,pool_fee_pct))/100
    uptime=max(0,min(100,uptime_pct))/100
    # BTC earned per TH/s per day; network EH/s = 1e6 TH/s.
    btc_per_th_day=(144*reward*(1-fee)*uptime)/(network_eh*1_000_000) if network_eh>0 else 0
    hashprice_eur_th_day=btc_per_th_day*btc_eur
    miners=db.query(Miner).filter(Miner.farm_id==farm_id).all()
    rows=[]
    for m in miners:
        h=float(m.hashrate_ths or 0); p=float(m.power_w or 0)/1000
        btc_day=h*btc_per_th_day; revenue=btc_day*btc_eur; energy_kwh=p*24*uptime
        rows.append({'miner_id':m.id,'name':m.name,'model':m.model,'hashrate_ths':h,'power_kw':p,'efficiency_j_th':(m.power_w/h if h else None),'btc_day':btc_day,'revenue_eur_day':revenue,'energy_kwh_day':energy_kwh,'gross_value_eur_kwh':(revenue/energy_kwh if energy_kwh else 0)})
    return {'farm_id':farm_id,'generated_at':datetime.now(timezone.utc).isoformat(),'btc_eur':btc_eur,'network_hashrate_eh':network_eh,'block_reward_btc':reward,'pool_fee_pct':pool_fee_pct,'uptime_pct':uptime_pct,'hashprice_eur_th_day':hashprice_eur_th_day,'hashprice_eur_ph_day':hashprice_eur_th_day*1000,'miners':rows,'assumptions':{'transaction_fees_included':False,'market_source':'mempool'}}
