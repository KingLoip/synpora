
from datetime import datetime, timezone
import httpx

GRIDCOMPUTE_URL="https://gridcompute.ai/api/latest"

async def live_compute_market():
    """Real public GPU asking-price snapshot from GridCompute. Prices are market asks, not guaranteed realizable revenue."""
    async with httpx.AsyncClient(timeout=12) as c:
        r=await c.get(GRIDCOMPUTE_URL); r.raise_for_status(); d=r.json()
    rows=[]
    for g in d.get("gpus",[]):
        m=g.get("market") or {}
        if m.get("median") is not None:
            rows.append({"gpu_key":g.get("key"),"gpu_name":g.get("name"),"source":"gridcompute/vast",
                          "price_usd_gpu_hour":float(m["median"]),"offers":m.get("offers"),
                          "p25_usd":m.get("p25"),"p75_usd":m.get("p75"),
                          "timestamp_utc":d.get("meta",{}).get("last")})
        lists=g.get("lists") or {}
        for provider,price in lists.items():
            if price is not None:
                rows.append({"gpu_key":g.get("key"),"gpu_name":g.get("name"),"source":f"gridcompute/{provider}",
                              "price_usd_gpu_hour":float(price),"offers":None,"p25_usd":None,"p75_usd":None,
                              "timestamp_utc":d.get("meta",{}).get("last")})
    return {"generated_at":datetime.now(timezone.utc).isoformat(),"source":GRIDCOMPUTE_URL,
            "source_note":"Vast.ai marketplace asks and provider rate cards aggregated by GridCompute; not guaranteed realized revenue.",
            "rows":rows,"meta":d.get("meta",{}),"lists":d.get("lists",[])}

def normalize_compute_quotes(rows, usd_eur=0.92, power_kw_by_gpu=None, availability=0.90, variable_cost_eur_hour=0):
    power_kw_by_gpu=power_kw_by_gpu or {}
    out=[]
    for r in rows:
        gpu=r.get("gpu_key") or ""
        kw=float(power_kw_by_gpu.get(gpu,0))
        gross=float(r["price_usd_gpu_hour"])*usd_eur
        net=max(0,gross*availability-variable_cost_eur_hour)
        out.append({**r,"price_eur_gpu_hour":gross,"availability_pct":availability*100,
                    "power_kw":kw,"gross_value_eur_kwh":gross/kw if kw else None,
                    "net_value_eur_kwh":net/kw if kw else None,
                    "risk_adjusted_value_eur_kwh":(net/kw*0.9 if kw else None)})
    return out
async def live_compute_market():
    return {'source':'fallback','gpu_compute_eur_hour':0.42,'quality':'illustrative','quotes':[]}
