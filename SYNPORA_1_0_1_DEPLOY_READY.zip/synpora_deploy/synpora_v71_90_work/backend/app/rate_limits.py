from time import time
WINDOWS={}
def allow(key,limit=60,window=60):
    now=time(); arr=[t for t in WINDOWS.get(key,[]) if now-t<window]
    ok=len(arr)<limit
    if ok: arr.append(now)
    WINDOWS[key]=arr
    return {"allowed":ok,"remaining":max(0,limit-len(arr))}
