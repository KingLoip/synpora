def autonomous_plan(candidates,safety):
    eligible=[c for c in candidates if float(c.get('confidence_pct') or 0)>=70]
    best=max(eligible,key=lambda x:float(x.get('expected_value_eur_kwh') or -999),default={'action':'HOLD','expected_value_eur_kwh':0,'confidence_pct':0})
    action=best.get('action','HOLD') if safety.get('safe_to_propose') else 'HOLD'
    return {'action':action,'expected_value_eur_kwh':best.get('expected_value_eur_kwh'),'confidence_pct':best.get('confidence_pct'),'approval_required':True,'control_commands_sent':False,'safety':safety}
