def run_cases(cases):
    results=[]
    for c in cases:
        fn=c["fn"]; expected=c.get("expected")
        try:
            got=fn(c.get("input",{}))
            results.append({"name":c.get("name","case"),"pass":got==expected,"got":got,"expected":expected})
        except Exception as e:
            results.append({"name":c.get("name","case"),"pass":False,"error":str(e)})
    return {"passed":sum(1 for r in results if r["pass"]),"total":len(results),"results":results}
