from datetime import datetime, timezone
from typing import Dict, Any
import json
from sqlalchemy import text


def ensure_adapter_table(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS hardware_adapters (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farm_id INTEGER NOT NULL, name VARCHAR(120) NOT NULL,
      kind VARCHAR(40) NOT NULL, endpoint VARCHAR(500), enabled INTEGER DEFAULT 1,
      last_seen DATETIME, last_status VARCHAR(40), metadata_json TEXT)'''))
    db.commit()


def register_adapter(db, farm_id, data):
    ensure_adapter_table(db)
    row = db.execute(text('''INSERT INTO hardware_adapters
      (farm_id,name,kind,endpoint,enabled,last_status,metadata_json) VALUES
      (:farm_id,:name,:kind,:endpoint,:enabled,:status,:meta)'''), {
        'farm_id': farm_id, 'name': data.get('name','adapter'), 'kind': data.get('kind','generic_http'),
        'endpoint': data.get('endpoint'), 'enabled': 1 if data.get('enabled', True) else 0,
        'status':'registered', 'meta': json.dumps(data.get('metadata',{}))}).lastrowid
    db.commit(); return get_adapter(db,row)


def get_adapter(db, adapter_id):
    r=db.execute(text('SELECT * FROM hardware_adapters WHERE id=:id'),{'id':adapter_id}).mappings().first()
    if not r:return None
    d=dict(r); d['enabled']=bool(d['enabled']); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); return d


def list_adapters(db,farm_id):
    ensure_adapter_table(db)
    return [dict(x) for x in db.execute(text('SELECT * FROM hardware_adapters WHERE farm_id=:farm ORDER BY id'),{'farm':farm_id}).mappings().all()]


def adapter_health(db,farm_id):
    ensure_adapter_table(db); rows=db.execute(text('SELECT * FROM hardware_adapters WHERE farm_id=:farm'),{'farm':farm_id}).mappings().all()
    now=datetime.now(timezone.utc); out=[]
    for r in rows:
        seen=r['last_seen']; age=None
        if seen:
            try: age=(now-seen.replace(tzinfo=timezone.utc)).total_seconds()/60
            except Exception: pass
        out.append({'id':r['id'],'name':r['name'],'kind':r['kind'],'enabled':bool(r['enabled']),'status':r['last_status'],'age_minutes':age,'read_only':True})
    return out


def ingest_adapter_state(db,adapter_id,state):
    ensure_adapter_table(db); now=datetime.now(timezone.utc)
    db.execute(text('UPDATE hardware_adapters SET last_seen=:ts,last_status=:status,metadata_json=:meta WHERE id=:id'),
               {'ts':now,'status':state.get('status','online'),'meta':json.dumps(state),'id':adapter_id}); db.commit()
    return get_adapter(db,adapter_id)
