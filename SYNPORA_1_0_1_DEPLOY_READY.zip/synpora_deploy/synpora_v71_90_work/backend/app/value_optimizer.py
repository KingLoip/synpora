from datetime import datetime, timezone
from .mining_economics import mining_economics
from .compute_economics import compute_economics
from .models import EnergyProfile
from .services import market_data

async def value_per_kwh(db, farm, risk_aversion=0.25, pv_available_kw=0.0, grid_price=None, export_price=None):
    market=await market_data(); mining=mining_economics(db,farm.id,market); compute=compute_economics(db,farm.id,risk_aversion*100)
    profile=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    price=float(grid_price if grid_price is not None else (profile.grid_import_price_eur_kwh if profile else farm.electricity_price_eur_kwh))
    export=float(export_price if export_price is not None else (profile.grid_export_price_eur_kwh if profile else 0.06))
    candidates=[]
    for m in mining['miners']:
        gross=m['gross_value_eur_kwh']; net=gross-price; risk=max(0,net)*(1-risk_aversion)
        candidates.append({'type':'BITCOIN_MINING','asset_id':m['miner_id'],'name':m['name'],'power_kw':m['power_kw'],'gross_value_eur_kwh':gross,'energy_cost_eur_kwh':price,'net_value_eur_kwh':net,'risk_adjusted_value_eur_kwh':risk,'source':'GRID'})
        pv_net=gross-export; pv_risk=max(0,pv_net)*(1-risk_aversion)
        candidates.append({'type':'BITCOIN_MINING_PV','asset_id':m['miner_id'],'name':m['name'],'power_kw':m['power_kw'],'gross_value_eur_kwh':gross,'energy_cost_eur_kwh':export,'net_value_eur_kwh':pv_net,'risk_adjusted_value_eur_kwh':pv_risk,'source':'PV_SURPLUS'})
    for x in compute['options']:
        net=x['net_value_eur_kwh']; grid_net=net-price; pv_net=net-export
        candidates.append({'type':'AI_COMPUTE','asset_id':x['compute_id'],'name':x['name'],'power_kw':x['power_kw'],'gross_value_eur_kwh':x['gross_value_eur_kwh'],'energy_cost_eur_kwh':price,'net_value_eur_kwh':grid_net,'risk_adjusted_value_eur_kwh':max(0,grid_net)*(1-risk_aversion),'source':'GRID'})
        candidates.append({'type':'AI_COMPUTE_PV','asset_id':x['compute_id'],'name':x['name'],'power_kw':x['power_kw'],'gross_value_eur_kwh':x['gross_value_eur_kwh'],'energy_cost_eur_kwh':export,'net_value_eur_kwh':pv_net,'risk_adjusted_value_eur_kwh':max(0,pv_net)*(1-risk_aversion),'source':'PV_SURPLUS'})
    candidates.sort(key=lambda x:x['risk_adjusted_value_eur_kwh'],reverse=True)
    best=candidates[0] if candidates else {'type':'IDLE','name':'Keine aktive Compute-Option','risk_adjusted_value_eur_kwh':0,'net_value_eur_kwh':0,'power_kw':0,'source':'NONE'}
    return {'version':'24.0','farm_id':farm.id,'generated_at':datetime.now(timezone.utc).isoformat(),'grid_price_eur_kwh':price,'pv_export_opportunity_cost_eur_kwh':export,'pv_available_kw':pv_available_kw,'risk_aversion':risk_aversion,'best_use_of_kwh':best,'ranking':candidates[:25],'mining':mining,'compute':compute,'recommendation':'ALLOCATE_TO_'+best['type'] if best.get('risk_adjusted_value_eur_kwh',0)>0 else 'HOLD_IDLE','read_only':True}
async def value_per_kwh(db, farm, risk_aversion=0.0, pv_available_kw=0.0, grid_price=0.11, export_price=0.06):
    from .value_center import rank_value
    return rank_value(energy_price=grid_price)
