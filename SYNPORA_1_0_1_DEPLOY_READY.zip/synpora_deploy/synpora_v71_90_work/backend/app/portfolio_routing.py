def route_farms(farms, power_budget_kw=None):
    ranked=sorted(farms,key=lambda x:float(x.get('expected_value_eur_kwh') or -999),reverse=True); remaining=power_budget_kw; routes=[]
    for f in ranked:
        cap=float(f.get('available_power_kw') or 0)
        alloc=cap if remaining is None else max(0,min(cap,remaining))
        routes.append({'farm_id':f.get('farm_id'),'allocation_kw':alloc,'action':f.get('action','HOLD'),'value_eur_kwh':f.get('expected_value_eur_kwh'),'confidence_pct':f.get('confidence_pct')})
        if remaining is not None: remaining-=alloc
    return {'routes':routes,'unallocated_kw':remaining,'optimization':'highest expected risk-adjusted value first'}
