METRICS={}
def observe(name,value):
    METRICS[name]=float(value); return {"name":name,"value":METRICS[name]}
def snapshot(): return dict(METRICS)
