def sanitize_config(cfg):
    secret_keys=("password","token","api_key","secret","private_key")
    out={}
    for k,v in cfg.items():
        out[k]="***REDACTED***" if any(x in k.lower() for x in secret_keys) else v
    return out
