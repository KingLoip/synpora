import time
MODELS={}
def register(name, version, metrics):
    MODELS[name]={"name":name,"version":version,"metrics":metrics,"registered_at":time.time()}
    return MODELS[name]
def list_models(): return list(MODELS.values())
def select_best(metric="mae"):
    if not MODELS: return None
    return min(MODELS.values(),key=lambda x:float(x.get("metrics",{}).get(metric,1e9)))
