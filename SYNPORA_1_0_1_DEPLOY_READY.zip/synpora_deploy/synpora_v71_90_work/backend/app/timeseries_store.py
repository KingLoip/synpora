from datetime import datetime, timezone
import json
from sqlalchemy import text

def ensure_ts_table(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS intelligence_timeseries (id INTEGER PRIMARY KEY AUTOINCREMENT,farm_id INTEGER NOT NULL,ts DATETIME NOT NULL,metric VARCHAR(100) NOT NULL,value REAL,unit VARCHAR(30),source VARCHAR(100),quality REAL,metadata_json TEXT)''')); db.commit()
def write_point(db,farm_id,metric,value,unit=None,source='manual',quality=1,ts=None,metadata=None):
    ensure_ts_table(db); ts=ts or datetime.now(timezone.utc); r=db.execute(text('INSERT INTO intelligence_timeseries(farm_id,ts,metric,value,unit,source,quality,metadata_json) VALUES(:f,:t,:m,:v,:u,:s,:q,:x)'),{'f':farm_id,'t':ts,'m':metric,'v':value,'u':unit,'s':source,'q':quality,'x':json.dumps(metadata or {})}); db.commit(); return {'id':r.lastrowid,'farm_id':farm_id,'timestamp':ts,'metric':metric,'value':value,'unit':unit,'source':source,'quality':quality}
def query_points(db,farm_id,metric=None,limit=500):
    ensure_ts_table(db); q='SELECT * FROM intelligence_timeseries WHERE farm_id=:f'; p={'f':farm_id,'n':min(limit,5000)}
    if metric:q+=' AND metric=:m'; p['m']=metric
    q+=' ORDER BY ts DESC LIMIT :n'; return [dict(x) for x in db.execute(text(q),p).mappings().all()]
