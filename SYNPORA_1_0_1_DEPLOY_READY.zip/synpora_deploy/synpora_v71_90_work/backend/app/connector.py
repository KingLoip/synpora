import json,socket
from .config import CONNECT_TIMEOUT

# Read-only CGMiner-compatible adapter. Many ASIC controllers expose status on TCP 4028.
# We never send restart/config/pool/write commands here.
READ_COMMANDS=("summary","stats","pools")

def call(host,port,command):
    req=json.dumps({"command":command})+"\n"
    with socket.create_connection((host,port),timeout=CONNECT_TIMEOUT) as s:
        s.sendall(req.encode())
        s.settimeout(CONNECT_TIMEOUT)
        data=b""
        while True:
            try:
                chunk=s.recv(65535)
                if not chunk: break
                data+=chunk
                if b"\n" in data: break
            except socket.timeout: break
    if not data: raise RuntimeError("No response")
    raw=data.decode("utf-8","replace").strip()
    try:return json.loads(raw)
    except Exception as e:raise RuntimeError(f"Invalid JSON response: {e}")

def number(obj,*keys):
    for k in keys:
        v=obj.get(k)
        if isinstance(v,(int,float)): return float(v)
        try:
            if v is not None:return float(v)
        except: pass
    return None

def normalize(raw):
    # Handles common CGMiner/ASIC naming variants without assuming one firmware.
    summary=(raw.get("SUMMARY") or [{}])[0] if isinstance(raw.get("SUMMARY"),list) else (raw.get("SUMMARY") or {})
    stats=(raw.get("STATS") or [{}])[0] if isinstance(raw.get("STATS"),list) else (raw.get("STATS") or {})
    h=number(summary,"GHS 5s","GHS av","HS 5s","HS av")
    if h is not None: h=h/1000 if h>100000 else h # GH/s -> TH/s
    power=number(summary,"Power","power","Power Consumption","Watts")
    temp=number(stats,"Temperature","temp","Temp")
    fan=number(stats,"Fan Speed In","Fan Speed","fan")
    uptime=number(summary,"Elapsed","Uptime")
    return {"hashrate_ths":h,"power_w":power,"temperature_c":temp,"fan_pct":fan,"uptime_raw":uptime,"raw_keys":list(raw.keys())}

def poll(host,port=4028):
    # summary is primary; stats fills temperature/fan on firmware where needed.
    s=call(host,port,"summary")
    try: st=call(host,port,"stats")
    except Exception: st={}
    merged={"SUMMARY":s.get("SUMMARY",s.get("summary",[])),"STATS":st.get("STATS",st.get("stats",[]))}
    out=normalize(merged)
    out["host"]=host;out["port"]=port;out["protocol"]="cgminer-compatible";return out
