from dataclasses import dataclass, asdict

@dataclass
class DeviceProfile:
    vendor: str
    model: str
    protocol: str
    capabilities: list
    read_only: bool = True

PROFILES = [
    DeviceProfile("SOFAR","HYD10KTL-3PH","modbus_tcp",
                  ["pv_power","grid_power","battery_soc","battery_power","load_power"]),
    DeviceProfile("Fronius","GEN24","modbus_tcp",
                  ["pv_power","grid_power","battery_soc","battery_power","load_power"]),
    DeviceProfile("SMA","generic","modbus_tcp",
                  ["pv_power","grid_power","battery_soc","battery_power","load_power"]),
    DeviceProfile("Victron","generic","rest",
                  ["pv_power","grid_power","battery_soc","battery_power","load_power"]),
]

def list_profiles():
    return [asdict(x) for x in PROFILES]

def find_profile(vendor, model=None):
    for p in PROFILES:
        if p.vendor.lower()==vendor.lower() and (model is None or p.model.lower()==model.lower()):
            return asdict(p)
    return None
