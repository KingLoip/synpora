def scenario_grid(base, overrides):
    out=[]
    for ov in overrides:
        x=dict(base); x.update(ov)
        x["scenario_id"]=ov.get("scenario_id",str(len(out)+1))
        out.append(x)
    return out

def evaluate(s):
    energy=float(s.get("energy_price_eur_kwh",0))
    btc=float(s.get("btc_value_eur_kwh",0))
    ai=float(s.get("ai_value_eur_kwh",0))
    pv=float(s.get("pv_kw",0))
    battery=float(s.get("battery_opportunity_eur_kwh",0))
    candidates={"BTC_MINING":btc-energy,"AI_COMPUTE":ai-energy,"BATTERY":battery,"HOLD":0}
    action=max(candidates,key=candidates.get)
    return {**s,"decision":action,"net_value_eur_kwh":candidates[action],"candidates":candidates}

def run(base, overrides):
    rows=[evaluate(x) for x in scenario_grid(base,overrides)]
    return {"scenarios":rows,"best":max(rows,key=lambda x:x["net_value_eur_kwh"]) if rows else None}
