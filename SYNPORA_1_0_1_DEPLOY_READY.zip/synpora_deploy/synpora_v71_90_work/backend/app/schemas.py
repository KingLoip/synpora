from datetime import datetime
from typing import Optional
from pydantic import BaseModel,Field,ConfigDict
class FarmCreate(BaseModel):
    name:str; electricity_price_eur_kwh:float=Field(.11,ge=0); power_limit_kw:Optional[float]=Field(None,ge=0); reserve_pct:float=Field(10,ge=0,le=50)
class FarmOut(FarmCreate):
    id:int; created_at:datetime
    model_config=ConfigDict(from_attributes=True)
class MinerCreate(BaseModel):
    farm_id:int; name:str; manufacturer:Optional[str]=None; model:Optional[str]=None
    hashrate_ths:float=Field(gt=0); power_w:float=Field(gt=0); capex_eur:Optional[float]=Field(None,ge=0)
    host:Optional[str]=None; api_port:int=Field(4028,ge=1,le=65535)
class MinerOut(MinerCreate):
    id:int; status:str; created_at:datetime
    model_config=ConfigDict(from_attributes=True)
class TelemetryCreate(BaseModel):
    miner_id:int; timestamp:Optional[datetime]=None; hashrate_ths:Optional[float]=Field(None,gt=0); power_w:Optional[float]=Field(None,gt=0)
    temperature_c:Optional[float]=None; fan_pct:Optional[float]=Field(None,ge=0,le=100); uptime_pct:Optional[float]=Field(None,ge=0,le=100)
    pool_fee_pct:Optional[float]=Field(None,ge=0,le=100); error_message:Optional[str]=None
class DecisionRequest(BaseModel):
    btc_eur:float=Field(gt=0); network_hashrate_eh:float=Field(gt=0); block_reward_btc:float=Field(gt=0)
    pool_fee_pct:float=Field(0,ge=0,le=100); uptime_pct:float=Field(100,ge=0,le=100)
    electricity_price_eur_kwh:float=Field(gt=0); opex_eur_day:float=Field(0,ge=0)
class DecisionOut(BaseModel):
    action:str; reason:str; btc_day:float; revenue_eur_day:float; electricity_eur_day:float; profit_eur_day:float
    efficiency_j_th:float; break_even_eur_kwh:float; break_even_btc_eur:float; margin_pct:float

class LoginRequest(BaseModel):
    email:str; password:str
class BootstrapRequest(BaseModel):
    secret:str
    email:str
    password:str=Field(min_length=10)
class UserOut(BaseModel):
    id:int; email:str; role:str; is_active:int; created_at:datetime
    model_config=ConfigDict(from_attributes=True)
class FarmAccessRequest(BaseModel):
    email:str; role:str=Field('operator',pattern='^(owner|admin|operator|viewer)$')


class EnergyProfileCreate(BaseModel):
    grid_import_price_eur_kwh:float=Field(.11,ge=0); grid_export_price_eur_kwh:float=Field(.06,ge=0)
    pv_capacity_kw:float=Field(0,ge=0); battery_capacity_kwh:float=Field(0,ge=0); battery_soc_pct:float=Field(50,ge=0,le=100)
    battery_roundtrip_efficiency_pct:float=Field(90,gt=0,le=100); max_grid_import_kw:Optional[float]=Field(None,ge=0); max_pv_kw:Optional[float]=Field(None,ge=0); latitude:Optional[float]=None; longitude:Optional[float]=None; pv_tilt_deg:float=35; pv_azimuth_deg:float=0; timezone:str='UTC'; country_code:Optional[str]=None; market_zone:Optional[str]=None; currency:str='EUR'
class TariffCreate(BaseModel):
    weekday:int=Field(-1,ge=-1,le=6); start_hour:int=Field(0,ge=0,le=23); end_hour:int=Field(24,ge=1,le=24); price_eur_kwh:float=Field(gt=0); label:str='tariff'
class ComputeOptionCreate(BaseModel):
    name:str; workload:str='AI inference'; power_kw:float=Field(gt=0); gross_revenue_eur_hour:float=Field(gt=0); availability_pct:float=Field(100,gt=0,le=100); variable_cost_eur_hour:float=Field(0,ge=0); enabled:bool=True


class ForecastSlotCreate(BaseModel):
    timestamp:datetime
    grid_price_eur_kwh:float=Field(ge=0)
    pv_kw:float=Field(ge=0,default=0)
    source:str='user'
    currency:str='EUR'
    fx_to_eur:float=Field(1.0,gt=0)
    confidence_pct:float=Field(70,ge=0,le=100)

class EnergyObservationCreate(BaseModel):
    timestamp:datetime
    grid_price_eur_kwh:Optional[float]=Field(None,ge=0)
    pv_kw:Optional[float]=Field(None,ge=0)
    currency:str='EUR'
    source:str='user'
