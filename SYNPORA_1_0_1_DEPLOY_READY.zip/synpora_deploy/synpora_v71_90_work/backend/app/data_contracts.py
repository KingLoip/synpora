REQUIRED_ENERGY=("timestamp","source")
NUMERIC_ENERGY=("pv_power_kw","grid_power_kw","battery_power_kw","battery_soc_pct","load_power_kw")
def validate_energy(payload):
    errors=[]
    for k in REQUIRED_ENERGY:
        if k not in payload: errors.append("missing:"+k)
    for k in NUMERIC_ENERGY:
        if k in payload:
            try: float(payload[k])
            except (TypeError,ValueError): errors.append("numeric:"+k)
    if "battery_soc_pct" in payload:
        try:
            x=float(payload["battery_soc_pct"])
            if x<0 or x>100: errors.append("range:battery_soc_pct")
        except: pass
    return {"valid":not errors,"errors":errors}
