from statistics import mean

def anonymize_farm_snapshot(snapshot):
    allowed=("farm_class","region","capacity_kw","energy_price_eur_kwh",
             "decision","value_eur_kwh","confidence","data_quality")
    return {k:snapshot[k] for k in allowed if k in snapshot}

def aggregate_snapshots(snapshots):
    clean=[anonymize_farm_snapshot(s) for s in snapshots]
    vals=[float(s["value_eur_kwh"]) for s in clean if "value_eur_kwh" in s]
    conf=[float(s["confidence"]) for s in clean if "confidence" in s]
    return {"farms":len(clean),"avg_value_eur_kwh":mean(vals) if vals else 0,
            "avg_confidence":mean(conf) if conf else 0,
            "snapshots":clean}
