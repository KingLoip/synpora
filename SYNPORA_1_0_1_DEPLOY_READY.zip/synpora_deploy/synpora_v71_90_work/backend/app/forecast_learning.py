from datetime import datetime, timezone, timedelta
from statistics import pstdev
from sqlalchemy.orm import Session
from .models import EnergyForecastSlot, EnergyObservation, ForecastAccuracy

def _pct_error(actual, forecast):
    if actual is None or forecast is None: return None
    denom=max(abs(actual),0.0001)
    return abs(actual-forecast)/denom*100

def _signed_pct_error(actual, forecast):
    if actual is None or forecast is None: return None
    denom=max(abs(actual),0.0001)
    return (actual-forecast)/denom*100

def score_farm(db: Session, farm_id:int, hours:int=720):
    since=datetime.now(timezone.utc)-timedelta(hours=hours)
    forecasts=db.query(EnergyForecastSlot).filter(EnergyForecastSlot.farm_id==farm_id,EnergyForecastSlot.timestamp>=since).all()
    obs=db.query(EnergyObservation).filter(EnergyObservation.farm_id==farm_id,EnergyObservation.timestamp>=since).all()
    by={o.timestamp.replace(tzinfo=timezone.utc) if o.timestamp.tzinfo is None else o.timestamp.astimezone(timezone.utc):o for o in obs}
    groups={}
    for f in forecasts:
        ts=f.timestamp.replace(tzinfo=timezone.utc) if f.timestamp.tzinfo is None else f.timestamp.astimezone(timezone.utc)
        o=by.get(ts)
        if not o: continue
        for metric,forecast,actual in [('price',f.grid_price_eur_kwh,o.grid_price_eur_kwh),('pv',f.pv_kw,o.pv_kw)]:
            if actual is None or forecast is None: continue
            key=(metric,f.provider or f.source or 'unknown')
            g=groups.setdefault(key,{'e':[],'signed_pct':[]})
            e=_pct_error(actual,forecast); se=_signed_pct_error(actual,forecast)
            if e is not None: g['e'].append(e)
            if se is not None: g['signed_pct'].append(se)
    out=[]
    for (metric,provider),g in groups.items():
        n=len(g['e']); mae=sum(g['e'])/n if n else None; bias_pct=sum(g['signed_pct'])/len(g['signed_pct']) if g['signed_pct'] else None
        err_std=pstdev(g['e']) if len(g['e'])>1 else (mae or 0)
        # Weight favours accurate, well-sampled providers while avoiding zero-weight lockout.
        sample_factor=min(1.0,n/24)
        accuracy=max(0.05,1/(1+(mae or 100)/10))
        weight=max(0.05,accuracy*(0.35+0.65*sample_factor))
        calibrated_conf=max(10,min(99,100-(0.65*(mae or 100)+0.35*(err_std or 0)))) if n else 10
        score=max(0,min(100,100-(mae or 100))) if n else 0
        row=db.query(ForecastAccuracy).filter_by(farm_id=farm_id,metric=metric,provider=provider).first() or ForecastAccuracy(farm_id=farm_id,metric=metric,provider=provider)
        row.samples=n; row.mae=mae; row.mape=mae; row.bias=(sum(g['signed_pct'])/len(g['signed_pct']) if g['signed_pct'] else None); row.score=score; row.error_std=err_std; row.weight=weight; row.calibrated_confidence=calibrated_conf; row.updated_at=datetime.now(timezone.utc); db.add(row)
        out.append({'metric':metric,'provider':provider,'samples':n,'mae_pct':round(mae,2) if mae is not None else None,'bias_pct':round(row.bias,2) if row.bias is not None else None,'error_std_pct':round(err_std,2),'weight':round(weight,4),'calibrated_confidence_pct':round(calibrated_conf,1),'score':round(score,1)})
    db.commit(); return out

def provider_calibration(db: Session, farm_id:int, metric:str, provider:str):
    row=db.query(ForecastAccuracy).filter_by(farm_id=farm_id,metric=metric,provider=provider).first()
    if not row: return {'weight':1.0,'bias_pct':0.0,'error_std_pct':15.0,'confidence_pct':70.0,'samples':0}
    return {'weight':row.weight or 1.0,'bias_pct':row.bias or 0.0,'error_std_pct':row.error_std or row.mae or 15.0,'confidence_pct':row.calibrated_confidence or row.score or 70.0,'samples':row.samples or 0}
