LEDGER=[]
def append(entry):
    LEDGER.append(dict(entry)); return LEDGER[-1]
def recent(limit=100): return LEDGER[-int(limit):][::-1]
