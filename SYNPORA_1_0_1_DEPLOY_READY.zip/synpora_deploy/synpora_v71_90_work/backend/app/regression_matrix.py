def matrix(checks):
    return {"checks":checks,"passed":all(bool(x.get("pass")) for x in checks),
            "failed":[x for x in checks if not x.get("pass")]}
