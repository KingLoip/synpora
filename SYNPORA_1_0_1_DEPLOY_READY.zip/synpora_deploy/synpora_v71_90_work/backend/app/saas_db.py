from sqlalchemy import text
from .db import engine

def db_status():
    with engine.connect() as c:
        c.execute(text('SELECT 1'))
    return {'ok':True,'engine':engine.url.get_backend_name()}

def table_names():
    from sqlalchemy import inspect
    return sorted(inspect(engine).get_table_names())
