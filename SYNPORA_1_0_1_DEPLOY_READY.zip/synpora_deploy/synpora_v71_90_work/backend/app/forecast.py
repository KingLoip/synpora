from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from .models import EnergyForecastSlot, EnergyProfile, Miner, Telemetry, ComputeOption
from .energy import current_energy_price
from .forecast_learning import provider_calibration
from .forecast_ensemble import ensemble_forecast
from .services import mining_decision


def _hourly_defaults(db: Session, farm, horizon: int):
    now = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    p = db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    pv_cap = p.pv_capacity_kw if p else 0
    slots=[]
    for i in range(horizon):
        ts=now+timedelta(hours=i)
        # Conservative bell-shaped daylight profile; replaced by user/provider forecasts when present.
        local_h=ts.astimezone().hour
        if pv_cap > 0 and 6 <= local_h <= 20:
            x=(local_h-13)/7
            pv=max(0.0, pv_cap*(1-x*x))
        else: pv=0.0
        price=current_energy_price(db,farm)
        slots.append({'timestamp':ts,'grid_price_eur_kwh':price,'pv_kw':round(pv,3),'source':'model','provider':'fallback','confidence_pct':55})
    return slots


def _forecast_slots(db, farm, horizon: int):
    # v14: use a learned, time-aware provider ensemble. It gracefully falls back
    # to the stored forecast/tariff model when fewer than two providers exist.
    return ensemble_forecast(db, farm, horizon)


def _assets(db,farm,market):
    btc=market.get('btc_eur') or 0; net=market.get('network_hashrate_eh') or 0
    assets=[]
    for m in farm.miners:
        t=db.query(Telemetry).filter_by(miner_id=m.id).order_by(Telemetry.timestamp.desc()).first()
        h=t.hashrate_ths if t and t.hashrate_ths else m.hashrate_ths
        p=t.power_w if t and t.power_w else m.power_w
        if btc and net:
            d=mining_decision(h,p,btc,net,3.125,0,100,0)
            assets.append({'id':f'miner:{m.id}','name':m.name,'kind':'bitcoin_mining','power_kw':p/1000,'gross_value_eur_kwh':d.revenue_eur_day/(p/1000*24) if p else 0,'fixed_cost_eur_kwh':0})
    for c in db.query(ComputeOption).filter_by(farm_id=farm.id,enabled=1).all():
        net_hour=max(0,c.gross_revenue_eur_hour-c.variable_cost_eur_hour)*(c.availability_pct/100)
        assets.append({'id':f'compute:{c.id}','name':c.name,'kind':'ai_compute','power_kw':c.power_kw,'gross_value_eur_kwh':net_hour/c.power_kw if c.power_kw else 0,'fixed_cost_eur_kwh':0})
    return assets


def simulate(db: Session, farm, market, horizon=24):
    horizon=max(1,min(int(horizon),168)); slots=_forecast_slots(db,farm,horizon); p=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    battery_kwh=float(p.battery_capacity_kwh if p else 0); soc=float((p.battery_soc_pct/100*battery_kwh) if p else 0)
    rte=float((p.battery_roundtrip_efficiency_pct/100) if p else .9); reserve_kwh=battery_kwh*0.10
    max_grid=float(p.max_grid_import_kw if p and p.max_grid_import_kw is not None else (farm.power_limit_kw or 1e9))
    assets=sorted(_assets(db,farm,market), key=lambda a:a['gross_value_eur_kwh'], reverse=True)
    # Future-value threshold: retain battery for hours where grid energy is more expensive than the best available compute value.
    future_prices=[x['grid_price_eur_kwh'] for x in slots]
    rows=[]; totals={'value':0,'cost':0,'pv':0,'grid':0,'charge':0,'discharge':0}
    for idx,s in enumerate(slots):
        price=float(s['grid_price_eur_kwh']); pv=float(s['pv_kw']); remaining=max_grid; chosen=[]
        for a in assets:
            if a['power_kw']<=remaining and a['gross_value_eur_kwh']>0 and (pv>0 or a['gross_value_eur_kwh']>=price):
                chosen.append(a); remaining-=a['power_kw']
        load=sum(a['power_kw'] for a in chosen)
        pv_used=min(pv,load); residual=max(0,load-pv_used)
        batt_dis=0; batt_ch=0
        # Discharge only when this hour is economically attractive relative to the next 6h or when needed for grid cap.
        next_peak=max(future_prices[idx:min(idx+7,len(future_prices))]) if future_prices else price
        should_discharge=residual>0 and soc>reserve_kwh and (price>=next_peak*0.98 or any(a['gross_value_eur_kwh']>price for a in chosen))
        if residual>0 and battery_kwh>0 and soc>reserve_kwh and should_discharge:
            batt_dis=min(residual,(soc-reserve_kwh)*rte); soc-=batt_dis/rte; residual-=batt_dis
        if pv>pv_used and battery_kwh>0 and soc<battery_kwh:
            batt_ch=min(pv-pv_used,battery_kwh-soc); soc+=batt_ch*rte
        grid=max(0,residual)
        if grid>max_grid:
            for a in sorted(chosen,key=lambda x:x['gross_value_eur_kwh']):
                if grid<=max_grid: break
                chosen.remove(a); load-=a['power_kw']; pv_used=min(pv,load); grid=max(0,load-pv_used-batt_dis)
        value=sum(a['power_kw']*a['gross_value_eur_kwh'] for a in chosen); cost=grid*price; net=value-cost
        totals['value']+=value; totals['cost']+=cost; totals['pv']+=pv_used; totals['grid']+=grid; totals['charge']+=batt_ch; totals['discharge']+=batt_dis
        rows.append({'timestamp':s['timestamp'],'grid_price_eur_kwh':price,'pv_kw':pv,'selected_assets':[a['name'] for a in chosen],'selected_power_kw':round(load,3),'pv_used_kw':round(pv_used,3),'battery_charge_kw':round(batt_ch,3),'battery_discharge_kw':round(batt_dis,3),'soc_kwh':round(soc,3),'grid_import_kw':round(grid,3),'value_eur':round(value,3),'energy_cost_eur':round(cost,3),'net_margin_eur':round(net,3),'forecast_source':s['source']})
    return {'farm_id':farm.id,'horizon_hours':horizon,'generated_at':datetime.now(timezone.utc),'assumptions':{'market_btc_eur':market.get('btc_eur'),'network_hashrate_eh':market.get('network_hashrate_eh'),'dispatch':'forecast-aware economic dispatch; read-only simulation','battery_reserve_pct':10,'note':'Uses stored provider forecasts when available and falls back per slot.'},'summary':{'value_eur':round(totals['value'],2),'energy_cost_eur':round(totals['cost'],2),'net_margin_eur':round(totals['value']-totals['cost'],2),'pv_used_kwh':round(totals['pv'],2),'grid_import_kwh':round(totals['grid'],2),'battery_charge_kwh':round(totals['charge'],2),'battery_discharge_kwh':round(totals['discharge'],2),'ending_battery_soc_kwh':round(soc,2)},'assets':assets,'slots':rows}




def _scenario_price(base, confidence, direction):
    # Price uncertainty is asymmetric to avoid understating expensive-hour risk.
    c=max(10.0,min(95.0,float(confidence or 70)))
    spread=max(0.08, min(0.35, (100-c)/100*0.75))
    if direction=='low': return max(-0.20, base*(1-spread))
    if direction=='high': return base*(1+spread*1.25)
    return base


def _scenario_pv(base, confidence, direction):
    c=max(10.0,min(95.0,float(confidence or 70)))
    spread=max(0.08, min(0.55, (100-c)/100*1.15))
    if direction=='low': return max(0.0, base*(1-spread))
    if direction=='high': return base*(1+spread*0.75)
    return max(0.0, base)


def _dispatch_given_scenario(slots, assets, profile, scenario, risk_reserve=True):
    battery_kwh=float(profile.battery_capacity_kwh if profile else 0)
    soc=float((profile.battery_soc_pct/100*battery_kwh) if profile else 0)
    rte=max(.5,min(1.0,float(profile.battery_roundtrip_efficiency_pct or 90)/100)) if profile else .9
    reserve=battery_kwh*0.10 if risk_reserve else 0
    max_grid=float(profile.max_grid_import_kw if profile and profile.max_grid_import_kw is not None else 1e9)
    rows=[]; net=0.0
    for i,s in enumerate(slots):
        price=_scenario_price(float(s['grid_price_eur_kwh']),s.get('confidence_pct'),scenario)
        pv=_scenario_pv(float(s.get('pv_kw',0)),s.get('confidence_pct'),scenario)
        chosen=[]; remaining=max_grid
        # Scenario-aware asset selection: use conservative high price / low PV for downside.
        for a in assets:
            threshold=price
            if scenario=='low' and a['kind']=='bitcoin_mining': threshold*=1.05
            if a['power_kw']<=remaining and a['gross_value_eur_kwh']>threshold:
                chosen.append(a); remaining-=a['power_kw']
        load=sum(a['power_kw'] for a in chosen)
        pv_used=min(pv,load); residual=max(0,load-pv_used)
        dis=0.0; ch=0.0
        future_prices=[_scenario_price(float(x['grid_price_eur_kwh']),x.get('confidence_pct'),scenario) for x in slots[i:min(i+7,len(slots))]]
        future=max(future_prices) if future_prices else price
        if residual and battery_kwh and soc>reserve and (price>=future*.97 or scenario=='high'):
            dis=min(residual,(soc-reserve)*rte); soc-=dis/rte; residual-=dis
        if pv>pv_used and battery_kwh and soc<battery_kwh:
            ch=min(pv-pv_used,battery_kwh-soc); soc+=ch*rte
        grid=max(0,residual)
        if grid>max_grid:
            for a in sorted(chosen,key=lambda x:x['gross_value_eur_kwh']):
                if grid<=max_grid: break
                chosen.remove(a); load-=a['power_kw']; pv_used=min(pv,load); grid=max(0,load-pv_used-dis)
        value=sum(a['power_kw']*a['gross_value_eur_kwh'] for a in chosen)
        margin=value-grid*price
        net+=margin
        rows.append({'timestamp':s['timestamp'],'price':price,'pv_kw':pv,'grid_kw':grid,'load_kw':load,'net_margin_eur':margin,'soc_kwh':soc,'assets':[a['name'] for a in chosen]})
    return {'net_margin_eur':net,'slots':rows,'ending_soc_kwh':soc}


def probabilistic_optimize(db: Session, farm, market, horizon=168, risk_aversion=0.35):
    horizon=max(1,min(int(horizon),168)); risk_aversion=max(0,min(float(risk_aversion),1))
    slots=_forecast_slots(db,farm,horizon); profile=db.query(EnergyProfile).filter_by(farm_id=farm.id).first(); assets=_assets(db,farm,market)
    scenarios={k:_dispatch_given_scenario(slots,assets,profile,k,True) for k in ('low','base','high')}
    vals={k:v['net_margin_eur'] for k,v in scenarios.items()}
    # Conservative objective: expected value minus downside-risk penalty.
    expected=.25*vals['low']+.50*vals['base']+.25*vals['high']
    downside=max(0,vals['base']-vals['low'])
    objective=expected-risk_aversion*downside
    # Recommend the base dispatch only when it survives a downside hurdle.
    downside_floor=vals['low']
    recommendation='RUN_BASE_DISPATCH' if objective>0 and downside_floor>-max(0.0,abs(vals['base'])*0.35) else 'CONSERVATIVE_DISPATCH'
    # Hourly robust action: require the asset to be profitable in the low scenario to be marked robust.
    robust=[]
    for i,b in enumerate(scenarios['base']['slots']):
        l=scenarios['low']['slots'][i]; h=scenarios['high']['slots'][i]
        robust.append({'timestamp':b['timestamp'],'base_margin_eur':round(b['net_margin_eur'],3),'low_margin_eur':round(l['net_margin_eur'],3),'high_margin_eur':round(h['net_margin_eur'],3),'base_assets':b['assets'],'robust':l['net_margin_eur']>=0})
    confidence=sum(float(x.get('confidence_pct') or 70) for x in slots)/len(slots) if slots else 0
    return {'farm_id':farm.id,'horizon_hours':horizon,'risk_aversion':risk_aversion,'generated_at':datetime.now(timezone.utc),
            'scenario_summary':{k:{'net_margin_eur':round(v['net_margin_eur'],2),'ending_battery_soc_kwh':round(v['ending_soc_kwh'],2)} for k,v in scenarios.items()},
            'expected_net_margin_eur':round(expected,2),'downside_risk_eur':round(downside,2),'risk_adjusted_objective_eur':round(objective,2),
            'forecast_confidence_pct':round(confidence,1),'recommendation':recommendation,'hourly':robust,
            'note':'Probabilistic read-only simulation. Low/base/high scenarios are uncertainty bands around stored forecasts; no control commands are sent to miners.'}
