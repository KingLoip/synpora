import json
import urllib.request
from .config import DISCORD_WEBHOOK_URL, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

def _post(url, payload):
    data=json.dumps(payload).encode()
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=8) as r:
        return r.status

def notify(message):
    results={}
    if DISCORD_WEBHOOK_URL:
        try: results['discord']=_post(DISCORD_WEBHOOK_URL,{'content':message})
        except Exception as e: results['discord']=f'error:{e}'
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        try:
            results['telegram']=_post(f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage',{'chat_id':TELEGRAM_CHAT_ID,'text':message})
        except Exception as e: results['telegram']=f'error:{e}'
    return results
