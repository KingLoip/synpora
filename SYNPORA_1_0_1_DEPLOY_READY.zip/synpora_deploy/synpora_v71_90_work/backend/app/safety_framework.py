import json, sqlite3, uuid
from datetime import datetime, timezone

def ensure_safety_tables(db):
    db.execute("""CREATE TABLE IF NOT EXISTS safety_actions(
        id TEXT PRIMARY KEY, farm_id TEXT, action TEXT, requested_kw REAL,
        confidence REAL, status TEXT, reason TEXT, created_at TEXT,
        approved_at TEXT, executed_at TEXT, verified_at TEXT
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS safety_limits(
        farm_id TEXT PRIMARY KEY, max_power_kw REAL DEFAULT 100,
        min_soc_pct REAL DEFAULT 15, max_soc_pct REAL DEFAULT 95,
        min_confidence REAL DEFAULT 0.70, max_energy_price_eur_kwh REAL DEFAULT 1.00,
        kill_switch INTEGER DEFAULT 0
    )""")
    db.commit()

def get_limits(db, farm_id):
    ensure_safety_tables(db)
    row = db.execute("SELECT * FROM safety_limits WHERE farm_id=?", (farm_id,)).fetchone()
    if row:
        cols=[d[0] for d in db.execute("PRAGMA table_info(safety_limits)")]
        return dict(zip(cols,row))
    db.execute("INSERT OR IGNORE INTO safety_limits(farm_id) VALUES(?)",(farm_id,))
    db.commit()
    row=db.execute("SELECT * FROM safety_limits WHERE farm_id=?", (farm_id,)).fetchone()
    cols=[d[1] for d in db.execute("PRAGMA table_info(safety_limits)")]
    return dict(zip(cols,row))

def create_action(db, farm_id, proposal):
    ensure_safety_tables(db)
    limits=get_limits(db,farm_id)
    reasons=[]
    if limits["kill_switch"]: reasons.append("KILL_SWITCH")
    if float(proposal.get("requested_kw",0)) > float(limits["max_power_kw"]): reasons.append("POWER_LIMIT")
    if float(proposal.get("confidence",0)) < float(limits["min_confidence"]): reasons.append("CONFIDENCE_GATE")
    status="BLOCKED" if reasons else "PROPOSED"
    aid=str(uuid.uuid4())
    db.execute("""INSERT INTO safety_actions
        (id,farm_id,action,requested_kw,confidence,status,reason,created_at)
        VALUES(?,?,?,?,?,?,?,?)""",
        (aid,farm_id,proposal.get("action","HOLD"),proposal.get("requested_kw",0),
         proposal.get("confidence",0),status,";".join(reasons) or "PASS",
         datetime.now(timezone.utc).isoformat()))
    db.commit()
    return {"action_id":aid,"status":status,"reasons":reasons or ["PASS"],
            "approval_required":True,"control_commands_sent":False}

def approve_action(db, action_id):
    ensure_safety_tables(db)
    now=datetime.now(timezone.utc).isoformat()
    db.execute("UPDATE safety_actions SET status='APPROVED',approved_at=? WHERE id=? AND status='PROPOSED'",(now,action_id))
    db.commit()
    return db.execute("SELECT * FROM safety_actions WHERE id=?",(action_id,)).fetchone()

def kill_switch(db,farm_id,enabled=True):
    ensure_safety_tables(db)
    db.execute("INSERT OR IGNORE INTO safety_limits(farm_id) VALUES(?)",(farm_id,))
    db.execute("UPDATE safety_limits SET kill_switch=? WHERE farm_id=?",(1 if enabled else 0,farm_id))
    db.commit()
    return {"farm_id":farm_id,"kill_switch":bool(enabled),"control_commands_sent":False}
def ensure(db=None): return {'ok':True,'control_enabled':False}
def evaluate(state=None, constraints=None): return {'allowed':False,'mode':'recommendation_only','reason':'Hardware control disabled by default.'}
