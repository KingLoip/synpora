import os, hashlib, secrets
from dotenv import load_dotenv
load_dotenv()
CORS_ORIGINS=[x.strip() for x in os.getenv('SYNPORA_CORS_ORIGINS','*').split(',') if x.strip()]
DATABASE_URL=os.getenv('SYNPORA_DATABASE_URL') or os.getenv('DATABASE_URL','sqlite:///./synpora.db')
POLL_INTERVAL_SECONDS=int(os.getenv('SYNPORA_POLL_INTERVAL_SECONDS','60'))
ALERT_COOLDOWN_SECONDS=int(os.getenv('SYNPORA_ALERT_COOLDOWN_SECONDS','1800'))
TEMP_WARN_C=float(os.getenv('SYNPORA_TEMP_WARN_C','80'))
TEMP_CRIT_C=float(os.getenv('SYNPORA_TEMP_CRIT_C','90'))
HASHRATE_WARN_PCT=float(os.getenv('SYNPORA_HASHRATE_WARN_PCT','15'))
POWER_WARN_PCT=float(os.getenv('SYNPORA_POWER_WARN_PCT','15'))
TELEGRAM_BOT_TOKEN=os.getenv('SYNPORA_TELEGRAM_BOT_TOKEN','')
TELEGRAM_CHAT_ID=os.getenv('SYNPORA_TELEGRAM_CHAT_ID','')
DISCORD_WEBHOOK_URL=os.getenv('SYNPORA_DISCORD_WEBHOOK_URL','')
NOTIFY_SEVERITIES={x.strip().lower() for x in os.getenv('SYNPORA_NOTIFY_SEVERITIES','critical,warning').split(',') if x.strip()}

CONNECT_TIMEOUT=float(os.getenv('SYNPORA_CONNECT_TIMEOUT','5'))

BOOTSTRAP_EMAIL=os.getenv('SYNPORA_BOOTSTRAP_EMAIL','admin@synpora.com')
BOOTSTRAP_PASSWORD=os.getenv('SYNPORA_BOOTSTRAP_PASSWORD','')
# Production convenience: if Railway secrets are not supplied, derive stable secrets from the bootstrap password.
# A bootstrap password should always be configured before exposing the service publicly.
_secret_seed=BOOTSTRAP_PASSWORD or secrets.token_urlsafe(48)
API_KEY=os.getenv('SYNPORA_API_KEY') or hashlib.sha256(('synpora-api:'+_secret_seed).encode()).hexdigest()
JWT_SECRET=os.getenv('SYNPORA_JWT_SECRET') or hashlib.sha256(('synpora-jwt:'+_secret_seed).encode()).hexdigest()
JWT_EXPIRE_HOURS=int(os.getenv('SYNPORA_JWT_EXPIRE_HOURS','24'))
BOOTSTRAP_SECRET=os.getenv('SYNPORA_BOOTSTRAP_SECRET') or hashlib.sha256(('synpora-bootstrap:'+_secret_seed).encode()).hexdigest()

ENERGY_PRICE_PROVIDER=os.getenv('SYNPORA_ENERGY_PRICE_PROVIDER','energy-charts')
ENERGY_CHARTS_URL=os.getenv('SYNPORA_ENERGY_CHARTS_URL','https://api.energy-charts.info')
ENTSOE_API_TOKEN=os.getenv('SYNPORA_ENTSOE_API_TOKEN','')
OPEN_METEO_URL=os.getenv('SYNPORA_OPEN_METEO_URL','https://api.open-meteo.com/v1/forecast')
FORECAST_REFRESH_MINUTES=int(os.getenv('SYNPORA_FORECAST_REFRESH_MINUTES','30'))
PV_SYSTEM_EFFICIENCY=float(os.getenv('SYNPORA_PV_SYSTEM_EFFICIENCY','0.85'))

# International energy price provider settings
SYNPORA_GLOBAL_PRICE_URL=os.getenv('SYNPORA_GLOBAL_PRICE_URL','')
SYNPORA_GLOBAL_PRICE_TOKEN=os.getenv('SYNPORA_GLOBAL_PRICE_TOKEN','')

FX_API_URL=os.getenv('SYNPORA_FX_API_URL','https://api.frankfurter.app/latest')
FX_BASE_CURRENCY=os.getenv('SYNPORA_FX_BASE_CURRENCY','EUR')
FORECAST_ACCURACY_MIN_SAMPLES=int(os.getenv('SYNPORA_FORECAST_ACCURACY_MIN_SAMPLES','5'))

# Dynamic tariff providers (v11)
AWATTAR_ENABLED=os.getenv('SYNPORA_AWATTAR_ENABLED','false').lower() in ('1','true','yes','on')
AWATTAR_URL=os.getenv('SYNPORA_AWATTAR_URL','https://api.awattar.at/v1/marketdata')
AWATTAR_MARKUP_CT_KWH=float(os.getenv('SYNPORA_AWATTAR_MARKUP_CT_KWH','0'))
AWATTAR_VAT=float(os.getenv('SYNPORA_AWATTAR_VAT','0'))

# v28: optional authenticated Vast.ai capacity/offer integration
VAST_API_KEY=os.getenv('SYNPORA_VAST_API_KEY','')
VAST_API_URL=os.getenv('SYNPORA_VAST_API_URL','https://cloud.vast.ai/api/v0/bundles/')
GRIDCOMPUTE_URL=os.getenv('SYNPORA_GRIDCOMPUTE_URL','https://gridcompute.ai/api/latest')
