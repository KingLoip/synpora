
from datetime import datetime, timezone

def score_source(source, age_minutes=None, live=False):
    s=(source or "").lower()
    score=50
    if live: score+=25
    if "mempool" in s or "d-central" in s: score+=15
    if "gridcompute" in s or "vast" in s: score+=10
    if age_minutes is not None:
        if age_minutes<=15: score+=10
        elif age_minutes>180: score-=20
    return max(0,min(100,score))

def provenance(source, live, age_minutes=None, quote_type="market"):
    return {
        "source":source,"live":bool(live),"age_minutes":age_minutes,
        "quality_score":score_source(source,age_minutes,live),
        "quote_type":quote_type,
        "generated_at":datetime.now(timezone.utc).isoformat(),
        "warning":"Market ask/rate is not guaranteed realized revenue." if quote_type=="market" else None
    }
