from datetime import datetime, timezone
from .models import Farm, Miner, Telemetry, EnergyProfile, EnergyTariff, ComputeOption
from .services import mining_decision

def current_energy_price(db, farm):
    p=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    base=p.grid_import_price_eur_kwh if p else farm.electricity_price_eur_kwh
    now=datetime.now().astimezone(); wd=now.weekday(); h=now.hour
    rows=db.query(EnergyTariff).filter(EnergyTariff.farm_id==farm.id).all()
    matches=[x for x in rows if (x.weekday==-1 or x.weekday==wd) and x.start_hour<=h<x.end_hour]
    if matches: base=matches[-1].price_eur_kwh
    return base

def energy_context(db,farm):
    p=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    price=current_energy_price(db,farm)
    return {'grid_price_eur_kwh':price,'pv_capacity_kw':p.pv_capacity_kw if p else 0,'battery_capacity_kwh':p.battery_capacity_kwh if p else 0,'battery_soc_pct':p.battery_soc_pct if p else 0,'max_grid_import_kw':p.max_grid_import_kw if p else farm.power_limit_kw}

async def optimize_farm(db,farm,market):
    ctx=energy_context(db,farm); btc=market.get('btc_eur') or 0; network=market.get('network_hashrate_eh') or 0
    rec=[]; total_profit=0; total_power=0
    for m in farm.miners:
        t=db.query(Telemetry).filter_by(miner_id=m.id).order_by(Telemetry.timestamp.desc()).first()
        h=(t.hashrate_ths if t and t.hashrate_ths else m.hashrate_ths); power=(t.power_w if t and t.power_w else m.power_w)
        if not btc or not network: continue
        d=mining_decision(h,power,btc,network,3.125,0,100,ctx['grid_price_eur_kwh'])
        total_profit += d.profit_eur_day; total_power += power/1000
        rec.append({'type':'bitcoin_mining','miner_id':m.id,'name':m.name,'recommendation':d.action,'reason':d.reason,'profit_eur_day':round(d.profit_eur_day,2),'value_eur_kwh':round(d.revenue_eur_day/(power/1000*24),4) if power else 0,'power_kw':round(power/1000,3),'efficiency_j_th':round(d.efficiency_j_th,2)})
    computes=db.query(ComputeOption).filter_by(farm_id=farm.id,enabled=1).all()
    for c in computes:
        net=c.gross_revenue_eur_hour-c.variable_cost_eur_hour
        value=(net/(c.power_kw)) if c.power_kw else 0
        value_adj=value*(c.availability_pct/100)
        rec.append({'type':'ai_compute','compute_id':c.id,'name':c.name,'workload':c.workload,'recommendation':'AI_COMPUTE' if value_adj>ctx['grid_price_eur_kwh'] else 'NICHT_STARTEN','reason':f'Netto-Wert {value_adj:.3f} €/kWh vs. Energiepreis {ctx["grid_price_eur_kwh"]:.3f} €/kWh.','value_eur_kwh':round(value_adj,4),'power_kw':c.power_kw,'profit_eur_hour':round(net*(c.availability_pct/100),2)})
    best=max([r for r in rec if r.get('value_eur_kwh') is not None],key=lambda x:x['value_eur_kwh'],default=None)
    score=max(0,min(100,round((best['value_eur_kwh']/max(ctx['grid_price_eur_kwh'],.0001))*70))) if best else 0
    return {'farm_id':farm.id,'energy':ctx,'market':market,'optimization_score':score,'grade':'A' if score>=85 else 'B' if score>=70 else 'C' if score>=50 else 'D','total_mining_profit_eur_day':round(total_profit,2),'total_mining_power_kw':round(total_power,2),'best_use_of_kwh':best,'recommendations':rec}
