from datetime import datetime, timezone, timedelta
import json, os, shutil, subprocess
from sqlalchemy import text
from sqlalchemy.orm import Session


def ensure_telemetry_table(db: Session):
    db.execute(text('''CREATE TABLE IF NOT EXISTS compute_telemetry (
      id INTEGER PRIMARY KEY AUTOINCREMENT, asset_id INTEGER NOT NULL, timestamp DATETIME NOT NULL,
      utilization_pct FLOAT, memory_utilization_pct FLOAT, temperature_c FLOAT, power_w FLOAT,
      fan_pct FLOAT, memory_used_mb FLOAT, process_count INTEGER, source VARCHAR(80), error TEXT
    )'''))
    db.commit()


def _num(v):
    try: return float(v) if v is not None and v != '' else None
    except Exception: return None


def record_telemetry(db, asset_id, payload, source='api'):
    ensure_telemetry_table(db)
    ts=payload.get('timestamp') or datetime.now(timezone.utc).isoformat()
    db.execute(text('''INSERT INTO compute_telemetry
      (asset_id,timestamp,utilization_pct,memory_utilization_pct,temperature_c,power_w,fan_pct,memory_used_mb,process_count,source,error)
      VALUES (:asset_id,:timestamp,:utilization_pct,:memory_utilization_pct,:temperature_c,:power_w,:fan_pct,:memory_used_mb,:process_count,:source,:error)'''),
      {'asset_id':asset_id,'timestamp':ts,'utilization_pct':_num(payload.get('utilization_pct')),
       'memory_utilization_pct':_num(payload.get('memory_utilization_pct')),'temperature_c':_num(payload.get('temperature_c')),
       'power_w':_num(payload.get('power_w')),'fan_pct':_num(payload.get('fan_pct')),
       'memory_used_mb':_num(payload.get('memory_used_mb')),'process_count':int(payload.get('process_count') or 0),
       'source':source,'error':payload.get('error')})
    db.commit()


def list_telemetry(db, asset_id=None, farm_id=None, limit=100):
    ensure_telemetry_table(db)
    params={'limit':max(1,min(int(limit),1000))}
    if asset_id is not None:
        q='SELECT t.* FROM compute_telemetry t WHERE t.asset_id=:asset_id ORDER BY t.timestamp DESC LIMIT :limit'; params['asset_id']=asset_id
    elif farm_id is not None:
        q='''SELECT t.* FROM compute_telemetry t JOIN compute_assets a ON a.id=t.asset_id
             WHERE a.farm_id=:farm_id ORDER BY t.timestamp DESC LIMIT :limit'''; params['farm_id']=farm_id
    else: q='SELECT * FROM compute_telemetry ORDER BY timestamp DESC LIMIT :limit'
    return [dict(r._mapping) for r in db.execute(text(q),params)]


def probe_nvidia(asset_id=None):
    if os.getenv('SYNPORA_NVIDIA_TELEMETRY_ENABLED','false').lower() not in ('1','true','yes','on'):
        return {'enabled':False,'source':'nvidia-smi','error':'NVIDIA telemetry probe disabled; set SYNPORA_NVIDIA_TELEMETRY_ENABLED=true on the telemetry host.'}
    exe=shutil.which('nvidia-smi')
    if not exe: return {'enabled':True,'source':'nvidia-smi','error':'nvidia-smi not found on this host'}
    fields='index,utilization.gpu,utilization.memory,temperature.gpu,power.draw,fan.speed,memory.used,memory.total'
    try:
        p=subprocess.run([exe,f'--query-gpu={fields}','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=8,check=True)
        rows=[]
        for idx,line in enumerate(p.stdout.strip().splitlines()):
            vals=[x.strip() for x in line.split(',')]
            if len(vals)<8: continue
            rows.append({'gpu_index':int(float(vals[0])),'asset_id':asset_id,'utilization_pct':_num(vals[1]),'memory_utilization_pct':_num(vals[2]),
                         'temperature_c':_num(vals[3]),'power_w':_num(vals[4]),'fan_pct':_num(vals[5]),'memory_used_mb':_num(vals[6]),
                         'memory_total_mb':_num(vals[7]),'process_count':0,'timestamp':datetime.now(timezone.utc).isoformat()})
        return {'enabled':True,'source':'nvidia-smi','rows':rows}
    except Exception as e: return {'enabled':True,'source':'nvidia-smi','error':str(e)}


def telemetry_freshness(rows, max_age_minutes=10):
    if not rows: return {'status':'missing','score':0,'age_minutes':None}
    ts=rows[0].get('timestamp')
    try:
        dt=datetime.fromisoformat(str(ts).replace('Z','+00:00')); age=max(0,(datetime.now(timezone.utc)-dt).total_seconds()/60)
    except Exception: age=None
    score=100 if age is not None and age<=max_age_minutes else max(0,round(100-(age or 999)*2))
    return {'status':'fresh' if score>=80 else 'stale','score':score,'age_minutes':age}
