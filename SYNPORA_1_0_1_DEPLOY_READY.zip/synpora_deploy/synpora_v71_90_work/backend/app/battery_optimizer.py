from datetime import datetime, timezone, timedelta
def optimize_battery(hours,energy_slots,soc_pct,capacity_kwh,max_charge_kw,max_discharge_kw,reserve_pct=10):
    soc=max(0,min(100,float(soc_pct or 0))); cap=max(0,float(capacity_kwh or 0)); ch=max(0,float(max_charge_kw or 0)); dis=max(0,float(max_discharge_kw or 0)); reserve=max(0,min(90,float(reserve_pct or 0))); rows=[]; total=0
    for i in range(max(1,min(int(hours),168))):
        e=energy_slots[i] if i<len(energy_slots) else (energy_slots[-1] if energy_slots else {}); price=float(e.get('grid_price_eur_kwh') or 0); pv=float(e.get('pv_kw') or 0); soc_kwh=cap*soc/100 if cap else 0; decision='HOLD'; power=0
        if cap:
            if pv>0 and soc<100-reserve: decision='CHARGE_PV'; power=min(ch,pv,cap-soc_kwh)
            elif price>0.18 and soc>reserve: decision='DISCHARGE_GRID'; power=min(dis,soc_kwh)
            elif price<0.08 and soc<100-reserve: decision='CHARGE_GRID'; power=min(ch,cap-soc_kwh)
        if decision.startswith('CHARGE'): soc=min(100,soc+(power/cap*100 if cap else 0)); value=0
        elif decision=='DISCHARGE_GRID': soc=max(reserve,soc-(power/cap*100 if cap else 0)); value=power*price
        else:value=0
        total+=value; rows.append({'timestamp':(datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)+timedelta(hours=i)).isoformat(),'decision':decision,'power_kw':power,'soc_pct':soc,'grid_price_eur_kwh':price,'pv_kw':pv,'value_eur':value})
    return {'version':'37.0','rows':rows,'total_opportunity_value_eur':total,'approval_required':True,'control_commands_sent':False}
