
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from .models import Farm, EnergyProfile, Miner

def _farm_caps(db,farm):
    p=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
    mining_kw=sum(float(m.power_w or 0) for m in farm.miners)/1000
    compute_kw=0.0
    if p and p.max_grid_import_kw is not None: grid=float(p.max_grid_import_kw)
    else: grid=float(farm.power_limit_kw or mining_kw or 0)
    return p,mining_kw,compute_kw,grid

def allocate_portfolio(db:Session,farm_id:int,mining_forecast:dict,compute_quotes:list,
                       hours:int=24,risk_aversion:float=.25,step_kw:float=1.0):
    farm=db.get(Farm,farm_id)
    if not farm: raise ValueError("Farm not found")
    p,mining_cap,compute_cap,grid_cap=_farm_caps(db,farm)
    if p and p.max_grid_import_kw is not None: grid_cap=float(p.max_grid_import_kw)
    slots={}
    for s in mining_forecast.get("slots",[]):
        if s["scenario"]=="base": slots[s["timestamp"]]=s
    # Best available compute quote: median of real public market rows.
    qvals=[float(q.get("risk_adjusted_value_eur_kwh") or 0) for q in compute_quotes if q.get("risk_adjusted_value_eur_kwh") is not None]
    best_compute=max(qvals) if qvals else 0
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    rows=[]; total=0
    for i in range(max(1,min(hours,168))):
        ts=(now+timedelta(hours=i)).isoformat()
        s=slots.get(ts) or {}
        hp=float(s.get("hashprice_eur_th_day") or 0)
        mining_value=hp
        # hp is €/TH/day; convert each farm's weighted mining value to €/kWh.
        mining_value_kwh=0
        miners=db.query(__import__("app.models",fromlist=["Miner"]).Miner).filter_by(farm_id=farm_id).all()
        if miners:
            vals=[]
            for m in miners:
                kw=float(m.power_w or 0)/1000; th=float(m.hashrate_ths or 0)
                if kw: vals.append(hp*th/(kw*24))
            mining_value_kwh=sum(vals)/len(vals) if vals else 0
        grid_price=float(getattr(p,"grid_import_price_eur_kwh",None) if p else None) if (p and p.grid_import_price_eur_kwh is not None) else float(farm.electricity_price_eur_kwh or 0)
        # PV and battery are reserved in the model; no auto-control.
        net_mining=mining_value_kwh-grid_price
        net_compute=best_compute-grid_price
        if max(net_mining,net_compute) <= 0:
            action="IDLE"; mk=ck=0
        elif net_mining >= net_compute:
            action="BTC_MINING"; mk=min(mining_cap,grid_cap); ck=0
        else:
            action="AI_COMPUTE"; mk=0; ck=min(compute_cap or grid_cap,grid_cap)
        margin=max(net_mining,net_compute,0)*(mk+ck)
        total+=margin
        rows.append({"timestamp":ts,"grid_price_eur_kwh":grid_price,"mining_value_eur_kwh":mining_value_kwh,
                     "compute_value_eur_kwh":best_compute,"mining_kw":mk,"compute_kw":ck,
                     "battery_charge_kw":0,"battery_discharge_kw":0,"pv_kw":0,"grid_import_kw":mk+ck,
                     "curtail_kw":0,"decision":action,"expected_net_margin_eur":margin,
                     "risk_adjusted":True,"approval_required":True,"control_commands_sent":False})
    return {"version":"27.0","farm_id":farm_id,"generated_at":datetime.now(timezone.utc).isoformat(),
            "horizon_hours":len(rows),"total_expected_net_margin_eur":total,
            "constraints":{"grid_cap_kw":grid_cap,"mining_cap_kw":mining_cap,"step_kw":step_kw},
            "rows":rows,"mode":"simulation_only","approval_required":True,"control_commands_sent":False}
