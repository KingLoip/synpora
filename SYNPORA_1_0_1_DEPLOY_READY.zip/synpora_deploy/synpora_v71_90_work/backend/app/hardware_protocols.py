import time, urllib.request, json

ADAPTERS={}
def register_adapter(name, kind, config=None):
    ADAPTERS[name]={"name":name,"kind":kind,"config":config or {},"read_only":True}
    return ADAPTERS[name]

def list_adapters():
    return list(ADAPTERS.values())

def rest_probe(url, timeout=3):
    try:
        req=urllib.request.Request(url, method="GET", headers={"User-Agent":"SYNPORA/56"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return {"ok":True,"status":r.status,"latency_ms":None,"read_only":True}
    except Exception as e:
        return {"ok":False,"error":str(e),"read_only":True}

def modbus_register_map(unit_id=1, registers=None):
    return {"protocol":"modbus_tcp","unit_id":unit_id,
            "registers":registers or [],"read_only":True,
            "write_enabled":False}
