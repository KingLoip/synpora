
from datetime import datetime, timezone
from sqlalchemy import text
from sqlalchemy.orm import Session

ASSET_TYPES=("gpu","asic")

def ensure_asset_table(db:Session):
    db.execute(text("""
    CREATE TABLE IF NOT EXISTS compute_assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      farm_id INTEGER NOT NULL,
      name VARCHAR(120) NOT NULL,
      asset_type VARCHAR(20) NOT NULL DEFAULT 'gpu',
      model VARCHAR(120),
      quantity INTEGER NOT NULL DEFAULT 1,
      power_kw FLOAT NOT NULL,
      capacity_units FLOAT NOT NULL DEFAULT 1,
      compute_market_key VARCHAR(120),
      enabled INTEGER NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    )
    """))
    db.commit()

def create_asset(db,farm_id, data):
    ensure_asset_table(db)
    now=datetime.now(timezone.utc).isoformat()
    db.execute(text("""INSERT INTO compute_assets
      (farm_id,name,asset_type,model,quantity,power_kw,capacity_units,compute_market_key,enabled,created_at)
      VALUES (:farm_id,:name,:asset_type,:model,:quantity,:power_kw,:capacity_units,:compute_market_key,:enabled,:created_at)"""),
      {"farm_id":farm_id,**data,"created_at":now})
    db.commit()

def list_assets(db,farm_id):
    ensure_asset_table(db)
    return [dict(r._mapping) for r in db.execute(text(
        "SELECT * FROM compute_assets WHERE farm_id=:f ORDER BY id"),{"f":farm_id})]

def update_asset(db,asset_id, data):
    ensure_asset_table(db)
    allowed={k:v for k,v in data.items() if k in
             {"name","asset_type","model","quantity","power_kw","capacity_units","compute_market_key","enabled"}}
    if not allowed:return
    sets=", ".join(f"{k}=:{k}" for k in allowed)
    allowed["id"]=asset_id
    db.execute(text(f"UPDATE compute_assets SET {sets} WHERE id=:id"),allowed);db.commit()
