from statistics import mean
def build_report(samples, decisions):
    n=len(samples)
    good=sum(1 for s in samples if s.get("quality")=="GOOD")
    values=[float(d.get("net_value_eur_kwh",0)) for d in decisions]
    return {
        "samples":n,
        "good_quality_ratio":good/max(n,1),
        "decision_count":len(decisions),
        "avg_decision_value_eur_kwh":mean(values) if values else 0,
        "best_decision_value_eur_kwh":max(values) if values else 0,
        "readiness_hint": n>=100 and good/max(n,1)>=0.95
    }
