from datetime import datetime, timezone

def build_plan(decision,confidence,limits=None):
    limits=limits or {}; action=decision if confidence>=float(limits.get('min_confidence',70)) else 'HOLD'
    return {'engine':'SYNPORA_AUTONOMOUS_PLANNER','version':'50.0','action':action,'confidence_pct':round(confidence,2),'approval_required':True,'control_commands_sent':False,'safety_gates':{'min_confidence':float(limits.get('min_confidence',70)),'max_power_kw':limits.get('max_power_kw'),'manual_approval':True,'kill_switch':True},'generated_at':datetime.now(timezone.utc).isoformat()}
