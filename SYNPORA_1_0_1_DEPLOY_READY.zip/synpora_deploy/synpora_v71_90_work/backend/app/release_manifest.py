def manifest(version, modules):
    return {"version":version,"modules":modules,"production_control_enabled":False,
            "release_policy":"read-only by default; manual approval required"}
