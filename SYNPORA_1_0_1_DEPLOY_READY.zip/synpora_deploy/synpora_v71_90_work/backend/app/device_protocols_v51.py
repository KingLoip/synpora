from datetime import datetime, timezone
import json, urllib.request
from sqlalchemy import text

def ensure_hardware_protocol_v51(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS device_protocol_v51 (id INTEGER PRIMARY KEY, farm_id INTEGER NOT NULL, name VARCHAR(120), protocol VARCHAR(30), host VARCHAR(255), port INTEGER, unit_id INTEGER DEFAULT 1, register_map_json TEXT, enabled INTEGER DEFAULT 1, last_seen DATETIME, last_status VARCHAR(40), last_error TEXT)''')); db.commit()

def register(db,farm_id,data):
    ensure_hardware_protocol_v51(db)
    r=db.execute(text('INSERT INTO device_protocol_v51(farm_id,name,protocol,host,port,unit_id,register_map_json,enabled,last_status) VALUES(:f,:n,:p,:h,:port,:u,:m,:e,:s)'),{'f':farm_id,'n':data.get('name','device'),'p':data.get('protocol','rest'),'h':data.get('host') or data.get('endpoint'),'port':int(data.get('port') or (80 if data.get('protocol','rest')=='rest' else 502)),'u':int(data.get('unit_id',1)),'m':json.dumps(data.get('register_map',{})),'e':1 if data.get('enabled',True) else 0,'s':'registered'}); db.commit(); return get(db,r.lastrowid)

def get(db,i):
    ensure_hardware_protocol_v51(db); r=db.execute(text('SELECT * FROM device_protocol_v51 WHERE id=:i'),{'i':i}).mappings().first()
    if not r:return None
    d=dict(r); d['enabled']=bool(d['enabled']); d['register_map']=json.loads(d.pop('register_map_json') or '{}'); return d

def list_all(db,farm_id):
    ensure_hardware_protocol_v51(db); return [get(db,x['id']) for x in db.execute(text('SELECT id FROM device_protocol_v51 WHERE farm_id=:f ORDER BY id'),{'f':farm_id}).mappings().all()]

def _rest_read(url,timeout=5):
    req=urllib.request.Request(url,headers={'Accept':'application/json'}); 
    with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode())

def probe(db,protocol_id):
    d=get(db,protocol_id)
    if not d: raise ValueError('Protocol not found')
    if not d['enabled']: raise ValueError('Protocol disabled')
    try:
        if d['protocol'].lower()=='rest': data=_rest_read(d['host'])
        elif d['protocol'].lower()=='modbus_tcp':
            try:
                from pymodbus.client import ModbusTcpClient
            except Exception as e: raise RuntimeError('pymodbus not installed; Modbus adapter is optional') from e
            client=ModbusTcpClient(d['host'],port=d['port'],timeout=5); 
            if not client.connect(): raise RuntimeError('Modbus connection failed')
            out={}
            for name,spec in d['register_map'].items():
                addr=int(spec.get('address',0)); count=int(spec.get('count',1)); typ=spec.get('type','holding')
                rr=getattr(client,'read_input_registers' if typ=='input' else 'read_holding_registers')(address=addr,count=count,slave=d['unit_id'])
                if rr.isError(): out[name]=None
                else: out[name]=rr.registers[0] if count==1 else rr.registers
            client.close(); data=out
        else: raise ValueError('Unsupported protocol')
        db.execute(text('UPDATE device_protocol_v51 SET last_seen=:t,last_status="online",last_error=NULL WHERE id=:i'),{'t':datetime.now(timezone.utc),'i':protocol_id}); db.commit(); return {'protocol':d['protocol'],'data':data,'read_only':True}
    except Exception as e:
        db.execute(text('UPDATE device_protocol_v51 SET last_status="error",last_error=:e WHERE id=:i'),{'e':str(e),'i':protocol_id}); db.commit(); raise
