from datetime import datetime, timezone, timedelta
from sqlalchemy import desc
from .models import Farm, Miner, Telemetry, Alert
from .services import market_data, mining_decision
from .config import TEMP_WARN_C,TEMP_CRIT_C,HASHRATE_WARN_PCT,POWER_WARN_PCT
from .notifications import notify

DEFAULTS = {
    'temperature_warning_c': TEMP_WARN_C,
    'temperature_critical_c': TEMP_CRIT_C,
    'hashrate_warning_pct': HASHRATE_WARN_PCT,
    'power_warning_pct': POWER_WARN_PCT,
    'stale_minutes': 5,
}

def _utc(dt):
    if not dt: return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)

def _upsert_alert(db, farm_id, miner_id, typ, severity, message, meta=None):
    q=db.query(Alert).filter(Alert.farm_id==farm_id, Alert.miner_id==miner_id, Alert.type==typ, Alert.resolved_at.is_(None)).order_by(desc(Alert.created_at)).first()
    if q:
        q.message=message; q.metadata_json=meta or q.metadata_json; q.last_seen_at=datetime.now(timezone.utc); return q
    a=Alert(farm_id=farm_id, miner_id=miner_id, type=typ, severity=severity, message=message, metadata_json=meta or {}, last_seen_at=datetime.now(timezone.utc))
    db.add(a); return a

def evaluate_farm_alerts(db, farm_id):
    farm=db.get(Farm,farm_id)
    if not farm: return []
    now=datetime.now(timezone.utc); created=[]
    for m in farm.miners:
        last=db.query(Telemetry).filter(Telemetry.miner_id==m.id).order_by(desc(Telemetry.timestamp)).first()
        if m.host and m.status=='offline':
            a=_upsert_alert(db,farm.id,m.id,'offline','critical',f'{m.name} ist offline oder antwortet nicht.',{'status':m.status}); created.append(a)
            continue
        if not last:
            if m.host:
                a=_upsert_alert(db,farm.id,m.id,'no_telemetry','warning',f'{m.name} hat noch keine Telemetrie geliefert.',{}); created.append(a)
            continue
        age=(now-_utc(last.timestamp)).total_seconds()/60
        if m.host and age>DEFAULTS['stale_minutes']:
            a=_upsert_alert(db,farm.id,m.id,'stale_telemetry','warning',f'Telemetrie von {m.name} ist {age:.1f} Minuten alt.',{'age_minutes':round(age,1)}); created.append(a)
        if last.error_message:
            a=_upsert_alert(db,farm.id,m.id,'connector_error','warning',f'{m.name}: {last.error_message[:180]}',{}); created.append(a)
        if last.temperature_c is not None:
            if last.temperature_c>=DEFAULTS['temperature_critical_c']:
                a=_upsert_alert(db,farm.id,m.id,'temperature','critical',f'{m.name} hat {last.temperature_c:.1f} °C erreicht.',{'temperature_c':last.temperature_c}); created.append(a)
            elif last.temperature_c>=DEFAULTS['temperature_warning_c']:
                a=_upsert_alert(db,farm.id,m.id,'temperature','warning',f'{m.name} ist mit {last.temperature_c:.1f} °C ungewöhnlich warm.',{'temperature_c':last.temperature_c}); created.append(a)
        if last.hashrate_ths and m.hashrate_ths:
            ratio=last.hashrate_ths/m.hashrate_ths*100
            if ratio < 100-DEFAULTS['hashrate_warning_pct']:
                a=_upsert_alert(db,farm.id,m.id,'hashrate_anomaly','warning',f'{m.name} liefert nur {ratio:.0f}% der Nenn-Hashrate.',{'ratio_pct':round(ratio,1)}); created.append(a)
        if last.power_w and m.power_w:
            ratio=last.power_w/m.power_w*100
            if ratio > 100+DEFAULTS['power_warning_pct']:
                a=_upsert_alert(db,farm.id,m.id,'power_anomaly','warning',f'{m.name} zieht {ratio:.0f}% der erwarteten Leistung.',{'ratio_pct':round(ratio,1)}); created.append(a)
    db.commit()
    # Notify only for genuinely new alerts; repeated polling updates last_seen_at without spam.
    new_alerts=[a for a in created if a.created_at and abs((now-_utc(a.created_at)).total_seconds()) < 2]
    for a in new_alerts:
        try:
            if a.severity.lower() in __import__('app.config',fromlist=['NOTIFY_SEVERITIES']).NOTIFY_SEVERITIES:
                notify(f'SYNPORA {a.severity.upper()}: {a.message}')
        except Exception:
            pass
    return created

def resolve_stale_alerts(db, farm_id):
    farm=db.get(Farm,farm_id)
    if not farm:return
    now=datetime.now(timezone.utc)
    active=db.query(Alert).filter(Alert.farm_id==farm_id,Alert.resolved_at.is_(None)).all()
    for a in active:
        m=db.get(Miner,a.miner_id) if a.miner_id else None
        last=db.query(Telemetry).filter(Telemetry.miner_id==m.id).order_by(desc(Telemetry.timestamp)).first() if m else None
        resolved=False
        if a.type=='offline' and m and m.status=='online': resolved=True
        elif a.type in ('stale_telemetry','no_telemetry') and last and (now-_utc(last.timestamp)).total_seconds()/60<=DEFAULTS['stale_minutes']: resolved=True
        elif a.type=='temperature' and last and (last.temperature_c is None or last.temperature_c<DEFAULTS['temperature_warning_c']): resolved=True
        elif a.type=='hashrate_anomaly' and last and m and last.hashrate_ths and last.hashrate_ths/m.hashrate_ths*100 >= 90: resolved=True
        elif a.type=='power_anomaly' and last and m and last.power_w and last.power_w/m.power_w*100 <= 115: resolved=True
        elif a.type=='connector_error' and last and not last.error_message: resolved=True
        if resolved:a.resolved_at=now
    db.commit()

def farm_health(db, farm_id):
    farm=db.get(Farm,farm_id)
    if not farm:return None
    active=db.query(Alert).filter(Alert.farm_id==farm_id,Alert.resolved_at.is_(None)).all()
    weights={'critical':25,'warning':8,'info':2}
    penalty=sum(weights.get(a.severity,2) for a in active)
    score=max(0,100-penalty)
    miners=len(farm.miners); online=sum(1 for m in farm.miners if m.status=='online')
    return {'farm_id':farm_id,'score':round(score,1),'grade':'A' if score>=90 else 'B' if score>=75 else 'C' if score>=55 else 'D' if score>=30 else 'F','active_alerts':len(active),'critical_alerts':sum(a.severity=='critical' for a in active),'online':online,'miners':miners}

async def optimization(db, farm_id):
    farm=db.get(Farm,farm_id)
    if not farm:return None
    try: market=await market_data()
    except Exception: market={'btc_eur':None,'network_hashrate_eh':None}
    btc=market.get('btc_eur'); net=market.get('network_hashrate_eh'); reward=3.125
    items=[]; score=100
    for m in farm.miners:
        last=db.query(Telemetry).filter(Telemetry.miner_id==m.id).order_by(desc(Telemetry.timestamp)).first()
        h=(last.hashrate_ths if last and last.hashrate_ths else m.hashrate_ths); p=(last.power_w if last and last.power_w else m.power_w)
        temp=last.temperature_c if last else None
        rec='BEOBACHTEN'; reason='Keine belastbare Optimierung ohne aktuelle Marktdaten.'; profit=None; margin=None
        if btc and net and h and p:
            d=mining_decision(h,p,btc,net,reward,0,100,farm.electricity_price_eur_kwh)
            profit=d.profit_eur_day; margin=d.margin_pct
            if m.status=='offline': rec='PRÜFEN'; reason='Miner ist offline.'
            elif temp is not None and temp>=85: rec='ABSCHALTEN'; reason='Kritische Temperatur.'
            elif profit<0: rec='ABSCHALTEN'; reason='Aktuell negativer Tagesgewinn.'
            elif margin<10: rec='UNDERCLOCK_PRÜFEN'; reason='Gewinn vorhanden, aber geringe Sicherheitsmarge.'
            elif d.efficiency_j_th>30: rec='EFFIZIENZ_PRÜFEN'; reason='Hoher Energieverbrauch je TH/s.'
            else: rec='BETREIBEN'; reason='Profitabel mit ausreichender Marge.'
        if rec in ('ABSCHALTEN','PRÜFEN'):score-=20
        elif rec in ('UNDERCLOCK_PRÜFEN','EFFIZIENZ_PRÜFEN'):score-=7
        items.append({'miner_id':m.id,'name':m.name,'recommendation':rec,'reason':reason,'profit_eur_day':profit,'margin_pct':margin,'temperature_c':temp,'hashrate_ths':h,'power_w':p,'efficiency_j_th':p/h if h else None})
    score=max(0,score)
    return {'farm_id':farm_id,'score':score,'grade':'A' if score>=90 else 'B' if score>=75 else 'C' if score>=55 else 'D' if score>=30 else 'F','electricity_price_eur_kwh':farm.electricity_price_eur_kwh,'btc_eur':btc,'network_hashrate_eh':net,'recommendations':items}
