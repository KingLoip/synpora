from datetime import datetime, timezone
import httpx
from .config import FX_API_URL, FX_BASE_CURRENCY

async def fx_rates(base='EUR'):
    base=(base or FX_BASE_CURRENCY or 'EUR').upper()
    url=FX_API_URL.rstrip('/') + '/' + base
    async with httpx.AsyncClient(timeout=10) as c:
        r=await c.get(url); r.raise_for_status(); data=r.json()
    rates=data.get('rates',{})
    rates[base]=1.0
    return {'base':base,'rates':rates,'date':data.get('date'),'source':'frankfurter'}

async def convert_to_eur(value, currency):
    currency=(currency or 'EUR').upper()
    if currency=='EUR': return float(value),1.0
    data=await fx_rates('EUR')
    # EUR -> local currency; invert to local -> EUR
    rate=data['rates'].get(currency)
    if not rate: raise ValueError(f'No FX rate for {currency}')
    return float(value)/float(rate), 1.0/float(rate)
