def explain(decision, ranked_options):
    best=ranked_options[0] if ranked_options else {}
    reasons=[]
    if best: reasons.append(f"highest risk-adjusted score={best.get('score',0):.6f}")
    if decision=="HOLD": reasons.append("confidence or safety gate prevented execution")
    return {"decision":decision,"reasons":reasons,"alternatives":ranked_options[1:4]}
