from datetime import datetime,timedelta,timezone

def demo_snapshot():
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    timeline=[]
    for i in range(24):
        h=(now+timedelta(hours=i)).hour
        energy=.055 + .045*((h-13)/11)**2
        if 18<=h<=21: energy += .035
        pv=max(0,42*max(0,1-abs(h-13)/6))
        btc=max(.06, .125-energy*.42)
        ai=max(.08, .165-energy*.30)
        timeline.append({'timestamp':now+timedelta(hours=i),'energy_price_eur_kwh':round(energy,4),'pv_kw':round(pv,1),'btc_eur_kwh':round(btc,4),'ai_eur_kwh':round(ai,4)})
    current=timeline[0]
    options=[('AI Compute',current['ai_eur_kwh']),('BTC Mining',current['btc_eur_kwh']),('Battery/Grid',max(.04,current['energy_price_eur_kwh']*.72))]
    options.sort(key=lambda x:x[1],reverse=True)
    return {'farm':{'id':'demo-1','name':'SYNPORA Demo Farm','mode':'simulation'},'assets':{'pv_kw':42,'battery_kwh':80,'battery_soc_pct':67,'asic_count':8,'gpu_count':16},'current':current,'best_option':options[0][0],'best_value_eur_kwh':options[0][1],'options':[{'name':n,'value_eur_kwh':v} for n,v in options],'confidence_pct':89,'data_quality_pct':96,'fleet_health_pct':98,'timeline':timeline}
