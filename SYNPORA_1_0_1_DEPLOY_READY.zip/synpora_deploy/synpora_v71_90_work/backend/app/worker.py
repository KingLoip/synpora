import asyncio
from datetime import datetime, timezone
from sqlalchemy import desc
from .db import SessionLocal
from .models import Miner, Telemetry
from .connector import poll
from .config import POLL_INTERVAL_SECONDS
from .alerts import evaluate_farm_alerts, resolve_stale_alerts

async def poll_once():
    db=SessionLocal()
    try:
        miners=db.query(Miner).filter(Miner.host.isnot(None)).all()
        results=[]
        for m in miners:
            try:
                data=await asyncio.to_thread(poll,m.host,m.api_port or 4028)
                t=Telemetry(
                    miner_id=m.id,
                    timestamp=datetime.now(timezone.utc),
                    hashrate_ths=data.get("hashrate_ths"),
                    power_w=data.get("power_w"),
                    temperature_c=data.get("temperature_c"),
                    fan_pct=data.get("fan_pct"),
                    uptime_pct=None,
                )
                db.add(t)
                if data.get("hashrate_ths"): m.hashrate_ths=data["hashrate_ths"]
                if data.get("power_w"): m.power_w=data["power_w"]
                m.status="online"
                results.append({"miner_id":m.id,"status":"online"})
            except Exception as e:
                m.status="offline"
                db.add(Telemetry(miner_id=m.id,timestamp=datetime.now(timezone.utc),error_message=str(e)))
                results.append({"miner_id":m.id,"status":"offline","error":str(e)})
        db.commit()
        for fid in sorted({m.farm_id for m in miners}):
            try:
                evaluate_farm_alerts(db,fid); resolve_stale_alerts(db,fid)
            except Exception: pass
        return results
    finally:
        db.close()

async def polling_loop(stop_event):
    while not stop_event.is_set():
        try: await poll_once()
        except Exception: pass
        try: await asyncio.wait_for(stop_event.wait(),timeout=POLL_INTERVAL_SECONDS)
        except asyncio.TimeoutError: pass

async def refresh_forecasts_once():
    from .models import Farm, EnergyProfile, EnergyForecastSlot
    from .data_providers import fetch_day_ahead_prices, fetch_awattar_prices, fetch_pv_forecast
    from .energy import current_energy_price
    from uuid import uuid4
    db=SessionLocal(); results=[]
    try:
        for farm in db.query(Farm).all():
            p=db.query(EnergyProfile).filter_by(farm_id=farm.id).first()
            if not p: continue
            run_id=uuid4().hex
            prices=[]; pv=[]
            try:
                zone=(p.market_zone or p.country_code or '').upper()
                if zone == 'AT':
                    prices=await fetch_awattar_prices(168)
                if not prices:
                    prices=await fetch_day_ahead_prices(zone,168)
            except Exception: pass
            if p.latitude is not None and p.longitude is not None and p.pv_capacity_kw>0:
                try: pv=await fetch_pv_forecast(p.latitude,p.longitude,p.pv_capacity_kw,p.pv_tilt_deg or 35,p.pv_azimuth_deg or 0,168,p.timezone or 'UTC')
                except Exception: pass
            byp={x['timestamp'].replace(minute=0,second=0,microsecond=0):x for x in prices}
            byv={x['timestamp'].replace(minute=0,second=0,microsecond=0):x for x in pv}
            now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0); count=0
            for i in range(168):
                ts=now+__import__('datetime').timedelta(hours=i); pr=byp.get(ts); vx=byv.get(ts)
                if not pr and not vx: continue
                obj=db.query(EnergyForecastSlot).filter_by(farm_id=farm.id,timestamp=ts).first()
                if not obj: obj=EnergyForecastSlot(farm_id=farm.id,timestamp=ts,grid_price_eur_kwh=current_energy_price(db,farm),pv_kw=0)
                if pr: obj.grid_price_eur_kwh=pr['grid_price_eur_kwh']; obj.provider=pr.get('provider',pr['source'].split(':')[0]); obj.confidence_pct=90 if obj.provider=='awattar' else 85
                if vx: obj.pv_kw=vx['pv_kw']; obj.provider='open-meteo' if not pr else obj.provider; obj.confidence_pct=min(obj.confidence_pct or 70,80)
                obj.source='+'.join([x['source'] for x in (pr,vx) if x]) or 'fallback'; obj.forecast_run_id=run_id; obj.currency='EUR'; obj.fx_to_eur=1.0
                db.add(obj); count+=1
            results.append({'farm_id':farm.id,'slots':count,'price_source':bool(prices),'pv_source':bool(pv),'run_id':run_id})
        db.commit(); return results
    finally: db.close()

async def forecast_loop(stop_event, interval_minutes):
    while not stop_event.is_set():
        try: await refresh_forecasts_once()
        except Exception: pass
        try: await asyncio.wait_for(stop_event.wait(),timeout=max(300,interval_minutes*60))
        except asyncio.TimeoutError: pass
