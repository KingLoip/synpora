ALLOWED_NETWORK_FIELDS={"farm_class","region","capacity_kw","energy_price_eur_kwh",
"decision","value_eur_kwh","confidence","data_quality","realized_value_eur_kwh",
"prediction_error"}
def anonymize(payload): return {k:payload[k] for k in ALLOWED_NETWORK_FIELDS if k in payload}
