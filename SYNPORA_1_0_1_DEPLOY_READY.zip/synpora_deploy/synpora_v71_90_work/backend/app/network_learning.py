from statistics import mean
def aggregate_learning(farms):
    vals=[float(f.get("realized_value_eur_kwh",0)) for f in farms if f.get("realized_value_eur_kwh") is not None]
    errors=[abs(float(f.get("prediction_error",0))) for f in farms if f.get("prediction_error") is not None]
    return {
        "farms":len(farms),
        "mean_realized_value_eur_kwh":mean(vals) if vals else 0,
        "mean_absolute_prediction_error":mean(errors) if errors else 0,
        "learning_samples":len(vals)
    }
