from datetime import datetime, timezone

def ai_core(decision, learning, data_quality=None, calibration=None):
    conf=float(decision.get('confidence_pct') or 0)
    quality=float((data_quality or {}).get('score') or 0)
    mae=float((learning or {}).get('mean_abs_error_pct') or 0)
    uncertainty=min(60,max(0,mae))
    final_conf=max(0,min(100,conf*0.65+quality*0.35-uncertainty*0.25))
    action=decision.get('decision','HOLD')
    if final_conf < 50: action='HOLD'
    return {'engine':'SYNPORA_AI_CORE','version':'45.0','decision':action,'confidence_pct':round(final_conf,2),
            'raw_confidence_pct':conf,'data_quality_score':quality,'learning_mae_pct':mae,
            'reason':'Combines economic decision, data quality and historical model error.','approval_required':True,
            'control_commands_sent':False,'generated_at':datetime.now(timezone.utc).isoformat()}
