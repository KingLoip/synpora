from datetime import datetime, timezone
import json
import urllib.request
from sqlalchemy import text

def ensure_protocol_table(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS device_protocols (id INTEGER PRIMARY KEY AUTOINCREMENT,farm_id INTEGER NOT NULL,name VARCHAR(120),protocol VARCHAR(30),endpoint VARCHAR(500),enabled INTEGER DEFAULT 1,metadata_json TEXT,last_seen DATETIME,last_status VARCHAR(40))''')); db.commit()
def register_protocol(db,farm_id,data):
    ensure_protocol_table(db); r=db.execute(text('INSERT INTO device_protocols(farm_id,name,protocol,endpoint,enabled,metadata_json,last_status) VALUES(:f,:n,:p,:e,:en,:m,"registered")'),{'f':farm_id,'n':data.get('name','device'),'p':data.get('protocol','rest'),'e':data.get('endpoint'),'en':1 if data.get('enabled',True) else 0,'m':json.dumps(data.get('metadata',{}))}); db.commit(); return get_protocol(db,r.lastrowid)
def get_protocol(db,pid):
    r=db.execute(text('SELECT * FROM device_protocols WHERE id=:i'),{'i':pid}).mappings().first()
    if not r:return None
    d=dict(r); d['enabled']=bool(d['enabled']); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); return d
def list_protocols(db,farm_id):
    ensure_protocol_table(db); return [dict(x) for x in db.execute(text('SELECT * FROM device_protocols WHERE farm_id=:f ORDER BY id'),{'f':farm_id}).mappings().all()]
def probe_rest(endpoint,timeout=5):
    req=urllib.request.Request(endpoint,headers={'Accept':'application/json'}); 
    with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode())
def protocol_health(db,farm_id):
    ensure_protocol_table(db); return [dict(x) for x in db.execute(text('SELECT id,name,protocol,endpoint,enabled,last_seen,last_status FROM device_protocols WHERE farm_id=:f'),{'f':farm_id}).mappings().all()]
