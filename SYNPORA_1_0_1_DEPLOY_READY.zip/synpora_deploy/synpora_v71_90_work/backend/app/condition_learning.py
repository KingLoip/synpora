from datetime import datetime, timezone, timedelta
from collections import defaultdict
from sqlalchemy.orm import Session
from .models import EnergyForecastSlot, EnergyObservation, ForecastAccuracy

def utc(dt):
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)

def season_for(ts):
    m=utc(ts).month
    return 'winter' if m in (12,1,2) else 'spring' if m in (3,4,5) else 'summer' if m in (6,7,8) else 'autumn'

def condition_for(pv_kw, capacity_kw, hour):
    if hour < 5 or hour >= 21 or (pv_kw is not None and pv_kw <= 0.001): return 'night'
    if not capacity_kw or capacity_kw <= 0: return 'unknown'
    ratio=max(0.0,min(1.2,float(pv_kw or 0)/capacity_kw))
    if ratio < 0.15: return 'overcast_low'
    if ratio < 0.45: return 'partly_cloudy'
    if ratio < 0.80: return 'bright'
    return 'clear'

def condition_calibration(db:Session,farm_id:int,metric:str,provider:str,season:str,condition:str):
    q=db.query(ForecastAccuracy).filter_by(farm_id=farm_id,metric=metric,provider=provider,season=season,condition=condition).first()
    if not q: return None
    return {'weight':q.weight or 1.0,'bias_pct':q.bias or 0.0,'error_std_pct':q.error_std or q.mae or 15.0,'confidence_pct':q.calibrated_confidence or q.score or 70.0,'samples':q.samples or 0}

def learn_conditions(db:Session,farm_id:int,lookback_hours:int=24*365):
    since=datetime.now(timezone.utc)-timedelta(hours=lookback_hours)
    forecasts=db.query(EnergyForecastSlot).filter(EnergyForecastSlot.farm_id==farm_id,EnergyForecastSlot.timestamp>=since).all()
    obs=db.query(EnergyObservation).filter(EnergyObservation.farm_id==farm_id,EnergyObservation.timestamp>=since).all()
    by={utc(o.timestamp):o for o in obs}
    groups=defaultdict(lambda:{'err':[],'signed':[]})
    for f in forecasts:
        ts=utc(f.timestamp); o=by.get(ts)
        if not o: continue
        season=season_for(ts)
        # For PV, actual generation is used to classify the realized operating/weather regime.
        pv_actual=o.pv_kw
        cap=max(float(pv_actual or 0),float(f.pv_kw or 0),0.001)
        cond=condition_for(pv_actual, cap, ts.hour) if o.pv_kw is not None else 'unknown'
        for metric,pred,actual in [('price',f.grid_price_eur_kwh,o.grid_price_eur_kwh),('pv',f.pv_kw,o.pv_kw)]:
            if pred is None or actual is None: continue
            denom=max(abs(float(actual)),0.0001)
            e=abs(float(actual)-float(pred))/denom*100
            se=(float(actual)-float(pred))/denom*100
            key=(metric,f.provider or f.source or 'unknown',season,cond)
            groups[key]['err'].append(e); groups[key]['signed'].append(se)
    results=[]
    for (metric,provider,season,condition),g in groups.items():
        n=len(g['err'])
        if n<4: continue
        mae=sum(g['err'])/n; bias=sum(g['signed'])/n
        accuracy=max(0.05,1/(1+mae/10)); sample_factor=min(1,n/24)
        weight=max(0.05,accuracy*(0.35+0.65*sample_factor))
        conf=max(10,min(99,100-(0.65*mae)))
        row=db.query(ForecastAccuracy).filter_by(farm_id=farm_id,metric=metric,provider=provider,season=season,condition=condition).first()
        if not row: row=ForecastAccuracy(farm_id=farm_id,metric=metric,provider=provider,season=season,condition=condition)
        row.samples=n; row.mae=mae; row.mape=mae; row.bias=bias; row.error_std=0; row.weight=weight; row.calibrated_confidence=conf; row.score=max(0,min(100,100-mae)); row.updated_at=datetime.now(timezone.utc)
        db.add(row)
        results.append({'metric':metric,'provider':provider,'season':season,'condition':condition,'samples':n,'mae_pct':round(mae,2),'bias_pct':round(bias,2),'weight':round(weight,4),'confidence_pct':round(conf,1)})
    db.commit(); return results
