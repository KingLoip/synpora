from statistics import mean

def run(rows,strategies=None,cost=0):
    strategies=strategies or ['btc','ai','value_rank','hold']; out=[]
    for s in strategies:
        vals=[]
        for r in rows:
            btc=float(r.get('btc_value_eur_kwh') or 0); ai=float(r.get('ai_value_eur_kwh') or 0); actual=float(r.get('realized_value_eur_kwh') or 0)
            pred=0 if s=='hold' else btc if s=='btc' else ai if s=='ai' else max(btc,ai)
            vals.append(actual-cost if pred>0 else 0)
        out.append({'model':s,'samples':len(vals),'total_net':sum(vals),'mean_net':mean(vals) if vals else 0})
    return {'strategies':out,'best_model':max(out,key=lambda x:x['mean_net'])['model'] if out else 'hold'}
