from datetime import datetime, timedelta, timezone
from sqlalchemy import func
from .models import Miner, Telemetry

def miner_timeseries(db, miner_id, hours=24, bucket_minutes=15):
    since=datetime.now(timezone.utc)-timedelta(hours=max(1,min(hours,24*30)))
    rows=db.query(Telemetry).filter(Telemetry.miner_id==miner_id,Telemetry.timestamp>=since).order_by(Telemetry.timestamp.asc()).all()
    if not rows: return {'miner_id':miner_id,'hours':hours,'bucket_minutes':bucket_minutes,'points':[]}
    bucket_seconds=bucket_minutes*60
    buckets={}
    for r in rows:
        ts=r.timestamp
        if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
        epoch=int(ts.timestamp()); key=epoch-(epoch%bucket_seconds)
        b=buckets.setdefault(key,{'samples':0,'hash':[],'power':[],'temp':[]})
        b['samples']+=1
        if r.hashrate_ths is not None:b['hash'].append(r.hashrate_ths)
        if r.power_w is not None:b['power'].append(r.power_w)
        if r.temperature_c is not None:b['temp'].append(r.temperature_c)
    points=[]
    for key,b in buckets.items():
        def avg(v): return round(sum(v)/len(v),3) if v else None
        points.append({'timestamp':datetime.fromtimestamp(key,tz=timezone.utc),'samples':b['samples'],'hashrate_ths':avg(b['hash']),'power_w':avg(b['power']),'temperature_c':avg(b['temp'])})
    return {'miner_id':miner_id,'hours':hours,'bucket_minutes':bucket_minutes,'points':points}

def fleet_timeseries(db, farm_id, hours=24, bucket_minutes=15):
    miners=db.query(Miner).filter(Miner.farm_id==farm_id).all()
    series=[miner_timeseries(db,m.id,hours,bucket_minutes) for m in miners]
    buckets={}
    for s in series:
        for p in s['points']:
            k=p['timestamp'].isoformat(); b=buckets.setdefault(k,{'hash':[],'power':[],'temp':[],'samples':0})
            if p['hashrate_ths'] is not None:b['hash'].append(p['hashrate_ths'])
            if p['power_w'] is not None:b['power'].append(p['power_w'])
            if p['temperature_c'] is not None:b['temp'].append(p['temperature_c'])
            b['samples']+=p['samples']
    def avg(v):return round(sum(v),3) if v else None
    return {'farm_id':farm_id,'hours':hours,'bucket_minutes':bucket_minutes,'points':[{'timestamp':k,'hashrate_ths':avg(v['hash']),'power_w':avg(v['power']),'temperature_c':avg(v['temp']),'samples':v['samples']} for k,v in sorted(buckets.items())]}
