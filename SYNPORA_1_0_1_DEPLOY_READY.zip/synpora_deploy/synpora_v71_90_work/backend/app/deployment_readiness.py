def assess(checks):
    failed=[c for c in checks if not c.get("pass")]
    return {"ready":not failed,"failed":failed,"checks":checks,
            "control_write_enabled":False}
