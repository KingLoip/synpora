from datetime import datetime, timezone
from sqlalchemy import text

def ensure_energy_asset_tables(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS energy_meter_readings (id INTEGER PRIMARY KEY AUTOINCREMENT, farm_id INTEGER NOT NULL, timestamp DATETIME NOT NULL, grid_import_kw FLOAT, grid_export_kw FLOAT, pv_kw FLOAT, battery_kw FLOAT, battery_soc_pct FLOAT, voltage_v FLOAT, frequency_hz FLOAT, source VARCHAR(100), quality_score FLOAT, error TEXT)'''))
    db.execute(text('''CREATE TABLE IF NOT EXISTS energy_devices (id INTEGER PRIMARY KEY AUTOINCREMENT, farm_id INTEGER NOT NULL, name VARCHAR(120) NOT NULL, device_type VARCHAR(40) NOT NULL, endpoint VARCHAR(300), enabled INTEGER DEFAULT 1, created_at DATETIME NOT NULL)''')); db.commit()
def _f(v):
    try:return float(v) if v is not None and v!='' else None
    except:return None
def record_meter(db,farm_id,p):
    ensure_energy_asset_tables(db); ts=p.get('timestamp') or datetime.now(timezone.utc).isoformat(); vals={k:_f(p.get(k)) for k in ['grid_import_kw','grid_export_kw','pv_kw','battery_kw','battery_soc_pct','voltage_v','frequency_hz']}; quality=_f(p.get('quality_score')); quality=100 if quality is None and p.get('source') else (70 if quality is None else quality)
    db.execute(text('''INSERT INTO energy_meter_readings (farm_id,timestamp,grid_import_kw,grid_export_kw,pv_kw,battery_kw,battery_soc_pct,voltage_v,frequency_hz,source,quality_score,error) VALUES (:farm_id,:timestamp,:grid_import_kw,:grid_export_kw,:pv_kw,:battery_kw,:battery_soc_pct,:voltage_v,:frequency_hz,:source,:quality_score,:error)'''),{'farm_id':farm_id,'timestamp':ts,**vals,'source':p.get('source','api'),'quality_score':quality,'error':p.get('error')}); db.commit()
def readings(db,farm_id,limit=100):
    ensure_energy_asset_tables(db); q=db.execute(text('SELECT * FROM energy_meter_readings WHERE farm_id=:id ORDER BY timestamp DESC LIMIT :limit'),{'id':farm_id,'limit':max(1,min(int(limit),1000))}); return [dict(r._mapping) for r in q]
def latest(db,farm_id): return (readings(db,farm_id,1) or [None])[0]
