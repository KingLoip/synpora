from datetime import datetime,timezone

def release():
    return {'product':'SYNPORA','version':'1.0.0','release':'SYNPORA 1.0','status':'pilot-ready','control_mode':'recommendation_only','hardware_write':False,'autonomous_control':False,'network_learning':True,'generated_at':datetime.now(timezone.utc)}
