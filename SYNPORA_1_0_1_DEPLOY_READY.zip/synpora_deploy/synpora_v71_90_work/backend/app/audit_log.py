import uuid
from datetime import datetime, timezone
EVENTS=[]
def record(event_type, actor, payload=None):
    e={"id":str(uuid.uuid4()),"timestamp":datetime.now(timezone.utc).isoformat(),
       "event_type":event_type,"actor":actor,"payload":payload or {}}
    EVENTS.append(e); return e
def list_events(limit=100): return EVENTS[-int(limit):][::-1]
