def batch_evaluate(engine, scenarios):
    return [engine(s) for s in scenarios]
