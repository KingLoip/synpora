DEFAULT_FLAGS={
    "autonomous_control":False,
    "hardware_write":False,
    "network_learning":True,
    "digital_twin":True,
    "experimental_models":False,
}
FLAGS=dict(DEFAULT_FLAGS)
def get_flags(): return dict(FLAGS)
def set_flags(updates):
    for k,v in updates.items():
        if k in FLAGS: FLAGS[k]=bool(v)
    FLAGS["autonomous_control"]=False
    FLAGS["hardware_write"]=False
    return get_flags()
