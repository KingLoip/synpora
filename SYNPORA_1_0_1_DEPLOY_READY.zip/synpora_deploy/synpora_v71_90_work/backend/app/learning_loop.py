from datetime import datetime, timezone
from sqlalchemy import text
def ensure_learning_table(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS optimization_learning (id INTEGER PRIMARY KEY AUTOINCREMENT, farm_id INTEGER NOT NULL, timestamp DATETIME NOT NULL, model VARCHAR(80), predicted_value_eur_kwh FLOAT, realized_value_eur_kwh FLOAT, error_pct FLOAT, sample_type VARCHAR(40), confidence_pct FLOAT, notes TEXT)''')); db.commit()
def record_feedback(db,farm_id,p):
    ensure_learning_table(db); pred=float(p.get('predicted_value_eur_kwh') or 0); real=float(p.get('realized_value_eur_kwh') or 0); err=(real-pred)/abs(pred)*100 if pred else None
    db.execute(text('''INSERT INTO optimization_learning (farm_id,timestamp,model,predicted_value_eur_kwh,realized_value_eur_kwh,error_pct,sample_type,confidence_pct,notes) VALUES (:farm_id,:timestamp,:model,:pred,:real,:err,:sample,:conf,:notes)'''),{'farm_id':farm_id,'timestamp':p.get('timestamp') or datetime.now(timezone.utc).isoformat(),'model':p.get('model','optimizer'),'pred':pred,'real':real,'err':err,'sample':p.get('sample_type','realized'),'conf':p.get('confidence_pct'),'notes':p.get('notes')}); db.commit(); return {'predicted_value_eur_kwh':pred,'realized_value_eur_kwh':real,'error_pct':err}
def learning_summary(db,farm_id):
    ensure_learning_table(db); r=db.execute(text('SELECT COUNT(*) n, AVG(error_pct) err, AVG(ABS(error_pct)) mae, AVG(confidence_pct) conf FROM optimization_learning WHERE farm_id=:id'),{'id':farm_id}).first(); return {'samples':int(r.n or 0),'avg_error_pct':float(r.err or 0),'mean_abs_error_pct':float(r.mae or 0),'avg_confidence_pct':float(r.conf or 0)}
