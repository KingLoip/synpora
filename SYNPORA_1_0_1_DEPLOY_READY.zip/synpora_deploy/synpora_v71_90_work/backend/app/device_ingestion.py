from datetime import datetime, timezone

FIELDS = ("pv_power_kw","grid_power_kw","battery_power_kw","battery_soc_pct","load_power_kw")

def normalize_payload(payload, source):
    out={"source":source,"timestamp":datetime.now(timezone.utc).isoformat(),"quality":"UNKNOWN"}
    for f in FIELDS:
        if f in payload:
            try: out[f]=float(payload[f])
            except (TypeError,ValueError): out[f]=None
    valid=sum(out.get(f) is not None for f in FIELDS)
    out["quality"]="GOOD" if valid>=4 else ("PARTIAL" if valid else "BAD")
    return out

def derive_power_balance(x):
    pv=x.get("pv_power_kw") or 0
    grid=x.get("grid_power_kw") or 0
    batt=x.get("battery_power_kw") or 0
    load=x.get("load_power_kw")
    if load is None:
        load=max(0,pv+grid+batt)
    return {**x,"derived_load_power_kw":round(load,4)}
