from datetime import datetime,timezone

def market_snapshot():
    return {'timestamp':datetime.now(timezone.utc),'currency':'EUR','quality':'demo/fallback','btc_price_eur':95000.0,'mining_hashprice_usd_th':0.045,'network_hashrate_eh':950.0,'gpu_compute_eur_hour':0.42,'fx_eurusd':1.17,'note':'Values are illustrative until a live provider is connected.'}
