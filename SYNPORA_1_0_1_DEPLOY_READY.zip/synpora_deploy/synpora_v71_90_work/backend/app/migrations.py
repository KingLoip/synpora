from sqlalchemy import inspect, text
from .db import engine

def ensure_schema():
    insp=inspect(engine); tables=set(insp.get_table_names())
    with engine.begin() as conn:
        if 'energy_profiles' in tables:
            cols={c['name'] for c in insp.get_columns('energy_profiles')}
            additions={'latitude':'FLOAT','longitude':'FLOAT','pv_tilt_deg':'FLOAT','pv_azimuth_deg':'FLOAT','timezone':'VARCHAR(64)','country_code':'VARCHAR(8)','market_zone':'VARCHAR(64)','currency':'VARCHAR(8)'}
            for name,typ in additions.items():
                if name not in cols: conn.execute(text(f'ALTER TABLE energy_profiles ADD COLUMN {name} {typ}'))
        if 'forecast_accuracy' in tables:
            cols={c['name'] for c in insp.get_columns('forecast_accuracy')}
            additions={'error_std':'FLOAT','weight':'FLOAT','calibrated_confidence':'FLOAT','season':'VARCHAR(16)','condition':'VARCHAR(24)'}
            for name,typ in additions.items():
                if name not in cols: conn.execute(text(f'ALTER TABLE forecast_accuracy ADD COLUMN {name} {typ}'))
        if 'asset_performance' not in tables:
            conn.execute(text('CREATE TABLE asset_performance (id INTEGER PRIMARY KEY, miner_id INTEGER NOT NULL, timestamp DATETIME NOT NULL, regime VARCHAR(32), hashrate_ratio_pct FLOAT, efficiency_j_th FLOAT, temperature_c FLOAT, power_w FLOAT, score FLOAT, metadata_json JSON)'))
        if 'energy_forecast_slots' in tables:
            cols={c['name'] for c in insp.get_columns('energy_forecast_slots')}
            additions={'currency':'VARCHAR(8)','fx_to_eur':'FLOAT','confidence_pct':'FLOAT','provider':'VARCHAR(40)','forecast_run_id':'VARCHAR(64)'}
            for name,typ in additions.items():
                if name not in cols: conn.execute(text(f'ALTER TABLE energy_forecast_slots ADD COLUMN {name} {typ}'))
