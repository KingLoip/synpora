from datetime import datetime, timezone
from sqlalchemy import text


def ensure_calibration_table(db):
    db.execute(text('''CREATE TABLE IF NOT EXISTS model_calibration (
      id INTEGER PRIMARY KEY AUTOINCREMENT, farm_id INTEGER NOT NULL, source VARCHAR(50) NOT NULL,
      predicted FLOAT, realized FLOAT, weight FLOAT DEFAULT 1, created_at DATETIME NOT NULL)''')); db.commit()


def add_sample(db,farm_id,source,predicted,realized,weight=1.0):
    ensure_calibration_table(db)
    db.execute(text('INSERT INTO model_calibration (farm_id,source,predicted,realized,weight,created_at) VALUES (:f,:s,:p,:r,:w,:t)'),
               {'f':farm_id,'s':source,'p':predicted,'r':realized,'w':weight,'t':datetime.now(timezone.utc)}); db.commit()
    return calibration(db,farm_id,source)


def calibration(db,farm_id,source=None):
    ensure_calibration_table(db)
    q='SELECT source,predicted,realized,weight FROM model_calibration WHERE farm_id=:f'
    params={'f':farm_id}
    if source: q+=' AND source=:s'; params['s']=source
    rows=db.execute(text(q),params).mappings().all()
    grouped={}
    for r in rows:
        g=grouped.setdefault(r['source'],{'w':0,'p':0,'r':0,'n':0})
        w=float(r['weight'] or 1); g['w']+=w; g['p']+=w*float(r['predicted'] or 0); g['r']+=w*float(r['realized'] or 0); g['n']+=1
    out={}
    for s,g in grouped.items():
        mean_p=g['p']/g['w'] if g['w'] else 0; mean_r=g['r']/g['w'] if g['w'] else 0
        ratio=mean_r/mean_p if mean_p else 1.0
        out[s]={'samples':g['n'],'mean_predicted':mean_p,'mean_realized':mean_r,'calibration_factor':max(.5,min(1.5,ratio))}
    return out if source is None else out.get(source,{'samples':0,'calibration_factor':1.0})


def calibrate_value(db,farm_id,source,value):
    c=calibration(db,farm_id,source); factor=float(c.get('calibration_factor',1.0)); return {'raw_value_eur_kwh':float(value or 0),'calibrated_value_eur_kwh':float(value or 0)*factor,'factor':factor,'samples':c.get('samples',0)}
