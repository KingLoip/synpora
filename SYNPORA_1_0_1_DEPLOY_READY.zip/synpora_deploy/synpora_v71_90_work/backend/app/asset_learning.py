from datetime import datetime, timezone, timedelta
from collections import defaultdict
from sqlalchemy.orm import Session
from .models import Miner, Telemetry

def utc(dt):
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)

def temp_band(t):
    if t is None: return 'unknown'
    if t < 25: return 'cool'
    if t < 32: return 'normal'
    if t < 38: return 'warm'
    return 'hot'

def asset_learning(db: Session, farm_id: int, lookback_hours: int = 24*90):
    since=datetime.now(timezone.utc)-timedelta(hours=lookback_hours)
    miners=db.query(Miner).filter(Miner.farm_id==farm_id).all()
    out=[]
    for m in miners:
        rows=db.query(Telemetry).filter(Telemetry.miner_id==m.id,Telemetry.timestamp>=since).order_by(Telemetry.timestamp).all()
        valid=[r for r in rows if r.hashrate_ths is not None and r.power_w is not None]
        if not valid: continue
        nominal_h=max(m.hashrate_ths or 0.0,0.001); nominal_p=max(m.power_w or 0.0,0.001)
        groups=defaultdict(list)
        for r in valid:
            temp=temp_band(r.temperature_c)
            hr_ratio=float(r.hashrate_ths)/nominal_h
            eff=float(r.power_w)/max(float(r.hashrate_ths),0.001)
            groups[temp].append((hr_ratio,eff,r.temperature_c))
        bands={}
        for band, vals in groups.items():
            bands[band]={
                'samples':len(vals),
                'hashrate_ratio_pct':round(100*sum(v[0] for v in vals)/len(vals),2),
                'efficiency_j_th':round(sum(v[1] for v in vals)/len(vals),3),
                'avg_temp_c':round(sum(v[2] for v in vals if v[2] is not None)/max(1,sum(v[2] is not None for v in vals)),2) if any(v[2] is not None for v in vals) else None
            }
        ratios=[float(r.hashrate_ths)/nominal_h for r in valid]
        effs=[float(r.power_w)/max(float(r.hashrate_ths),0.001) for r in valid]
        temps=[r.temperature_c for r in valid if r.temperature_c is not None]
        out.append({'miner_id':m.id,'name':m.name,'model':m.model,'samples':len(valid),'availability_pct':round(100*len(valid)/max(1,len(rows)),2),'hashrate_ratio_pct':round(100*sum(ratios)/len(ratios),2),'efficiency_j_th':round(sum(effs)/len(effs),3),'avg_temp_c':round(sum(temps)/len(temps),2) if temps else None,'temperature_bands':bands})
    return {'farm_id':farm_id,'lookback_hours':lookback_hours,'assets':out,'generated_at':datetime.now(timezone.utc).isoformat()}
