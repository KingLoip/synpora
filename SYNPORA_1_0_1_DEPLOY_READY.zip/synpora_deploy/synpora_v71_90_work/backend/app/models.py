from datetime import datetime,timezone
from sqlalchemy import Column,DateTime,Float,ForeignKey,Integer,String,Text,JSON
from sqlalchemy.orm import relationship
from .db import Base
def utcnow(): return datetime.now(timezone.utc)
class Farm(Base):
    __tablename__="farms"
    id=Column(Integer,primary_key=True); name=Column(String(120),nullable=False)
    electricity_price_eur_kwh=Column(Float,nullable=False,default=.11)
    power_limit_kw=Column(Float); reserve_pct=Column(Float,nullable=False,default=10)
    created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)
    miners=relationship("Miner",back_populates="farm",cascade="all, delete-orphan")
class Miner(Base):
    __tablename__="miners"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    name=Column(String(120),nullable=False); manufacturer=Column(String(80)); model=Column(String(80))
    hashrate_ths=Column(Float,nullable=False); power_w=Column(Float,nullable=False); capex_eur=Column(Float)
    host=Column(String(255)); api_port=Column(Integer,default=4028); status=Column(String(20),default="unknown")
    created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)
    farm=relationship("Farm",back_populates="miners"); telemetry=relationship("Telemetry",back_populates="miner",cascade="all, delete-orphan")
class Telemetry(Base):
    __tablename__="telemetry"
    id=Column(Integer,primary_key=True); miner_id=Column(Integer,ForeignKey("miners.id"),nullable=False)
    timestamp=Column(DateTime(timezone=True),default=utcnow,nullable=False)
    hashrate_ths=Column(Float); power_w=Column(Float); temperature_c=Column(Float); fan_pct=Column(Float); uptime_pct=Column(Float)
    pool_fee_pct=Column(Float); error_message=Column(Text)
    miner=relationship("Miner",back_populates="telemetry")

class Alert(Base):
    __tablename__="alerts"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False); miner_id=Column(Integer,ForeignKey("miners.id"))
    type=Column(String(60),nullable=False); severity=Column(String(20),nullable=False); message=Column(Text,nullable=False)
    metadata_json=Column(JSON,default=dict); created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False); last_seen_at=Column(DateTime(timezone=True),default=utcnow,nullable=False); resolved_at=Column(DateTime(timezone=True))

class User(Base):
    __tablename__='users'
    id=Column(Integer,primary_key=True); email=Column(String(255),unique=True,index=True,nullable=False)
    password_hash=Column(String(255),nullable=False); role=Column(String(30),nullable=False,default='operator')
    is_active=Column(Integer,nullable=False,default=1); created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False); last_login_at=Column(DateTime(timezone=True))

class UserFarm(Base):
    __tablename__='user_farms'
    user_id=Column(Integer,ForeignKey('users.id'),primary_key=True); farm_id=Column(Integer,ForeignKey('farms.id'),primary_key=True); role=Column(String(30),nullable=False,default='operator')

class AuditLog(Base):
    __tablename__='audit_logs'
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id')); action=Column(String(100),nullable=False); resource=Column(String(120)); ip=Column(String(80)); metadata_json=Column(JSON,default=dict); created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)

class Subscription(Base):
    __tablename__='subscriptions'
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id'),unique=True,nullable=False); plan=Column(String(30),nullable=False,default='free'); status=Column(String(30),nullable=False,default='active'); seats=Column(Integer,nullable=False,default=1); created_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)


class EnergyProfile(Base):
    __tablename__="energy_profiles"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),unique=True,nullable=False)
    grid_import_price_eur_kwh=Column(Float,nullable=False,default=.11)
    grid_export_price_eur_kwh=Column(Float,nullable=False,default=.06)
    pv_capacity_kw=Column(Float,nullable=False,default=0)
    battery_capacity_kwh=Column(Float,nullable=False,default=0)
    battery_soc_pct=Column(Float,nullable=False,default=50)
    battery_roundtrip_efficiency_pct=Column(Float,nullable=False,default=90)
    max_grid_import_kw=Column(Float)
    max_pv_kw=Column(Float)
    latitude=Column(Float)
    longitude=Column(Float)
    pv_tilt_deg=Column(Float,default=35)
    pv_azimuth_deg=Column(Float,default=0)
    timezone=Column(String(64),default='UTC')
    country_code=Column(String(8),default='')
    market_zone=Column(String(64),default='')
    currency=Column(String(8),default='EUR')
    updated_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)

class EnergyTariff(Base):
    __tablename__="energy_tariffs"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    weekday=Column(Integer,nullable=False,default=-1)
    start_hour=Column(Integer,nullable=False,default=0); end_hour=Column(Integer,nullable=False,default=24)
    price_eur_kwh=Column(Float,nullable=False)
    label=Column(String(80),default="tariff")

class ComputeOption(Base):
    __tablename__="compute_options"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    name=Column(String(120),nullable=False); workload=Column(String(80),nullable=False,default="AI inference")
    power_kw=Column(Float,nullable=False); gross_revenue_eur_hour=Column(Float,nullable=False)
    availability_pct=Column(Float,nullable=False,default=100); variable_cost_eur_hour=Column(Float,nullable=False,default=0)
    enabled=Column(Integer,nullable=False,default=1)


class EnergyForecastSlot(Base):
    __tablename__="energy_forecast_slots"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    timestamp=Column(DateTime(timezone=True),nullable=False); grid_price_eur_kwh=Column(Float,nullable=False)
    pv_kw=Column(Float,nullable=False,default=0); source=Column(String(80),default="user")
    currency=Column(String(8),default="EUR"); fx_to_eur=Column(Float,default=1.0); confidence_pct=Column(Float,default=70.0)
    provider=Column(String(40),default="fallback"); forecast_run_id=Column(String(64))

class EnergyObservation(Base):
    __tablename__="energy_observations"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    timestamp=Column(DateTime(timezone=True),nullable=False); grid_price_eur_kwh=Column(Float)
    pv_kw=Column(Float); currency=Column(String(8),default="EUR"); source=Column(String(80),default="user")

class ForecastAccuracy(Base):
    __tablename__="forecast_accuracy"
    id=Column(Integer,primary_key=True); farm_id=Column(Integer,ForeignKey("farms.id"),nullable=False)
    metric=Column(String(40),nullable=False); provider=Column(String(80),nullable=False); samples=Column(Integer,default=0)
    mae=Column(Float); mape=Column(Float); bias=Column(Float); score=Column(Float); error_std=Column(Float); weight=Column(Float); calibrated_confidence=Column(Float); season=Column(String(16),default='all'); condition=Column(String(24),default='all'); updated_at=Column(DateTime(timezone=True),default=utcnow,nullable=False)

class AssetPerformance(Base):
    __tablename__="asset_performance"
    id=Column(Integer,primary_key=True); miner_id=Column(Integer,ForeignKey("miners.id"),nullable=False)
    timestamp=Column(DateTime(timezone=True),nullable=False,default=utcnow); regime=Column(String(32),default='all')
    hashrate_ratio_pct=Column(Float); efficiency_j_th=Column(Float); temperature_c=Column(Float); power_w=Column(Float)
    score=Column(Float); metadata_json=Column(JSON,default=dict)
