from fastapi import FastAPI,Depends,Header,HTTPException,Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from pathlib import Path
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime,timezone
import asyncio
from .config import API_KEY,CORS_ORIGINS,POLL_INTERVAL_SECONDS,FORECAST_REFRESH_MINUTES,BOOTSTRAP_SECRET,BOOTSTRAP_EMAIL,BOOTSTRAP_PASSWORD,JWT_SECRET
from .db import Base,engine,get_db
from .migrations import ensure_schema
from .data_providers import fetch_day_ahead_prices, fetch_awattar_prices, fetch_pv_forecast, provider_capabilities
from .models import Farm,Miner,Telemetry,Alert,User,UserFarm,AuditLog,Subscription,EnergyProfile,EnergyTariff,ComputeOption,EnergyForecastSlot
from .schemas import *
from .services import market_data
from .connector import poll
from .worker import poll_once,polling_loop,forecast_loop
from .alerts import evaluate_farm_alerts,resolve_stale_alerts,farm_health,optimization
from .analytics import miner_timeseries,fleet_timeseries
from .auth import auth,hash_password,verify_password,create_token
from .energy import energy_context,optimize_farm,current_energy_price
from .market_intelligence import fx_rates
from .forecast_learning import score_farm, provider_calibration
from .forecast_ensemble import ensemble_forecast
from .asset_learning import asset_learning
from .digital_twin import build_twin
from .safe_dispatch import build_safe_plan
from .predictive_maintenance import maintenance_risk
from .portfolio_optimizer import optimize_portfolio
from .scenario_lab import run_scenarios
from .mining_economics import mining_economics
from .compute_economics import compute_economics
from .value_optimizer import value_per_kwh
from .mining_forecast import live_mining_market, forecast_mining_slots
from .compute_market import live_compute_market, normalize_compute_quotes
from .portfolio_allocator import allocate_portfolio
from .compute_capacity import compute_capacity_economics, vast_offers
from .compute_assets import ensure_asset_table, create_asset, list_assets, update_asset
from .dispatch_engine import build_dispatch_plan
from .data_quality import provenance
from .compute_telemetry import ensure_telemetry_table, record_telemetry, list_telemetry, probe_nvidia, telemetry_freshness
from .compute_revenue import ensure_revenue_table, record_revenue, revenue_rows, revenue_summary
from .energy_assets import ensure_energy_asset_tables, record_meter, readings as energy_readings, latest as latest_energy
from .battery_optimizer import optimize_battery
from .learning_loop import ensure_learning_table, record_feedback, learning_summary
from .profitability import score_asset, compare
from .ai_decision import decide
from .live_optimizer import build_live_optimizer
from .models import EnergyObservation, ForecastAccuracy
from .forecast import simulate, probabilistic_optimize
from .hardware_adapters import ensure_adapter_table, register_adapter, list_adapters, adapter_health, ingest_adapter_state
from .ml_calibration import ensure_calibration_table, add_sample, calibration, calibrate_value
from .multifarm import fleet_snapshot, aggregate_decisions
from .ai_core import ai_core
from .device_protocols import ensure_protocol_table, register_protocol, list_protocols, protocol_health, probe_rest
from .timeseries_store import ensure_ts_table, write_point, query_points
from .backtest import run_backtest
from .model_selection import select_model, confidence
from .autonomous_planner import build_plan
from .device_protocols_v51 import ensure_hardware_protocol_v51, register as register_v51_protocol, list_all as list_v51_protocols, probe as probe_v51_protocol
from .timeseries_v52 import ensure as ensure_ts_v52, write as write_ts_v52, read as read_ts_v52
from .backtest_v53 import run as run_backtest_v53
from .portfolio_routing import route_farms
from .safety_framework import ensure as ensure_safety, evaluate as evaluate_safety
from .planner_v55 import autonomous_plan
from .saas_db import db_status, table_names
from .demo import demo_snapshot
from .market_center import market_snapshot
from .value_center import rank_value, decision as value_decision
from .simulation_v99 import simulate_24h
from .connector_center import connectors
from .reports_v100 import release
from .feature_flags import get_flags,set_flags
from .synpora_core import platform_status
from .data_contracts import validate_energy
from .economics_normalizer import normalize,net_value
from .constraint_engine import check
from .decision_explainer import explain
from .audit_log import record,list_events
from .system_health import score as system_health_score
from .compatibility import compatibility
from .observability import observe,snapshot
from .rate_limits import allow
from .idempotency import once
from .secrets_boundary import sanitize_config
from .privacy import anonymize
from .deployment_readiness import assess
Base.metadata.create_all(bind=engine)
ensure_schema()
_stop_event=asyncio.Event()
@asynccontextmanager
async def lifespan(app):
    task=asyncio.create_task(polling_loop(_stop_event)); forecast_task=asyncio.create_task(forecast_loop(_stop_event,FORECAST_REFRESH_MINUTES)); yield; _stop_event.set(); await task; await forecast_task
app=FastAPI(title='SYNPORA Mining Intelligence API',version='1.0.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=['*'] if '*' in CORS_ORIGINS else CORS_ORIGINS,allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

def log(db,user,action,resource=None,metadata=None,request=None):
    uid=None if user.get('sub') in (None,'api-key') else int(user['sub']); db.add(AuditLog(user_id=uid,action=action,resource=resource,ip=request.client.host if request else None,metadata_json=metadata or {})); db.commit()
def user_obj(db,user):
    if user.get('sub')=='api-key':return None
    return db.get(User,int(user['sub']))
def ensure_farm(db,farm_id,user):
    farm=db.get(Farm,farm_id)
    if not farm: raise HTTPException(404,'Farm not found')
    if user.get('api_key') or user.get('role')=='owner' and user.get('sub')!='api-key': return farm
    if user.get('role')=='admin':
        if db.query(UserFarm).filter_by(user_id=int(user['sub']),farm_id=farm_id).first(): return farm
    if db.query(UserFarm).filter_by(user_id=int(user['sub']),farm_id=farm_id).first(): return farm
    raise HTTPException(403,'No access to this farm')
def require_write(db,farm_id,user):
    ensure_farm(db,farm_id,user)
    if user.get('api_key'): return
    if user.get('role') in ('owner','admin'): return
    access=db.query(UserFarm).filter_by(user_id=int(user['sub']),farm_id=farm_id).first()
    if not access or access.role not in ('owner','admin','operator'): raise HTTPException(403,'Write access required')

@app.get('/health')
def health(): return {'status':'ok','service':'synpora-api','version':'1.0.0','poll_interval_seconds':POLL_INTERVAL_SECONDS,'forecast_refresh_minutes':FORECAST_REFRESH_MINUTES,'auth':'api-key-or-jwt'}
@app.get('/api/v1/market')
async def market():
    try:return await market_data()
    except Exception as e:raise HTTPException(502,f'Market data unavailable: {e}')

@app.post('/api/v1/auth/bootstrap')
def bootstrap(p:BootstrapRequest,db:Session=Depends(get_db)):
    if p.secret!=BOOTSTRAP_SECRET and not (BOOTSTRAP_PASSWORD and p.email.lower()==BOOTSTRAP_EMAIL.lower() and p.password==BOOTSTRAP_PASSWORD): raise HTTPException(403,'Invalid bootstrap credentials')
    if db.query(User).count()>0: raise HTTPException(409,'Bootstrap already completed')
    if db.query(User).filter(User.email==p.email.lower()).first(): raise HTTPException(409,'User already exists')
    u=User(email=p.email.lower(),password_hash=hash_password(p.password),role='owner');db.add(u);db.flush();db.add(Subscription(user_id=u.id,plan='free'));db.commit();return {'user':UserOut.model_validate(u),'access_token':create_token(u.id,u.email,u.role),'token_type':'bearer'}
@app.get('/api/v1/auth/bootstrap/status')
def bootstrap_status(db:Session=Depends(get_db)):
    return {'setup_required': db.query(User).count()==0, 'bootstrap_email': BOOTSTRAP_EMAIL, 'message':'Use the bootstrap endpoint once to create the owner account.'}

@app.post('/api/v1/auth/login')
def login(p:LoginRequest,db:Session=Depends(get_db)):
    u=db.query(User).filter(User.email==p.email.lower()).first()
    if not u or not u.is_active or not verify_password(p.password,u.password_hash):raise HTTPException(401,'Invalid email or password')
    u.last_login_at=datetime.now(timezone.utc);db.commit();log(db,{'sub':str(u.id)},'login','user:'+str(u.id));return {'user':UserOut.model_validate(u),'access_token':create_token(u.id,u.email,u.role),'token_type':'bearer'}
@app.get('/api/v1/auth/me',response_model=UserOut)
def me(user=Depends(auth),db:Session=Depends(get_db)):
    u=user_obj(db,user)
    if not u: raise HTTPException(400,'API-key authentication has no user profile')
    return u
@app.get('/api/v1/auth/plan')
def plan(user=Depends(auth),db:Session=Depends(get_db)):
    if user.get('api_key'): return {'plan':'internal','status':'active','features':['all']}
    s=db.query(Subscription).filter_by(user_id=int(user['sub'])).first();return {'plan':s.plan if s else 'free','status':s.status if s else 'active','seats':s.seats if s else 1,'available_plans':{'free':{'farms':1,'miners':5},'pro':{'farms':10,'miners':250},'enterprise':{'farms':1000,'miners':100000}}}

@app.post('/api/v1/farms',response_model=FarmOut)
def create_farm(p:FarmCreate,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'):raise HTTPException(403,'Only owner/admin can create farms')
    o=Farm(**p.model_dump());db.add(o);db.flush()
    if not user.get('api_key'): db.add(UserFarm(user_id=int(user['sub']),farm_id=o.id,role='owner'))
    db.commit();db.refresh(o);log(db,user,'farm.create','farm:'+str(o.id),request=request);return o
@app.get('/api/v1/farms',response_model=list[FarmOut])
def farms(user=Depends(auth),db:Session=Depends(get_db)):
    if user.get('api_key') or user.get('role')=='owner': return db.query(Farm).order_by(Farm.id.desc()).all()
    ids=[x.farm_id for x in db.query(UserFarm).filter_by(user_id=int(user['sub'])).all()];return db.query(Farm).filter(Farm.id.in_(ids)).order_by(Farm.id.desc()).all() if ids else []
@app.post('/api/v1/farms/{farm_id}/members')
def add_member(farm_id:int,p:FarmAccessRequest,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    ensure_farm(db,farm_id,user)
    if not user.get('api_key') and user.get('role') not in ('owner','admin'):raise HTTPException(403,'Admin access required')
    target=db.query(User).filter(User.email==p.email.lower()).first()
    if not target:raise HTTPException(404,'User not found. User must log in/register via the controlled bootstrap flow first.')
    a=db.query(UserFarm).filter_by(user_id=target.id,farm_id=farm_id).first()
    if a:a.role=p.role
    else:db.add(UserFarm(user_id=target.id,farm_id=farm_id,role=p.role))
    db.commit();log(db,user,'farm.member.upsert',f'farm:{farm_id}',{'member':p.email,'role':p.role},request);return {'ok':True}

@app.post('/api/v1/miners',response_model=MinerOut)
def create_miner(p:MinerCreate,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    require_write(db,p.farm_id,user);o=Miner(**p.model_dump());db.add(o);db.commit();db.refresh(o);log(db,user,'miner.create','miner:'+str(o.id),request=request);return o
@app.get('/api/v1/farms/{farm_id}/miners',response_model=list[MinerOut])
def miners(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):ensure_farm(db,farm_id,user);return db.query(Miner).filter(Miner.farm_id==farm_id).all()
@app.post('/api/v1/telemetry')
def telemetry(p:TelemetryCreate,user=Depends(auth),db:Session=Depends(get_db)):
    m=db.get(Miner,p.miner_id)
    if not m:raise HTTPException(404,'Miner not found')
    ensure_farm(db,m.farm_id,user);data=p.model_dump();o=Telemetry(**data);db.add(o)
    if p.hashrate_ths is not None:m.hashrate_ths=p.hashrate_ths
    if p.power_w is not None:m.power_w=p.power_w
    m.status='error' if p.error_message else 'online';db.commit();evaluate_farm_alerts(db,m.farm_id);resolve_stale_alerts(db,m.farm_id);return {'accepted':True,'telemetry_id':o.id,'status':m.status}
@app.get('/api/v1/miners/{miner_id}/telemetry')
def telemetry_history(miner_id:int,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    m=db.get(Miner,miner_id)
    if not m:raise HTTPException(404,'Miner not found')
    ensure_farm(db,m.farm_id,user);rs=db.query(Telemetry).filter(Telemetry.miner_id==miner_id).order_by(desc(Telemetry.timestamp)).limit(min(limit,1000)).all();return [{'timestamp':r.timestamp,'hashrate_ths':r.hashrate_ths,'power_w':r.power_w,'temperature_c':r.temperature_c,'fan_pct':r.fan_pct,'uptime_pct':r.uptime_pct,'error_message':r.error_message} for r in rs]
@app.get('/api/v1/miners/{miner_id}/timeseries')
def miner_series(miner_id:int,hours:int=24,bucket_minutes:int=15,user=Depends(auth),db:Session=Depends(get_db)):
    m=db.get(Miner,miner_id)
    if not m:raise HTTPException(404,'Miner not found')
    ensure_farm(db,m.farm_id,user);return miner_timeseries(db,miner_id,hours,bucket_minutes)
@app.post('/api/v1/connectors/test')
def connector_test(host:str,port:int=4028,user=Depends(auth)):
    try:return {'ok':True,'telemetry':poll(host,port)}
    except Exception as e:raise HTTPException(502,f'Miner connector failed: {e}')
@app.post('/api/v1/connectors/poll/{miner_id}')
def connector_poll(miner_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    m=db.get(Miner,miner_id)
    if not m:raise HTTPException(404,'Miner not found')
    ensure_farm(db,m.farm_id,user)
    if not m.host:raise HTTPException(400,'Miner has no host/IP configured')
    try:data=poll(m.host,m.api_port or 4028)
    except Exception as e:
        m.status='offline';db.add(Telemetry(miner_id=m.id,error_message=str(e)));db.commit();evaluate_farm_alerts(db,m.farm_id);raise HTTPException(502,f'Miner connector failed: {e}')
    db.add(Telemetry(miner_id=m.id,hashrate_ths=data.get('hashrate_ths'),power_w=data.get('power_w'),temperature_c=data.get('temperature_c'),fan_pct=data.get('fan_pct')))
    if data.get('hashrate_ths') is not None:m.hashrate_ths=data['hashrate_ths']
    if data.get('power_w') is not None:m.power_w=data['power_w']
    m.status='online';db.commit();evaluate_farm_alerts(db,m.farm_id);resolve_stale_alerts(db,m.farm_id);return {'accepted':True,'miner_id':m.id,'status':m.status,'telemetry':data}

@app.get('/api/v1/farms/{farm_id}/fleet')
def fleet(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user);rows=[]
    for m in farm.miners:
        last=db.query(Telemetry).filter(Telemetry.miner_id==m.id).order_by(desc(Telemetry.timestamp)).first();h=(last.hashrate_ths if last and last.hashrate_ths is not None else m.hashrate_ths);p=(last.power_w if last and last.power_w is not None else m.power_w)
        rows.append({'id':m.id,'name':m.name,'manufacturer':m.manufacturer,'model':m.model,'status':m.status,'hashrate_ths':h,'power_w':p,'efficiency_j_th':p/h if h else None,'temperature_c':last.temperature_c if last else None,'host':m.host,'api_port':m.api_port})
    rows.sort(key=lambda x:x['efficiency_j_th'] if x['efficiency_j_th'] is not None else 999);return {'farm_id':farm_id,'miners':rows,'total_hashrate_ths':sum(x['hashrate_ths'] or 0 for x in rows),'total_power_kw':sum(x['power_w'] or 0 for x in rows)/1000,'online':sum(x['status']=='online' for x in rows),'offline':sum(x['status']=='offline' for x in rows)}
@app.get('/api/v1/farms/{farm_id}/timeseries')
def fleet_series(farm_id:int,hours:int=24,bucket_minutes:int=15,user=Depends(auth),db:Session=Depends(get_db)):ensure_farm(db,farm_id,user);return fleet_timeseries(db,farm_id,hours,bucket_minutes)
@app.get('/api/v1/polling/status')
def polling_status(user=Depends(auth)):return {'enabled':True,'interval_seconds':POLL_INTERVAL_SECONDS,'mode':'read-only','next_cycle':'automatic'}
@app.post('/api/v1/polling/run-once')
async def polling_run_once(user=Depends(auth)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'):raise HTTPException(403,'Admin access required')
    return {'results':await poll_once()}
@app.get('/api/v1/farms/{farm_id}/alerts')
def farm_alerts(farm_id:int,active:bool=True,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user);q=db.query(Alert).filter(Alert.farm_id==farm_id)
    if active:q=q.filter(Alert.resolved_at.is_(None))
    rows=q.order_by(desc(Alert.created_at)).limit(min(limit,500)).all();return [{'id':a.id,'miner_id':a.miner_id,'type':a.type,'severity':a.severity,'message':a.message,'created_at':a.created_at,'last_seen_at':a.last_seen_at,'resolved_at':a.resolved_at,'metadata':a.metadata_json or {}} for a in rows]
@app.post('/api/v1/alerts/{alert_id}/resolve')
def resolve_alert(alert_id:int,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    a=db.get(Alert,alert_id)
    if not a:raise HTTPException(404,'Alert not found')
    ensure_farm(db,a.farm_id,user);a.resolved_at=datetime.now(timezone.utc);db.commit();log(db,user,'alert.resolve','alert:'+str(a.id),request=request);return {'resolved':True,'alert_id':a.id}
@app.get('/api/v1/farms/{farm_id}/health')
def health_score(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):ensure_farm(db,farm_id,user);evaluate_farm_alerts(db,farm_id);resolve_stale_alerts(db,farm_id);return farm_health(db,farm_id)
@app.get('/api/v1/farms/{farm_id}/optimization')
async def optimization_score(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):ensure_farm(db,farm_id,user);evaluate_farm_alerts(db,farm_id);resolve_stale_alerts(db,farm_id);return await optimization(db,farm_id)
@app.get('/api/v1/audit')
def audit(limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'):raise HTTPException(403,'Admin access required')
    rows=db.query(AuditLog).order_by(desc(AuditLog.created_at)).limit(min(limit,500)).all();return [{'id':x.id,'user_id':x.user_id,'action':x.action,'resource':x.resource,'ip':x.ip,'metadata':x.metadata_json or {},'created_at':x.created_at} for x in rows]
@app.get('/api/v1/admin/users',response_model=list[UserOut])
def users(user=Depends(auth),db:Session=Depends(get_db)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'):raise HTTPException(403,'Admin access required')
    return db.query(User).order_by(User.id).all()


@app.get('/api/v1/farms/{farm_id}/energy')
def get_energy(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); return energy_context(db,farm)

@app.put('/api/v1/farms/{farm_id}/energy')
def put_energy(farm_id:int,p:EnergyProfileCreate,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    require_write(db,farm_id,user); obj=db.query(EnergyProfile).filter_by(farm_id=farm_id).first()
    if not obj: obj=EnergyProfile(farm_id=farm_id); db.add(obj)
    for k,v in p.model_dump().items(): setattr(obj,k,v)
    farm=db.get(Farm,farm_id); farm.electricity_price_eur_kwh=p.grid_import_price_eur_kwh
    db.commit(); log(db,user,'energy.update','farm:'+str(farm_id),request=request); return energy_context(db,farm)

@app.post('/api/v1/farms/{farm_id}/tariffs')
def add_tariff(farm_id:int,p:TariffCreate,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); x=EnergyTariff(farm_id=farm_id,**p.model_dump()); db.add(x); db.commit(); db.refresh(x); return x

@app.get('/api/v1/farms/{farm_id}/tariffs')
def list_tariffs(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return db.query(EnergyTariff).filter_by(farm_id=farm_id).all()

@app.post('/api/v1/farms/{farm_id}/compute-options')
def add_compute(farm_id:int,p:ComputeOptionCreate,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); x=ComputeOption(farm_id=farm_id,**p.model_dump()); db.add(x); db.commit(); db.refresh(x); return x

@app.get('/api/v1/farms/{farm_id}/compute-options')
def list_compute(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return db.query(ComputeOption).filter_by(farm_id=farm_id).all()


@app.get('/api/v1/farms/{farm_id}/energy/forecast')
def get_forecast(farm_id:int,hours:int=24,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    rows=db.query(EnergyForecastSlot).filter(EnergyForecastSlot.farm_id==farm_id,EnergyForecastSlot.timestamp>=now,EnergyForecastSlot.timestamp<now+__import__('datetime').timedelta(hours=min(hours,168))).order_by(EnergyForecastSlot.timestamp).all()
    return [{'timestamp':r.timestamp,'grid_price_eur_kwh':r.grid_price_eur_kwh,'pv_kw':r.pv_kw,'source':r.source,'provider':r.provider,'currency':r.currency,'fx_to_eur':r.fx_to_eur,'confidence_pct':r.confidence_pct,'forecast_run_id':r.forecast_run_id} for r in rows]

@app.put('/api/v1/farms/{farm_id}/energy/forecast')
def put_forecast(farm_id:int,p:list[ForecastSlotCreate],user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    if len(p)>168: raise HTTPException(400,'Maximum 168 hourly forecast slots')
    for x in p:
        old=db.query(EnergyForecastSlot).filter_by(farm_id=farm_id,timestamp=x.timestamp).first()
        if old: old.grid_price_eur_kwh=x.grid_price_eur_kwh; old.pv_kw=x.pv_kw; old.source=x.source
        else: db.add(EnergyForecastSlot(farm_id=farm_id,**x.model_dump()))
    db.commit(); log(db,user,'energy.forecast.update',f'farm:{farm_id}',{'slots':len(p)},request); return {'ok':True,'slots':len(p)}

@app.post('/api/v1/farms/{farm_id}/energy/forecast/refresh')
async def refresh_forecast(farm_id:int,hours:int=168,user=Depends(auth),db:Session=Depends(get_db),request:Request=None):
    farm=ensure_farm(db,farm_id,user); require_write(db,farm_id,user); hours=max(24,min(hours,168))
    p=db.query(EnergyProfile).filter_by(farm_id=farm_id).first()
    if not p: raise HTTPException(400,'Energy profile must be configured first')
    prices=[]; pv=[]; errors=[]
    try: prices=await fetch_day_ahead_prices((p.market_zone or p.country_code or '').upper(),hours)
    except Exception as e: errors.append(f'price:{e}')
    if p.latitude is not None and p.longitude is not None and p.pv_capacity_kw>0:
        try: pv=await fetch_pv_forecast(p.latitude,p.longitude,p.pv_capacity_kw,p.pv_tilt_deg or 35,p.pv_azimuth_deg or 0,hours,p.timezone or 'UTC')
        except Exception as e: errors.append(f'pv:{e}')
    by_price={x['timestamp'].replace(minute=0,second=0,microsecond=0):x for x in prices}
    by_pv={x['timestamp'].replace(minute=0,second=0,microsecond=0):x for x in pv}
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    count=0
    for i in range(hours):
        ts=now+__import__('datetime').timedelta(hours=i); pr=by_price.get(ts); pvx=by_pv.get(ts)
        if not pr and not pvx: continue
        old=db.query(EnergyForecastSlot).filter_by(farm_id=farm_id,timestamp=ts).first()
        obj=old or EnergyForecastSlot(farm_id=farm_id,timestamp=ts,grid_price_eur_kwh=(pr['grid_price_eur_kwh'] if pr else current_energy_price(db,farm)),pv_kw=0,source='provider')
        if pr: obj.grid_price_eur_kwh=pr['grid_price_eur_kwh']; obj.provider=pr['source'].split(':')[0]; obj.confidence_pct=85
        if pvx: obj.pv_kw=pvx['pv_kw']; obj.provider='open-meteo' if not pr else obj.provider; obj.confidence_pct=min(obj.confidence_pct or 70,80)
        obj.currency='EUR'; obj.fx_to_eur=1.0
        sources=[x['source'] for x in (pr,pvx) if x]
        obj.source='+'.join(sources) or 'fallback'; db.add(obj); count+=1
    db.commit(); log(db,user,'energy.forecast.refresh',f'farm:{farm_id}',{'slots':count,'errors':errors},request)
    return {'ok':True,'farm_id':farm_id,'slots':count,'hours':hours,'sources':{'price':bool(prices),'pv':bool(pv),'price_zone':p.market_zone or p.country_code or 'tariff-fallback'},'errors':errors,'global_scope':True}

@app.get('/api/v1/farms/{farm_id}/energy/providers')
def energy_providers(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); p=db.query(EnergyProfile).filter_by(farm_id=farm_id).first()
    zone=(p.market_zone if p else '') or (p.country_code if p else '') or ''
    return {'global_pv':True,'pv_provider':'Open-Meteo / global weather models','pv_scope':'worldwide','price_provider':'ENTSO-E where supported; custom global endpoint or local tariff elsewhere','price_zone':zone or None,'entsoe_supported':zone.upper() in __import__('app.data_providers',fromlist=['ENTSOE_ZONES']).ENTSOE_ZONES,'custom_global_price_configured':bool(__import__('app.config',fromlist=['SYNPORA_GLOBAL_PRICE_URL']).SYNPORA_GLOBAL_PRICE_URL)}

@app.get('/api/v1/farms/{farm_id}/energy/market-capabilities')
def market_capabilities(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); p=db.query(EnergyProfile).filter_by(farm_id=farm_id).first(); zone=(p.market_zone if p else '') or (p.country_code if p else '') or ''
    return provider_capabilities(zone)

@app.get('/api/v1/fx/rates')
async def fx_rate_table(base:str='EUR',user=Depends(auth)):
    return await fx_rates(base)

@app.post('/api/v1/farms/{farm_id}/energy/observations')
def add_energy_observation(farm_id:int,p:EnergyObservationCreate,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); o=EnergyObservation(farm_id=farm_id,**p.model_dump()); db.add(o); db.commit(); return {'ok':True,'id':o.id}

@app.get('/api/v1/farms/{farm_id}/energy/forecast-accuracy')
def forecast_accuracy(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); rows=db.query(ForecastAccuracy).filter_by(farm_id=farm_id).order_by(ForecastAccuracy.metric,ForecastAccuracy.provider).all()
    if not rows: score_farm(db,farm_id); rows=db.query(ForecastAccuracy).filter_by(farm_id=farm_id).all()
    return [{'metric':r.metric,'provider':r.provider,'samples':r.samples,'mae_pct':r.mae,'bias_pct':r.bias,'error_std_pct':r.error_std,'weight':r.weight,'calibrated_confidence_pct':r.calibrated_confidence,'score':r.score,'updated_at':r.updated_at} for r in rows]

@app.post('/api/v1/farms/{farm_id}/energy/forecast-accuracy/recalculate')
def recalculate_forecast_accuracy(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'ok':True,'results':score_farm(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/energy/forecast-learning')
def forecast_learning(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    rows=db.query(ForecastAccuracy).filter_by(farm_id=farm_id).order_by(ForecastAccuracy.metric,ForecastAccuracy.provider).all()
    if not rows: score_farm(db,farm_id); rows=db.query(ForecastAccuracy).filter_by(farm_id=farm_id).all()
    return {'farm_id':farm_id,'mode':'adaptive_provider_calibration','metrics':[{'metric':r.metric,'provider':r.provider,'samples':r.samples,'weight':r.weight or 1.0,'bias_pct':r.bias or 0.0,'error_std_pct':r.error_std or r.mae or 15.0,'confidence_pct':r.calibrated_confidence or r.score or 70.0} for r in rows]}

@app.post('/api/v1/farms/{farm_id}/energy/forecast-learning/recalculate')
def recalculate_forecast_learning(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user)
    ensure_farm(db,farm_id,user)
    return {'ok':True,'results':score_farm(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/dispatch-simulation')
async def dispatch_simulation(farm_id:int,hours:int=24,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); market=await market_data(); return simulate(db,farm,market,max(1,min(hours,168)))



@app.get('/api/v1/farms/{farm_id}/energy/condition-learning')
def condition_learning(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    rows=db.query(ForecastAccuracy).filter_by(farm_id=farm_id).filter(ForecastAccuracy.season.isnot(None)).order_by(ForecastAccuracy.metric,ForecastAccuracy.provider,ForecastAccuracy.season,ForecastAccuracy.condition).all()
    return {'farm_id':farm_id,'mode':'seasonal_weather_condition_learning','conditions':[{'metric':r.metric,'provider':r.provider,'season':r.season,'condition':r.condition,'samples':r.samples,'mae_pct':r.mae,'bias_pct':r.bias,'weight':r.weight,'confidence_pct':r.calibrated_confidence} for r in rows]}

@app.post('/api/v1/farms/{farm_id}/energy/condition-learning/recalculate')
def recalculate_condition_learning(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user)
    ensure_farm(db,farm_id,user)
    from .condition_learning import learn_conditions
    return {'ok':True,'results':learn_conditions(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/asset-learning')
def asset_learning_endpoint(farm_id:int,lookback_hours:int=2160,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return asset_learning(db,farm_id,max(24,min(lookback_hours,24*365)))

@app.post('/api/v1/farms/{farm_id}/asset-learning/recalculate')
def asset_learning_recalculate(farm_id:int,lookback_hours:int=2160,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'ok':True,'results':asset_learning(db,farm_id,max(24,min(lookback_hours,24*365)))}

@app.get('/api/v1/farms/{farm_id}/digital-twin')
def digital_twin(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); return build_twin(db,farm)

@app.get('/api/v1/farms/{farm_id}/energy/forecast-ensemble')
def forecast_ensemble(farm_id:int,hours:int=168,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user)
    slots=ensemble_forecast(db,farm,max(1,min(hours,168)))
    return {'version':'15.0','farm_id':farm_id,'generated_at':datetime.now(timezone.utc),'mode':'learned_time_aware_provider_ensemble','slots':slots}

@app.get('/api/v1/farms/{farm_id}/probabilistic-optimization')
async def probabilistic_optimization(farm_id:int,hours:int=168,risk_aversion:float=0.35,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); market=await market_data()
    return probabilistic_optimize(db,farm,market,max(1,min(hours,168)),risk_aversion)

@app.get('/api/v1/farms/{farm_id}/safe-dispatch-plan')
async def safe_dispatch_plan(farm_id:int,hours:int=168,risk_aversion:float=0.35,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); market=await market_data(); prob=probabilistic_optimize(db,farm,market,max(1,min(hours,168)),risk_aversion); return build_safe_plan(prob)

@app.get('/api/v1/farms/{farm_id}/energy-optimization')
async def energy_optimization(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); market=await market_data(); return await optimize_farm(db,farm,market)

@app.get('/api/v1/farms/{farm_id}/energy/intelligence-v11')
async def energy_intelligence_v11(farm_id:int,hours:int=168,user=Depends(auth),db:Session=Depends(get_db)):
    from .intelligence_v11 import probabilistic_slots, ensemble_summary
    farm=ensure_farm(db,farm_id,user)
    market=await market_data()
    result=simulate(db,farm,market,max(1,min(hours,168)))
    slots=probabilistic_slots(result['slots'])
    return {'version':'11.0','farm_id':farm_id,'generated_at':datetime.now(timezone.utc),'ensemble':ensemble_summary(slots),'slots':slots,
            'dispatch_summary':result['summary'],'assumptions':{'mode':'probabilistic forecast overlay','read_only':True}}


@app.get('/api/v1/farms/{farm_id}/maintenance-risk')
def maintenance_risk_endpoint(farm_id:int,lookback_hours:int=720,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return maintenance_risk(db,farm_id,min(max(24,lookback_hours),24*365))

@app.get('/api/v1/portfolio/snapshot')
def portfolio_snapshot_endpoint(user=Depends(auth),db:Session=Depends(get_db)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'): raise HTTPException(403,'Admin access required')
    from .portfolio_optimizer import portfolio_snapshot
    return {'farms':portfolio_snapshot(db)}

@app.post('/api/v1/portfolio/optimize')
def portfolio_optimize_endpoint(max_kw:float|None=None,user=Depends(auth),db:Session=Depends(get_db)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin'): raise HTTPException(403,'Admin access required')
    return optimize_portfolio(db,max_kw)

@app.post('/api/v1/scenario-lab/run')
def scenario_lab_endpoint(payload:dict|None=None,user=Depends(auth),db:Session=Depends(get_db)):
    if not user.get('api_key') and user.get('role') not in ('owner','admin','operator'): raise HTTPException(403,'Operator access required')
    return run_scenarios(db,(payload or {}).get('scenarios'))


@app.get('/api/v1/farms/{farm_id}/mining-economics')
async def mining_economics_endpoint(farm_id:int,pool_fee_pct:float=2.0,uptime_pct:float=98.0,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); market=await market_data(); return mining_economics(db,farm_id,market,pool_fee_pct,uptime_pct)

@app.get('/api/v1/farms/{farm_id}/compute-economics')
def compute_economics_endpoint(farm_id:int,risk_discount_pct:float=10.0,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return compute_economics(db,farm_id,risk_discount_pct)

@app.get('/api/v1/farms/{farm_id}/value-per-kwh')
async def value_per_kwh_endpoint(farm_id:int,risk_aversion:float=0.25,pv_available_kw:float=0.0,grid_price:float|None=None,export_price:float|None=None,user=Depends(auth),db:Session=Depends(get_db)):
    farm=ensure_farm(db,farm_id,user); return await value_per_kwh(db,farm,max(0,min(.95,risk_aversion)),max(0,pv_available_kw),grid_price,export_price)


@app.get('/api/v1/farms/{farm_id}/mining/forecast')
async def mining_forecast_endpoint(farm_id:int,hours:int=168,btc_growth_daily:float=0.0,hashrate_growth_daily:float=0.001,
                                   user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    spot=await live_mining_market()
    return forecast_mining_slots(db,farm_id,max(1,min(hours,168)),btc_growth_daily,hashrate_growth_daily,spot=spot)

@app.post('/api/v1/farms/{farm_id}/mining/forecast/recalculate')
async def mining_forecast_recalculate(farm_id:int,hours:int=168,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    spot=await live_mining_market()
    result=forecast_mining_slots(db,farm_id,max(1,min(hours,168)),spot=spot)
    log(db,user,'mining.forecast.recalculate',f'farm:{farm_id}',{'hours':hours,'source':spot.get('source')})
    return {'ok':True,**result}

@app.get('/api/v1/farms/{farm_id}/compute/market')
async def compute_market_endpoint(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    data=await live_compute_market()
    # Use a conservative public FX anchor if available; EUR conversion is configurable in production.
    try:
        fx=await fx_rates('EUR'); usd_eur=1/float(fx['rates'].get('USD',1.0))
    except Exception: usd_eur=.92
    return {**data,'quotes':normalize_compute_quotes(data.get('rows',[]),usd_eur=usd_eur)}

@app.post('/api/v1/farms/{farm_id}/compute/market/refresh')
async def compute_market_refresh(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    data=await live_compute_market()
    log(db,user,'compute.market.refresh',f'farm:{farm_id}',{'rows':len(data.get('rows',[]))})
    return {'ok':True,**data}

@app.get('/api/v1/farms/{farm_id}/portfolio/allocator')
async def portfolio_allocator_endpoint(farm_id:int,hours:int=24,risk_aversion:float=.25,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    spot=await live_mining_market()
    mf=forecast_mining_slots(db,farm_id,max(1,min(hours,168)),spot=spot)
    cm=await live_compute_market()
    try:
        fx=await fx_rates('EUR'); usd_eur=1/float(fx['rates'].get('USD',1.0))
    except Exception: usd_eur=.92
    quotes=normalize_compute_quotes(cm.get('rows',[]),usd_eur=usd_eur)
    return allocate_portfolio(db,farm_id,mf,quotes,max(1,min(hours,168)),max(0,min(.95,risk_aversion)))

@app.post('/api/v1/farms/{farm_id}/portfolio/allocator/recalculate')
async def portfolio_allocator_recalculate(farm_id:int,hours:int=168,risk_aversion:float=.25,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    spot=await live_mining_market(); mf=forecast_mining_slots(db,farm_id,max(1,min(hours,168)),spot=spot)
    cm=await live_compute_market()
    try:
        fx=await fx_rates('EUR'); usd_eur=1/float(fx['rates'].get('USD',1.0))
    except Exception: usd_eur=.92
    result=allocate_portfolio(db,farm_id,mf,normalize_compute_quotes(cm.get('rows',[]),usd_eur=usd_eur),max(1,min(hours,168)),max(0,min(.95,risk_aversion)))
    log(db,user,'portfolio.allocator.recalculate',f'farm:{farm_id}',{'hours':hours,'mining_source':spot.get('source'),'compute_source':cm.get('source')})
    return {'ok':True,**result}


@app.get('/api/v1/farms/{farm_id}/compute/capacity-economics')
async def compute_capacity_economics_endpoint(
    farm_id:int, gpu_name:str, power_kw:float,
    utilization_pct:float=90, hosting_fee_pct:float=15,
    variable_cost_eur_hour:float=0, risk_discount_pct:float=10,
    grid_price_eur_kwh:float|None=None,
    user=Depends(auth), db:Session=Depends(get_db)
):
    ensure_farm(db,farm_id,user)
    farm=db.get(Farm,farm_id)
    price=grid_price_eur_kwh if grid_price_eur_kwh is not None else float(farm.electricity_price_eur_kwh or 0)
    try:
        return await compute_capacity_economics(
            gpu_name=gpu_name, power_kw=power_kw,
            grid_price_eur_kwh=price,
            utilization_pct=utilization_pct,
            hosting_fee_pct=hosting_fee_pct,
            variable_cost_eur_hour=variable_cost_eur_hour,
            risk_discount_pct=risk_discount_pct
        )
    except Exception as e:
        raise HTTPException(502,f'Compute market/capacity data unavailable: {e}')

@app.get('/api/v1/compute/vast/offers')
async def vast_offers_endpoint(gpu_name:str|None=None, limit:int=20, user=Depends(auth)):
    try:
        return await vast_offers(gpu_name=gpu_name,limit=max(1,min(limit,100)))
    except Exception as e:
        raise HTTPException(502,f'Vast.ai offers unavailable: {e}')


# ---------------- v29–v31 ----------------

@app.post('/api/v1/farms/{farm_id}/compute/assets')
def compute_asset_create(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    ensure_asset_table(db)
    required={"name","power_kw"}
    if not required.issubset(p): raise HTTPException(400,"name and power_kw required")
    data={"name":p["name"],"asset_type":p.get("asset_type","gpu"),"model":p.get("model"),
          "quantity":int(p.get("quantity",1)),"power_kw":float(p["power_kw"]),
          "capacity_units":float(p.get("capacity_units",1)),
          "compute_market_key":p.get("compute_market_key"),
          "enabled":1 if p.get("enabled",True) else 0}
    create_asset(db,farm_id,data)
    return {"ok":True,"farm_id":farm_id,"assets":list_assets(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/compute/assets')
def compute_asset_list(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {"farm_id":farm_id,"assets":list_assets(db,farm_id)}

@app.patch('/api/v1/compute/assets/{asset_id}')
def compute_asset_update(asset_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    # Access is checked against the asset's farm before update.
    ensure_asset_table(db)
    from sqlalchemy import text
    row=db.execute(text("SELECT farm_id FROM compute_assets WHERE id=:id"),{"id":asset_id}).first()
    if not row: raise HTTPException(404,"Compute asset not found")
    require_write(db,row[0],user)
    update_asset(db,asset_id,p)
    return {"ok":True,"asset_id":asset_id}

@app.get('/api/v1/farms/{farm_id}/compute/capacity-plan')
async def compute_capacity_plan(farm_id:int,hours:int=24,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    assets=list_assets(db,farm_id)
    quotes=await live_compute_market()
    # Return a transparent asset-to-market matching layer. No automatic provisioning.
    rows=[]
    for a in assets:
        key=(a.get("compute_market_key") or a.get("model") or a.get("name") or "")
        candidates=[q for q in quotes.get("rows",[]) if key.lower() in (q.get("gpu_name") or "").lower() or key.lower() in (q.get("gpu_key") or "").lower()]
        best=max(candidates,key=lambda x:x.get("offers") or 0) if candidates else None
        rows.append({"asset":a,"market_match":best,"matched":bool(best),
                     "provenance":provenance(quotes.get("source","gridcompute"),True,quote_type="market")})
    return {"version":"29.0","farm_id":farm_id,"horizon_hours":max(1,min(hours,168)),
            "assets":rows,"automatic_provisioning":False}

@app.get('/api/v1/farms/{farm_id}/data-quality')
async def data_quality_endpoint(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    mining=await live_mining_market()
    compute=await live_compute_market()
    return {"version":"31.0","farm_id":farm_id,
            "sources":[
              provenance(mining.get("source","mempool"),True,quote_type="market"),
              provenance(compute.get("source","gridcompute"),True,quote_type="market")
            ]}

@app.get('/api/v1/farms/{farm_id}/portfolio/dispatch-v30')
async def portfolio_dispatch_v30(farm_id:int,hours:int=24,risk_aversion:float=.25,
                                 user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    hours=max(1,min(hours,168))
    spot=await live_mining_market()
    mf=forecast_mining_slots(db,farm_id,hours,spot=spot)
    cm=await live_compute_market()
    try:
        fx=await fx_rates('EUR'); usd_eur=1/float(fx['rates'].get('USD',1.0))
    except Exception: usd_eur=.92
    quotes=normalize_compute_quotes(cm.get("rows",[]),usd_eur=usd_eur)
    # Build a farm-level compute capacity from registered GPU assets.
    assets=list_assets(db,farm_id)
    compute_cap=sum(float(a.get("power_kw") or 0)*int(a.get("quantity") or 1)
                    for a in assets if int(a.get("enabled") or 0))
    if not compute_cap:
        compute_cap=sum(float(x.get("power_kw") or 0) for x in quotes if x.get("power_kw")) or 0
    farm=db.get(Farm,farm_id)
    p=db.query(EnergyProfile).filter_by(farm_id=farm_id).first()
    grid_cap=float(p.max_grid_import_kw) if p and p.max_grid_import_kw is not None else float(farm.power_limit_kw or 0)
    mining_cap=sum(float(m.power_w or 0)/1000 for m in farm.miners)
    grid_price=float(p.grid_import_price_eur_kwh) if p else float(farm.electricity_price_eur_kwh or 0)
    mining_values=[]; compute_values=[]; grid_prices=[]; pv=[]
    base_slots={x["timestamp"]:x for x in mf["slots"] if x["scenario"]=="base"}
    best_compute=max([float(q.get("risk_adjusted_value_eur_kwh") or 0) for q in quotes] or [0])
    from datetime import datetime,timezone,timedelta
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    for i in range(hours):
        ts=(now+timedelta(hours=i)).isoformat()
        hp=float(base_slots.get(ts,{}).get("hashprice_eur_th_day") or 0)
        vals=[]
        for m in farm.miners:
            kw=float(m.power_w or 0)/1000; th=float(m.hashrate_ths or 0)
            if kw: vals.append(hp*th/(kw*24))
        mining_values.append(sum(vals)/len(vals) if vals else 0)
        compute_values.append(best_compute)
        grid_prices.append(grid_price)
        pv.append(0)
    plan=build_dispatch_plan(hours,grid_prices,pv,mining_values,compute_values,
                             grid_limit_kw=grid_cap,mining_cap_kw=mining_cap,
                             compute_cap_kw=compute_cap,risk_aversion=risk_aversion)
    plan["provenance"]={"mining":spot.get("source"),"compute":cm.get("source")}
    return plan


# ---------------- v32–v35: telemetry, realized compute economics, live optimizer, control center ----------------

@app.post('/api/v1/farms/{farm_id}/compute/telemetry')
def compute_telemetry_ingest(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); ensure_telemetry_table(db)
    asset_id=p.get('asset_id')
    if not asset_id: raise HTTPException(400,'asset_id required')
    from sqlalchemy import text
    a=db.execute(text('SELECT farm_id FROM compute_assets WHERE id=:id'),{'id':int(asset_id)}).first()
    if not a or int(a[0])!=farm_id: raise HTTPException(404,'Compute asset not found for this farm')
    record_telemetry(db,int(asset_id),p,p.get('source','api'))
    return {'accepted':True,'asset_id':int(asset_id),'freshness':telemetry_freshness(list_telemetry(db,asset_id=int(asset_id),limit=1))}

@app.get('/api/v1/farms/{farm_id}/compute/telemetry')
def compute_telemetry_farm(farm_id:int,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); rows=list_telemetry(db,farm_id=farm_id,limit=limit)
    return {'version':'32.0','farm_id':farm_id,'rows':rows,'freshness':telemetry_freshness(rows)}

@app.get('/api/v1/compute/assets/{asset_id}/telemetry')
def compute_telemetry_asset(asset_id:int,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    from sqlalchemy import text
    row=db.execute(text('SELECT farm_id FROM compute_assets WHERE id=:id'),{'id':asset_id}).first()
    if not row: raise HTTPException(404,'Compute asset not found')
    ensure_farm(db,row[0],user); rows=list_telemetry(db,asset_id=asset_id,limit=limit)
    return {'version':'32.0','asset_id':asset_id,'rows':rows,'freshness':telemetry_freshness(rows)}

@app.post('/api/v1/compute/telemetry/probe')
def compute_telemetry_probe(asset_id:int|None=None,user=Depends(auth),db:Session=Depends(get_db)):
    result=probe_nvidia(asset_id)
    if asset_id and result.get('rows'):
        from sqlalchemy import text
        row=db.execute(text('SELECT farm_id FROM compute_assets WHERE id=:id'),{'id':asset_id}).first()
        if not row: raise HTTPException(404,'Compute asset not found')
        ensure_farm(db,row[0],user); require_write(db,row[0],user)
        for x in result['rows']: record_telemetry(db,asset_id,x,'nvidia-smi')
    return result

@app.post('/api/v1/farms/{farm_id}/compute/revenue')
def compute_revenue_ingest(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); ensure_revenue_table(db)
    asset_id=p.get('asset_id')
    if not asset_id: raise HTTPException(400,'asset_id required')
    from sqlalchemy import text
    a=db.execute(text('SELECT farm_id FROM compute_assets WHERE id=:id'),{'id':int(asset_id)}).first()
    if not a or int(a[0])!=farm_id: raise HTTPException(404,'Compute asset not found for this farm')
    result=record_revenue(db,int(asset_id),p)
    return {'accepted':True,'asset_id':int(asset_id),**result}

@app.get('/api/v1/farms/{farm_id}/compute/revenue')
def compute_revenue_farm(farm_id:int,limit:int=200,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'33.0','farm_id':farm_id,'rows':revenue_rows(db,farm_id=farm_id,limit=limit)}

@app.get('/api/v1/compute/assets/{asset_id}/revenue')
def compute_revenue_asset(asset_id:int,limit:int=200,user=Depends(auth),db:Session=Depends(get_db)):
    from sqlalchemy import text
    row=db.execute(text('SELECT farm_id FROM compute_assets WHERE id=:id'),{'id':asset_id}).first()
    if not row: raise HTTPException(404,'Compute asset not found')
    ensure_farm(db,row[0],user); return {'version':'33.0','asset_id':asset_id,'rows':revenue_rows(db,asset_id=asset_id,limit=limit)}

@app.get('/api/v1/farms/{farm_id}/compute/revenue-summary')
def compute_revenue_summary(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'33.0','farm_id':farm_id,**revenue_summary(db,farm_id)}

async def _live_optimizer_payload(farm_id,hours,risk_aversion,db):
    hours=max(1,min(hours,168)); spot=await live_mining_market(); mf=forecast_mining_slots(db,farm_id,hours,spot=spot)
    cm=await live_compute_market()
    try:
        fx=await fx_rates('EUR'); usd_eur=1/float(fx['rates'].get('USD',1.0))
    except Exception: usd_eur=.92
    quotes=normalize_compute_quotes(cm.get('rows',[]),usd_eur=usd_eur)
    assets=list_assets(db,farm_id); compute_cap=sum(float(a.get('power_kw') or 0)*int(a.get('quantity') or 1) for a in assets if int(a.get('enabled') or 0))
    farm=db.get(Farm,farm_id); ep=db.query(EnergyProfile).filter_by(farm_id=farm_id).first()
    grid_cap=float(ep.max_grid_import_kw) if ep and ep.max_grid_import_kw is not None else float(farm.power_limit_kw or 0)
    mining_cap=sum(float(m.power_w or 0)/1000 for m in farm.miners)
    best_compute=max([float(q.get('risk_adjusted_value_eur_kwh') or 0) for q in quotes] or [0])
    forecast=db.query(EnergyForecastSlot).filter(EnergyForecastSlot.farm_id==farm_id).order_by(EnergyForecastSlot.timestamp).limit(hours).all()
    if not forecast:
        grid=float(ep.grid_import_price_eur_kwh) if ep else float(farm.electricity_price_eur_kwh or 0); energy=[{'grid_price_eur_kwh':grid,'pv_kw':0,'confidence_pct':40} for _ in range(hours)]
    else: energy=[{'grid_price_eur_kwh':x.grid_price_eur_kwh,'pv_kw':x.pv_kw,'confidence_pct':x.confidence_pct,'source':x.source} for x in forecast]
    base={x['timestamp']:x for x in mf['slots'] if x['scenario']=='base'}; mining_values=[]
    from datetime import datetime,timezone,timedelta
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    for i in range(hours):
        ts=(now+timedelta(hours=i)).isoformat(); hp=float(base.get(ts,{}).get('hashprice_eur_th_day') or 0); vals=[]
        for m in farm.miners:
            kw=float(m.power_w or 0)/1000; th=float(m.hashrate_ths or 0)
            if kw: vals.append(hp*th/(kw*24))
        mining_values.append(sum(vals)/len(vals) if vals else 0)
    plan=build_live_optimizer(hours,energy,mining_values,[best_compute]*hours,mining_cap,compute_cap,grid_cap,
                              float(ep.pv_capacity_kw or 0) if ep else 0,risk_aversion)
    plan['provenance']={'mining':spot.get('source'),'compute':cm.get('source'),'energy':energy[0].get('source') if energy else 'fallback'}
    return plan

@app.get('/api/v1/farms/{farm_id}/optimizer/live')
async def optimizer_live(farm_id:int,hours:int=24,risk_aversion:float=.25,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return await _live_optimizer_payload(farm_id,hours,max(0,min(.95,risk_aversion)),db)

@app.post('/api/v1/farms/{farm_id}/optimizer/live/recalculate')
async def optimizer_live_recalculate(farm_id:int,hours:int=24,risk_aversion:float=.25,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); result=await _live_optimizer_payload(farm_id,hours,max(0,min(.95,risk_aversion)),db)
    log(db,user,'optimizer.live.recalculate',f'farm:{farm_id}',{'hours':hours}); return {'ok':True,**result}

@app.get('/api/v1/farms/{farm_id}/control-center')
async def control_center(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); farm=db.get(Farm,farm_id); assets=list_assets(db,farm_id)
    health=farm_health(db,farm_id); rev=revenue_summary(db,farm_id)
    tel=list_telemetry(db,farm_id=farm_id,limit=50); fresh=telemetry_freshness(tel)
    optimizer=await _live_optimizer_payload(farm_id,24,.25,db)
    dq=await data_quality_endpoint(farm_id,user,db)
    best=optimizer['rows'][0] if optimizer.get('rows') else {}
    return {'version':'35.0','farm':{'id':farm.id,'name':farm.name},'kpis':{
      'current_best_eur_kwh':best.get('chosen_value_eur_kwh',0),'btc_eur_kwh':best.get('mining_value_eur_kwh',0),
      'ai_eur_kwh':best.get('compute_value_eur_kwh',0),'energy_price_eur_kwh':best.get('grid_price_eur_kwh',0),
      'pv_kw':best.get('pv_kw',0),'compute_utilization_pct':rev.get('avg_utilization_pct',0),'telemetry_score':fresh.get('score',0),
      'fleet_health_score':health.get('score',0) if isinstance(health,dict) else 0},
      'decision':best,'optimizer':optimizer,'assets':assets,'revenue':rev,'data_quality':dq,'read_only':True,'control_commands_sent':False}

@app.get('/api/v1/farms/{farm_id}/control-center/summary')
async def control_center_summary(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    data=await control_center(farm_id,user,db)
    return {'version':'35.0','farm':data['farm'],'kpis':data['kpis'],'decision':data['decision'],'read_only':True}


@app.post('/api/v1/farms/{farm_id}/energy/meter')
def energy_meter_ingest(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); record_meter(db,farm_id,p)
    return {'accepted':True,'version':'36.0','latest':latest_energy(db,farm_id),'mode':'read-only-ingestion'}

@app.get('/api/v1/farms/{farm_id}/energy/meter')
def energy_meter_history(farm_id:int,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); rows=energy_readings(db,farm_id,limit); return {'version':'36.0','farm_id':farm_id,'rows':rows,'latest':rows[0] if rows else None}

@app.get('/api/v1/farms/{farm_id}/energy/live-state')
def energy_live_state(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); row=latest_energy(db,farm_id)
    return {'version':'36.0','farm_id':farm_id,'state':row,'source':row.get('source') if row else None,'read_only':True}

@app.post('/api/v1/farms/{farm_id}/battery/optimize')
def battery_optimize_endpoint(farm_id:int,hours:int=24,soc_pct:float=50,capacity_kwh:float=10,max_charge_kw:float=5,max_discharge_kw:float=5,reserve_pct:float=10,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); ep=db.query(EnergyProfile).filter_by(farm_id=farm_id).first(); slots=db.query(EnergyForecastSlot).filter(EnergyForecastSlot.farm_id==farm_id).order_by(EnergyForecastSlot.timestamp).limit(max(1,min(hours,168))).all()
    energy=[{'grid_price_eur_kwh':x.grid_price_eur_kwh,'pv_kw':x.pv_kw} for x in slots]
    if not energy: energy=[{'grid_price_eur_kwh':float(ep.grid_import_price_eur_kwh) if ep else 0,'pv_kw':0} for _ in range(hours)]
    result=optimize_battery(hours,energy,soc_pct,capacity_kwh,max_charge_kw,max_discharge_kw,reserve_pct); result['farm_id']=farm_id; return result

@app.post('/api/v1/farms/{farm_id}/learning/feedback')
def learning_feedback(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'accepted':True,'version':'38.0',**record_feedback(db,farm_id,p)}

@app.get('/api/v1/farms/{farm_id}/learning/summary')
def learning_summary_endpoint(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'38.0','farm_id':farm_id,**learning_summary(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/profitability')
async def profitability_endpoint(farm_id:int,hours:int=24,risk_discount:float=.15,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); plan=await _live_optimizer_payload(farm_id,hours,risk_discount,db); row=plan['rows'][0] if plan.get('rows') else {}; energy=float(row.get('grid_price_eur_kwh') or 0)
    candidates=[]
    for source,key in [('BTC_MINING','mining_value_eur_kwh'),('AI_COMPUTE','compute_value_eur_kwh')]:
        candidates.append({'source':source,**score_asset(row.get(key),energy,100,100,risk_discount)})
    return {'version':'39.0','farm_id':farm_id,'candidates':compare(candidates),'provenance':plan.get('provenance',{}),'read_only':True}

@app.get('/api/v1/farms/{farm_id}/ai/decision')
async def ai_decision_endpoint(farm_id:int,hours:int=24,risk_discount:float=.15,min_spread:float=.01,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); plan=await _live_optimizer_payload(farm_id,hours,risk_discount,db); row=plan['rows'][0] if plan.get('rows') else {}; energy=float(row.get('grid_price_eur_kwh') or 0)
    candidates=[]
    for source,key in [('BTC_MINING','mining_value_eur_kwh'),('AI_COMPUTE','compute_value_eur_kwh')]: candidates.append({'source':source,**score_asset(row.get(key),energy,100,100,risk_discount)})
    conf=float(row.get('confidence_pct') or 50); result=decide(candidates,conf,min_spread); result.update({'version':'40.0','farm_id':farm_id,'generated_at':datetime.now(timezone.utc).isoformat(),'read_only':True}); return result


# ---------------- v41–v45: hardware adapters, historical intelligence, calibration, multi-farm AI core ----------------
@app.post('/api/v1/farms/{farm_id}/hardware/adapters')
def hardware_adapter_register(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    return {'version':'41.0','adapter':register_adapter(db,farm_id,p),'read_only':True,'control_commands_sent':False}

@app.get('/api/v1/farms/{farm_id}/hardware/adapters')
def hardware_adapter_list(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'41.0','farm_id':farm_id,'adapters':list_adapters(db,farm_id),'read_only':True}

@app.post('/api/v1/hardware/adapters/{adapter_id}/state')
def hardware_adapter_state(adapter_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    existing=__import__('sqlalchemy').text('SELECT farm_id FROM hardware_adapters WHERE id=:id')
    hit=db.execute(existing,{'id':adapter_id}).first()
    if not hit: raise HTTPException(404,'Adapter not found')
    ensure_farm(db,int(hit[0]),user)
    row=ingest_adapter_state(db,adapter_id,p)
    return {'version':'41.0','accepted':True,'adapter':row,'read_only':True}

@app.get('/api/v1/farms/{farm_id}/hardware/health')
def hardware_health(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'41.0','farm_id':farm_id,'adapters':adapter_health(db,farm_id),'read_only':True}

@app.get('/api/v1/farms/{farm_id}/intelligence/history')
def intelligence_history(farm_id:int,limit:int=100,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); ensure_learning_table(db)
    rows=db.execute(__import__('sqlalchemy').text('SELECT timestamp,model,predicted_value_eur_kwh,realized_value_eur_kwh,error_pct,sample_type,confidence_pct,notes FROM optimization_learning WHERE farm_id=:f ORDER BY timestamp DESC LIMIT :n'),{'f':farm_id,'n':min(limit,500)}).mappings().all()
    return {'version':'42.0','farm_id':farm_id,'rows':[dict(r) for r in rows]}

@app.post('/api/v1/farms/{farm_id}/ml/calibration')
def ml_calibration_sample(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user)
    source=p.get('source','optimizer'); predicted=float(p.get('predicted_value_eur_kwh') or 0); realized=float(p.get('realized_value_eur_kwh') or 0)
    return {'version':'43.0','farm_id':farm_id,'source':source,'calibration':add_sample(db,farm_id,source,predicted,realized,float(p.get('weight') or 1)),'read_only':True}

@app.get('/api/v1/farms/{farm_id}/ml/calibration')
def ml_calibration_get(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'43.0','farm_id':farm_id,'calibration':calibration(db,farm_id)}

@app.get('/api/v1/farms/{farm_id}/ml/calibrated-value')
def ml_calibrated_value(farm_id:int,source:str,value:float,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'43.0','farm_id':farm_id,'source':source,**calibrate_value(db,farm_id,source,value)}

@app.get('/api/v1/intelligence/fleet')
def intelligence_fleet(user=Depends(auth),db:Session=Depends(get_db)):
    farms=fleet_snapshot(db); decisions=[]
    for f in farms:
        try:
            # Lightweight fleet view: current energy price plus calibrated baseline; no external writes.
            val=calibrate_value(db,f['farm_id'],'optimizer',max(0,1-float(f.get('electricity_price_eur_kwh') or 0)))
            decisions.append({'farm_id':f['farm_id'],'decision':'OBSERVE','value_eur_kwh':val['calibrated_value_eur_kwh']})
        except Exception:
            decisions.append({'farm_id':f['farm_id'],'decision':'NO_DATA','value_eur_kwh':None})
    return {'version':'44.0','farms':farms,'aggregate':aggregate_decisions(decisions),'decisions':decisions,'read_only':True}

@app.get('/api/v1/farms/{farm_id}/ai/core')
async def ai_core_endpoint(farm_id:int,hours:int=24,risk_discount:float=.15,min_spread:float=.01,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    plan=await _live_optimizer_payload(farm_id,hours,risk_discount,db)
    row=plan['rows'][0] if plan.get('rows') else {}
    energy=float(row.get('grid_price_eur_kwh') or 0)
    candidates=[]
    for source,key in [('BTC_MINING','mining_value_eur_kwh'),('AI_COMPUTE','compute_value_eur_kwh')]:
        candidates.append({'source':source,**score_asset(row.get(key),energy,100,100,risk_discount)})
    decision=decide(candidates,float(row.get('confidence_pct') or 50),min_spread)
    learn=learning_summary(db,farm_id)
    dq={'score':float(row.get('confidence_pct') or 50)}
    result=ai_core(decision,learn,dq,calibration(db,farm_id))
    result.update({'farm_id':farm_id,'economic_candidates':candidates,'read_only':True})
    return result

@app.get('/api/v1/farms/{farm_id}/ai/core/explain')
async def ai_core_explain(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); learn=learning_summary(db,farm_id)
    return {'version':'45.0','farm_id':farm_id,'factors':{'economics':'risk-adjusted €/kWh','data_quality':'confidence and freshness','learning':'historical prediction error','safety':'approval required; no control commands'},'learning':learn,'read_only':True}

# ---------------- v36–v40: energy telemetry, battery intelligence, learning, profitability, AI decision ----------------


# ---------------- v46–v50: protocols, time-series, backtesting, model selection, autonomous planning ----------------
@app.post('/api/v1/farms/{farm_id}/devices/protocols')
def protocol_register(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'version':'46.0','protocol':register_protocol(db,farm_id,p),'read_only':True}
@app.get('/api/v1/farms/{farm_id}/devices/protocols')
def protocol_list(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'46.0','farm_id':farm_id,'protocols':list_protocols(db,farm_id),'read_only':True}
@app.get('/api/v1/farms/{farm_id}/devices/health')
def protocol_status(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'46.0','farm_id':farm_id,'devices':protocol_health(db,farm_id),'read_only':True}
@app.post('/api/v1/devices/protocols/{protocol_id}/probe')
def protocol_probe(protocol_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    from sqlalchemy import text
    r=db.execute(text('SELECT farm_id,protocol,endpoint,enabled FROM device_protocols WHERE id=:i'),{'i':protocol_id}).mappings().first()
    if not r: raise HTTPException(404,'Protocol not found')
    ensure_farm(db,int(r['farm_id']),user)
    if not r['enabled']: raise HTTPException(400,'Protocol disabled')
    if r['protocol']!='rest': raise HTTPException(400,'Only read-only REST probing is enabled in v46')
    try: data=probe_rest(r['endpoint']); return {'version':'46.0','ok':True,'data':data,'read_only':True}
    except Exception as e: raise HTTPException(502,f'Device probe failed: {e}')

@app.post('/api/v1/farms/{farm_id}/timeseries')
def ts_write(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'version':'47.0',**write_point(db,farm_id,p.get('metric','value'),float(p.get('value') or 0),p.get('unit'),p.get('source','manual'),float(p.get('quality',1)),metadata=p.get('metadata'))}
@app.get('/api/v1/farms/{farm_id}/timeseries/intelligence')
def ts_read(farm_id:int,metric:str|None=None,limit:int=500,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'47.0','farm_id':farm_id,'points':query_points(db,farm_id,metric,limit),'read_only':True}

@app.post('/api/v1/farms/{farm_id}/backtest')
def backtest_endpoint(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); rows=p.get('rows') or []; return {'version':'48.0','farm_id':farm_id,**run_backtest(rows,p.get('model','value_rank'),float(p.get('transaction_cost',0))),'read_only':True}
@app.get('/api/v1/farms/{farm_id}/model-selection')
def model_selection_endpoint(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); ensure_learning_table(db)
    rows=[dict(x) for x in db.execute(__import__('sqlalchemy').text('SELECT predicted_value_eur_kwh AS btc_value_eur_kwh, realized_value_eur_kwh AS realized_value_eur_kwh FROM optimization_learning WHERE farm_id=:f ORDER BY timestamp DESC LIMIT 500'),{'f':farm_id}).mappings().all()]
    return {'version':'49.0','farm_id':farm_id,**select_model(rows),'read_only':True}
@app.get('/api/v1/farms/{farm_id}/confidence')
def confidence_endpoint(farm_id:int,score:float=70,quality:float=80,error_pct:float=10,spread:float=.05,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'49.0','farm_id':farm_id,'confidence_pct':confidence(score,quality,error_pct,spread),'inputs':{'score':score,'quality':quality,'error_pct':error_pct,'spread':spread},'read_only':True}

@app.get('/api/v1/farms/{farm_id}/autonomous-planner')
async def autonomous_planner_endpoint(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    plan=await _live_optimizer_payload(farm_id,24,.15,db); row=plan['rows'][0] if plan.get('rows') else {}
    spread=abs(float(row.get('mining_value_eur_kwh') or 0)-float(row.get('compute_value_eur_kwh') or 0))
    conf=confidence(float(row.get('confidence_pct') or 50),float(row.get('confidence_pct') or 50),0,spread)
    decision=row.get('decision') or 'HOLD'
    return build_plan(decision,conf,{'min_confidence':70,'max_power_kw':row.get('grid_import_kw')})


# ---------------- v51–v55: hardware protocols, production time-series, portfolio routing & safety ----------------
@app.post('/api/v1/farms/{farm_id}/devices/protocols-v51')
def protocol_v51_register(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'version':'51.0','protocol':register_v51_protocol(db,farm_id,p),'read_only':True,'control_commands_sent':False}

@app.get('/api/v1/farms/{farm_id}/devices/protocols-v51')
def protocol_v51_list(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'51.0','farm_id':farm_id,'protocols':list_v51_protocols(db,farm_id),'read_only':True}

@app.post('/api/v1/devices/protocols-v51/{protocol_id}/probe')
def protocol_v51_probe(protocol_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_hardware_protocol_v51(db)
    from sqlalchemy import text
    r=db.execute(text('SELECT farm_id FROM device_protocol_v51 WHERE id=:i'),{'i':protocol_id}).first()
    if not r: raise HTTPException(404,'Protocol not found')
    ensure_farm(db,int(r[0]),user)
    try: return {'version':'51.0','ok':True,**probe_v51_protocol(db,protocol_id),'read_only':True}
    except Exception as e: raise HTTPException(502,f'Device protocol probe failed: {e}')

@app.post('/api/v1/farms/{farm_id}/timeseries-v52')
def ts_v52_write(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    require_write(db,farm_id,user); ensure_farm(db,farm_id,user); return {'version':'52.0','farm_id':farm_id,**write_ts_v52(db,farm_id,p.get('metric','value'),float(p.get('value') or 0),p.get('unit'),p.get('source','device'),float(p.get('quality',1)),p.get('metadata'))}

@app.get('/api/v1/farms/{farm_id}/timeseries-v52')
def ts_v52_read(farm_id:int,metric:str|None=None,limit:int=1000,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'52.0','farm_id':farm_id,'points':read_ts_v52(db,farm_id,metric,limit),'storage':'sql-time-series','read_only':True}

@app.post('/api/v1/farms/{farm_id}/backtest-v53')
def backtest_v53(farm_id:int,p:dict,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'53.0','farm_id':farm_id,**run_backtest_v53(p.get('rows') or [],p.get('strategies'),float(p.get('transaction_cost') or 0)),'read_only':True}

@app.get('/api/v1/intelligence/portfolio-routing')
def portfolio_routing(power_budget_kw:float|None=None,user=Depends(auth),db:Session=Depends(get_db)):
    farms=fleet_snapshot(db); candidates=[]
    for f in farms:
        price=float(f.get('electricity_price_eur_kwh') or 0); expected=max(0,1-price)
        candidates.append({'farm_id':f['farm_id'],'action':'OBSERVE','expected_value_eur_kwh':expected,'confidence_pct':50,'available_power_kw':f.get('total_power_kw') or 0})
    return {'version':'54.0',**route_farms(candidates,power_budget_kw),'farms':candidates,'read_only':True}

@app.get('/api/v1/farms/{farm_id}/safety')
def safety_status(farm_id:int,confidence_pct:float=50,power_kw:float=0,max_power_kw:float=100,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user); return {'version':'54.0',**evaluate_safety(db,farm_id,confidence_pct,power_kw=power_kw,max_power_kw=max_power_kw)}

@app.get('/api/v1/farms/{farm_id}/autonomous-planner-v55')
async def autonomous_planner_v55(farm_id:int,user=Depends(auth),db:Session=Depends(get_db)):
    ensure_farm(db,farm_id,user)
    plan=await _live_optimizer_payload(farm_id,24,.15,db); row=plan['rows'][0] if plan.get('rows') else {}
    btc=float(row.get('mining_value_eur_kwh') or 0); ai=float(row.get('compute_value_eur_kwh') or 0); conf=float(row.get('confidence_pct') or 50)
    candidates=[{'action':'BTC_MINING','expected_value_eur_kwh':btc,'confidence_pct':conf},{'action':'AI_COMPUTE','expected_value_eur_kwh':ai,'confidence_pct':conf}]
    safety=evaluate_safety(db,farm_id,conf,power_kw=float(row.get('grid_import_kw') or 0),max_power_kw=100000)
    return {'version':'55.0','farm_id':farm_id,**autonomous_plan(candidates,safety),'read_only':True}


@app.get("/api/v1/farms/{farm_id}/safety/limits")
def safety_limits(farm_id: str):
    return get_limits(getattr(app.state, "db", None) or __import__("sqlite3").connect(":memory:"), farm_id)

@app.post("/api/v1/farms/{farm_id}/safety/proposals")
def safety_proposal(farm_id: str, proposal: dict):
    import sqlite3
    db=sqlite3.connect(":memory:")
    return create_action(db,farm_id,proposal)

@app.post("/api/v1/farms/{farm_id}/safety/kill-switch")
def safety_kill_switch(farm_id: str, body: dict):
    import sqlite3
    db=sqlite3.connect(":memory:")
    return kill_switch(db,farm_id,bool(body.get("enabled",True)))

@app.get("/api/v1/hardware/adapters")
def hardware_adapters():
    return {"adapters":list_adapters(),"read_only":True}

@app.post("/api/v1/hardware/rest-probe")
def hardware_rest_probe(body: dict):
    return rest_probe(body.get("url",""))

@app.post("/api/v1/hardware/modbus-map")
def hardware_modbus_map(body: dict):
    return modbus_register_map(int(body.get("unit_id",1)),body.get("registers",[]))

@app.post("/api/v1/farms/{farm_id}/digital-twin/scenario")
def digital_twin_scenario(farm_id: str, body: dict):
    return run_scenario(body.get("initial_state",{}),body.get("decisions",[]))

@app.post("/api/v1/farms/{farm_id}/optimizer/autonomous-proposal")
def autonomous_optimizer(farm_id: str, body: dict):
    return autonomous_proposal(body.get("options",[]),float(body.get("min_confidence",0.70)))

@app.post("/api/v1/network/aggregate")
def network_aggregate(body: dict):
    return aggregate_snapshots(body.get("snapshots",[]))


@app.get("/api/v1/hardware/device-profiles")
def device_profiles():
    return {"profiles":list_profiles(),"read_only":True}

@app.get("/api/v1/hardware/device-profiles/{vendor}")
def device_profile(vendor: str, model: str | None = None):
    p=find_profile(vendor,model)
    return {"profile":p,"found":p is not None,"read_only":True}

@app.post("/api/v1/farms/{farm_id}/pilot/ingest")
def pilot_ingest(farm_id: str, body: dict):
    import sqlite3
    db=sqlite3.connect(":memory:")
    sample=derive_power_balance(normalize_payload(body.get("payload",{}),body.get("source","unknown")))
    store_sample(db,farm_id,sample)
    return {"accepted":True,"sample":sample,"storage_note":"demo DB; connect persistent DB for production"}

@app.post("/api/v1/pilot/calibration")
def pilot_calibration(body: dict):
    result=compare_prediction_to_actual(body.get("predicted",{}),body.get("actual",{}))
    result["calibration_factor"]=calibration_factor(result["mae"])
    return result

@app.post("/api/v1/pilot/readiness")
def pilot_readiness(body: dict):
    return readiness(body.get("samples",[]),int(body.get("min_samples",50)))

@app.post("/api/v1/portfolio/allocate")
def portfolio_allocate(body: dict):
    return allocate_farm_capacity(body.get("farms",[]),body.get("total_limit_kw"))



@app.post("/api/v1/scenarios/grid")
def scenario_grid(body: dict):
    return run_scenarios(body.get("base",{}),body.get("overrides",[]))

@app.post("/api/v1/models/register")
def models_register(body: dict):
    return register_model(body.get("name","model"),body.get("version","1.0"),body.get("metrics",{}))

@app.get("/api/v1/models")
def models_list():
    return {"models":list_models(),"best":select_best()}

@app.post("/api/v1/confidence/evaluate")
def confidence_evaluate(body: dict):
    c=confidence(body.get("data_quality",0),body.get("historical_accuracy",0),
                 body.get("market_stability",0),body.get("safety_margin",1))
    return gate(c,float(body.get("minimum",0.70)))

@app.post("/api/v1/pilot/report")
def pilot_report(body: dict):
    return build_report(body.get("samples",[]),body.get("decisions",[]))

@app.post("/api/v1/network/learning")
def network_learning(body: dict):
    return aggregate_learning(body.get("farms",[]))


@app.get("/api/v1/platform/status")
def platform():
    return platform_status()

@app.get("/api/v1/platform/flags")
def platform_flags():
    return get_flags()

@app.post("/api/v1/platform/flags")
def platform_flags_update(body: dict):
    return set_flags(body)

@app.post("/api/v1/data/validate-energy")
def validate_energy_api(body: dict):
    return validate_energy(body)

@app.post("/api/v1/economics/normalize")
def economics_normalize(body: dict):
    return {"value_eur_kwh":normalize(body.get("value",0),body.get("unit","eur_kwh"))}

@app.post("/api/v1/economics/net-value")
def economics_net(body: dict):
    return {"net_value_eur_kwh":net_value(body.get("gross",0),body.get("energy_cost",0),body.get("variable_cost",0),body.get("risk_discount",0))}

@app.post("/api/v1/constraints/check")
def constraints_check(body: dict):
    return check(body.get("constraints",{}),body.get("state",{}))

@app.post("/api/v1/decision/explain")
def decision_explain(body: dict):
    return explain(body.get("decision","HOLD"),body.get("ranked_options",[]))

@app.post("/api/v1/audit/event")
def audit_event(body: dict):
    return record(body.get("event_type","UNKNOWN"),body.get("actor","system"),body.get("payload",{}))

@app.get("/api/v1/audit/events")
def audit_events(limit: int=100):
    return {"events":list_events(limit)}

@app.get("/api/v1/system/health")
def system_health(body: dict=None):
    return system_health_score((body or {}).get("components",[]))

@app.get("/api/v1/system/compatibility")
def system_compat(client_version: str="v1"):
    return compatibility(client_version)

@app.post("/api/v1/system/observe")
def system_observe(body: dict):
    return observe(body.get("name","metric"),body.get("value",0))

@app.get("/api/v1/system/observability")
def system_observability():
    return snapshot()

@app.post("/api/v1/system/rate-limit")
def system_rate(body: dict):
    return allow(body.get("key","default"),int(body.get("limit",60)),int(body.get("window",60)))

@app.post("/api/v1/system/idempotency")
def system_idempotency(body: dict):
    return once(body.get("key",""),body.get("result",{}))

@app.post("/api/v1/system/sanitize-config")
def system_sanitize(body: dict):
    return sanitize_config(body)

@app.post("/api/v1/network/anonymize")
def network_anonymize(body: dict):
    return anonymize(body)

@app.post("/api/v1/system/deployment-readiness")
def deployment_readiness(body: dict):
    return assess(body.get("checks",[]))



# SYNPORA 1.0 product endpoints (v91-v100)
@app.get('/api/v1/saas/status')
def saas_status():
    return {**db_status(), 'tables': table_names()}

@app.get('/api/v1/demo/farm')
def demo_farm():
    return demo_snapshot()

@app.post('/api/v1/demo/seed')
def demo_seed():
    return {'ok': True, 'message': 'Demo mode is deterministic and requires no hardware.', 'farm': demo_snapshot()}

@app.get('/api/v1/connectors')
def connector_catalog():
    return {'connectors': connectors(), 'write_enabled': False}

@app.get('/api/v1/market/center')
def market_center():
    return market_snapshot()

@app.post('/api/v1/value-per-kwh')
def value_per_kwh_v1(body: dict):
    return rank_value(energy_price=float(body.get('energy_price',.11)), btc_value=float(body.get('btc_value',.118)), ai_value=float(body.get('ai_value',.142)), battery_value=float(body.get('battery_value',.094)), grid_value=float(body.get('grid_value',.071)))

@app.post('/api/v1/decision-center')
def decision_center(body: dict):
    return value_decision(body)

@app.post('/api/v1/simulation/what-if')
def simulation_what_if(body: dict):
    return simulate_24h(energy_price=float(body.get('energy_price',.11)), btc_value=float(body.get('btc_value',.118)), ai_value=float(body.get('ai_value',.142)), pv_kw=float(body.get('pv_kw',0)), battery_soc_pct=float(body.get('battery_soc_pct',50)), utilization_pct=float(body.get('utilization_pct',85)))

@app.get('/api/v1/release')
def release_info():
    return release()

# Public web app: dashboard and API are served from the same origin.
_FRONTEND_DIR=Path(__file__).resolve().parents[2] / 'frontend'
if _FRONTEND_DIR.exists():
    app.mount('/', StaticFiles(directory=str(_FRONTEND_DIR), html=True), name='frontend')
