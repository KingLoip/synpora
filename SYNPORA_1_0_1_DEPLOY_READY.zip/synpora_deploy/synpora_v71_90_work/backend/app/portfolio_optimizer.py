def allocate_farm_capacity(farms, total_limit_kw=None):
    ranked=sorted(farms,key=lambda x: float(x.get("score",0)),reverse=True)
    remaining=float(total_limit_kw) if total_limit_kw is not None else sum(float(x.get("available_kw",0)) for x in ranked)
    out=[]
    for f in ranked:
        avail=max(0,float(f.get("available_kw",0)))
        take=min(avail,remaining)
        out.append({**f,"allocated_kw":take})
        remaining-=take
        if remaining<=0: break
    return {"allocations":out,"unallocated_kw":max(0,remaining)}
def optimize_portfolio(db, max_kw=None):
    return {'status':'recommendation_only','max_kw':max_kw,'allocations':[],'control_enabled':False}
def portfolio_snapshot(db): return {'allocations':[],'status':'recommendation_only'}
