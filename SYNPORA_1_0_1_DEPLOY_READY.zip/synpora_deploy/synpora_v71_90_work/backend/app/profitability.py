def score_asset(value_eur_kwh,energy_price,utilization=100,uptime=100,risk_discount=.15):
    gross=max(0,float(value_eur_kwh or 0)); util=max(0,min(100,float(utilization or 0)))/100; up=max(0,min(100,float(uptime or 0)))/100; net=gross*util*up-float(energy_price or 0); risk=max(0,min(.9,float(risk_discount or 0))); return {'gross_eur_kwh':gross,'net_eur_kwh':net,'risk_adjusted_eur_kwh':net*(1-risk),'break_even_energy_price_eur_kwh':gross*util*up}
def compare(candidates):
    rows=sorted(candidates,key=lambda x:float(x.get('risk_adjusted_eur_kwh') or -999),reverse=True); return {'ranking':rows,'best':rows[0] if rows else None,'spread_eur_kwh':float(rows[0].get('risk_adjusted_eur_kwh') or 0)-float(rows[1].get('risk_adjusted_eur_kwh') or 0) if len(rows)>1 else None}
