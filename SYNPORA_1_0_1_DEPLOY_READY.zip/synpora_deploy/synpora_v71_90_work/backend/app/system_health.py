def score(components):
    vals=[float(x.get("score",0)) for x in components if x.get("score") is not None]
    avg=sum(vals)/len(vals) if vals else 0
    status="HEALTHY" if avg>=0.85 else ("DEGRADED" if avg>=0.60 else "UNHEALTHY")
    return {"score":avg,"status":status,"components":components}
