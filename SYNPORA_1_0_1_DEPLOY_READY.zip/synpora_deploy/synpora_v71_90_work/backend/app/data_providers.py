import httpx
from datetime import datetime,timedelta,timezone
from .config import ENERGY_CHARTS_URL,ENTSOE_API_TOKEN,OPEN_METEO_URL,PV_SYSTEM_EFFICIENCY,SYNPORA_GLOBAL_PRICE_URL,SYNPORA_GLOBAL_PRICE_TOKEN,AWATTAR_ENABLED,AWATTAR_URL,AWATTAR_MARKUP_CT_KWH,AWATTAR_VAT

# ENTSO-E bidding-zone EICs. This covers a broad European footprint; non-European
# farms can still use their local tariff or a custom global price endpoint.
ENTSOE_ZONES={
    'AT':'10YAT-APG------L','DE-LU':'10Y1001A1001A82H','DE':'10Y1001A1001A82H','BE':'10YBE----------2','FR':'10YFR-RTE------C',
    'NL':'10YNL----------L','ES':'10YES-REE------0','PT':'10YPT-REN------W','IT-NORTH':'10YIT-GRTN-----B','IT-CENTRE-NORTH':'10YIT-GRTN-----B',
    'CH':'10YCH-SWISSGRIDZ','PL':'10YPL-AREA-----S','CZ':'10YCZ-CEPS-----N','SK':'10YSK-SEPS-----K','HU':'10YHU-MAVIR----U',
    'SI':'10YSI-ELES-----O','HR':'10YHR-HEP------M','RO':'10YRO-TEL------P','BG':'10YCA-BULGARIA-R','GR':'10YGR-HTSO-----Y','DK1':'10YDK-1--------W',
    'DK2':'10YDK-2--------M','SE1':'10YSE-1--------K','SE2':'10YSE-2--------M','SE3':'10YSE-3--------J','SE4':'10YSE-4--------E',
    'NO1':'10YNO-1--------2','NO2':'10YNO-2--------T','NO3':'10YNO-3--------J','NO4':'10YNO-4--------9','NO5':'10YNO-5--------V','FI':'10YFI-1--------U','EE':'10Y1001A1001A39I','LV':'10YLV-1001A00074','LT':'10YLT-1001A0008Q','IE':'10YIE-1001A00010','XI':'10Y1001A1001A59C'
}


async def fetch_awattar_prices(hours=48):
    if not AWATTAR_ENABLED:
        return []
    now=datetime.now(timezone.utc)
    end=now+timedelta(hours=hours)
    params={'start':int(now.timestamp()*1000),'end':int(end.timestamp()*1000)}
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.get(AWATTAR_URL,params=params); r.raise_for_status(); data=r.json()
    out=[]
    for x in data.get('data',[]):
        ts=datetime.fromtimestamp(x['start_timestamp']/1000,tz=timezone.utc)
        market_eur_kwh=float(x['marketprice'])/1000
        # Optional provider-specific markup/VAT. Keep 0 by default so raw EPEX is preserved.
        price=market_eur_kwh + AWATTAR_MARKUP_CT_KWH/100
        if AWATTAR_VAT:
            price*=1+AWATTAR_VAT
        out.append({'timestamp':ts,'grid_price_eur_kwh':price,'source':'awattar:AT','provider':'awattar','market_price_eur_kwh':market_eur_kwh})
    return out[:hours]

async def fetch_day_ahead_prices(zone='AT', hours=48):
    zone=(zone or '').upper()
    if SYNPORA_GLOBAL_PRICE_URL:
        headers={'Authorization':f'Bearer {SYNPORA_GLOBAL_PRICE_TOKEN}'} if SYNPORA_GLOBAL_PRICE_TOKEN else {}
        async with httpx.AsyncClient(timeout=15) as c:
            r=await c.get(SYNPORA_GLOBAL_PRICE_URL,params={'zone':zone,'hours':hours},headers=headers); r.raise_for_status(); data=r.json()
        rows=data.get('data',data if isinstance(data,list) else [])
        return [{'timestamp':datetime.fromisoformat(x['timestamp'].replace('Z','+00:00')).astimezone(timezone.utc),'grid_price_eur_kwh':float(x['price_eur_kwh']),'source':x.get('source','custom-global-price')} for x in rows[:hours]]
    if not ENTSOE_API_TOKEN or zone not in ENTSOE_ZONES:
        return []
    now=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
    params={'securityToken':ENTSOE_API_TOKEN,'documentType':'A44','in_Domain':ENTSOE_ZONES[zone],'out_Domain':ENTSOE_ZONES[zone],'contract_MarketAgreement.type':'A01','periodStart':now.strftime('%Y%m%d%H%M'),'periodEnd':(now+timedelta(hours=hours)).strftime('%Y%m%d%H%M')}
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.get('https://web-api.tp.entsoe.eu/api',params=params); r.raise_for_status(); xml=r.text
    import re
    ns=re.search(r'namespace="([^"]+)"',xml); nsuri=ns.group(1) if ns else ''
    import xml.etree.ElementTree as ET
    root=ET.fromstring(xml); out=[]
    for ts in root.iter():
        if not ts.tag.endswith('TimeSeries'): continue
        period=next((x for x in ts if x.tag.endswith('Period')),None)
        if period is None: continue
        start=next((x.text for x in period if x.tag.endswith('timeInterval')),None)
        # fallback: parse point positions against the document period start
        interval=period.find('.//{*}timeInterval')
        if interval is None: continue
        st=interval.find('{*}start').text
        dt=datetime.fromisoformat(st.replace('Z','+00:00')).astimezone(timezone.utc)
        resolution=(period.find('{*}resolution').text if period.find('{*}resolution') is not None else 'PT60M')
        step=timedelta(hours=1) if resolution=='PT60M' else timedelta(minutes=15)
        for point in period.findall('{*}Point'):
            pos=point.find('{*}position'); price=point.find('{*}price.amount')
            if pos is not None and price is not None:
                out.append({'timestamp':dt+step*(int(pos.text)-1),'grid_price_eur_kwh':float(price.text)/1000,'source':f'entsoe:{zone}'})
    out.sort(key=lambda x:x['timestamp']); return out[:hours]

async def provider_capabilities(zone=''):
    z=(zone or '').upper()
    return {
        'price': {
            'entsoe': z in ENTSOE_ZONES,
            'awattar': AWATTAR_ENABLED and z == 'AT',
            'custom_global': bool(SYNPORA_GLOBAL_PRICE_URL),
            'local_tariff': True,
        },
        'solar': {'open_meteo_global': True},
        'fx': {'frankfurter': True},
        'scope': 'global'
    }


async def fetch_pv_forecast(latitude, longitude, capacity_kw, tilt=35, azimuth=0, hours=168, timezone_name='UTC'):
    params={'latitude':latitude,'longitude':longitude,'hourly':'global_tilted_irradiance','tilt':tilt,'azimuth':azimuth,'forecast_hours':hours,'timezone':timezone_name}
    async with httpx.AsyncClient(timeout=20) as c:
        r=await c.get(OPEN_METEO_URL,params=params); r.raise_for_status(); data=r.json()
    times=data.get('hourly',{}).get('time',[]); gti=data.get('hourly',{}).get('global_tilted_irradiance',[])
    out=[]
    for t,v in zip(times,gti):
        dt=datetime.fromisoformat(t).replace(tzinfo=timezone.utc) if '+' not in t and 'Z' not in t else datetime.fromisoformat(t.replace('Z','+00:00')).astimezone(timezone.utc)
        pv=max(0,float(v or 0))/1000*capacity_kw*PV_SYSTEM_EFFICIENCY
        out.append({'timestamp':dt,'pv_kw':pv,'source':'open-meteo:global'})
    return out
