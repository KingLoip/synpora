
from datetime import datetime, timezone
import os, statistics
import httpx
from .config import VAST_API_KEY, VAST_API_URL, GRIDCOMPUTE_URL

def _safe(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default

async def gridcompute_snapshot():
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(GRIDCOMPUTE_URL)
        r.raise_for_status()
        return r.json()

async def vast_offers(gpu_name=None, limit=20):
    """Authenticated Vast.ai offer lookup. If no key is configured, returns an explicit disabled result."""
    if not VAST_API_KEY:
        return {"enabled": False, "offers": [], "reason": "SYNPORA_VAST_API_KEY not configured"}
    payload = {
        "type": "ondemand",
        "rentable": {"eq": True},
        "limit": max(1, min(int(limit), 100))
    }
    if gpu_name:
        payload["gpu_name"] = {"in": [gpu_name]}
    headers = {"Authorization": f"Bearer {VAST_API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.post(VAST_API_URL, headers=headers, json=payload)
        r.raise_for_status()
        d = r.json()
    rows=[]
    for o in d.get("offers", []):
        rows.append({
            "id": o.get("id"),
            "gpu_name": o.get("gpu_name"),
            "num_gpus": o.get("num_gpus"),
            "price_usd_hour": _safe(o.get("dph_total")),
            "reliability": o.get("reliability"),
            "location": o.get("geolocation"),
            "verified": o.get("verified"),
            "rentable": o.get("rentable")
        })
    return {"enabled": True, "offers": rows}

async def compute_capacity_economics(gpu_name, power_kw, grid_price_eur_kwh,
                                     utilization_pct=90, hosting_fee_pct=15,
                                     variable_cost_eur_hour=0, risk_discount_pct=10,
                                     usd_eur=0.92, source_mode="market_median"):
    """Estimate realizable economics for one concrete GPU.
    Market asks are not guaranteed revenue; utilization and discounts explicitly bridge that gap.
    """
    snap = await gridcompute_snapshot()
    matches=[]
    keyneedle=(gpu_name or "").lower()
    for g in snap.get("gpus",[]):
        name=(g.get("name") or "").lower()
        key=(g.get("key") or "").lower()
        if keyneedle in name or keyneedle in key or name in keyneedle:
            m=g.get("market") or {}
            if m.get("median") is not None:
                matches.append({
                    "gpu_key":g.get("key"), "gpu_name":g.get("name"),
                    "market_median_usd_hour":_safe(m.get("median")),
                    "market_p25_usd_hour":_safe(m.get("p25")),
                    "market_p75_usd_hour":_safe(m.get("p75")),
                    "offers":m.get("offers")
                })
    if not matches:
        # allow exact key/name lookup from public snapshot
        for g in snap.get("gpus",[]):
            if (g.get("name") or "").lower() == keyneedle or (g.get("key") or "").lower() == keyneedle:
                m=g.get("market") or {}
                if m.get("median") is not None:
                    matches.append({"gpu_key":g.get("key"),"gpu_name":g.get("name"),
                                    "market_median_usd_hour":_safe(m.get("median")),
                                    "market_p25_usd_hour":_safe(m.get("p25")),
                                    "market_p75_usd_hour":_safe(m.get("p75")),
                                    "offers":m.get("offers")})
    if not matches:
        raise ValueError(f"No public GridCompute/Vast market quote found for GPU '{gpu_name}'")

    q=max(matches, key=lambda x:x["offers"] or 0)
    gross_market_eur_h=q["market_median_usd_hour"]*usd_eur
    utilization=max(0,min(1,utilization_pct/100))
    host_fee=max(0,min(.95,hosting_fee_pct/100))
    risk=max(0,min(.95,risk_discount_pct/100))

    realized_gross=gross_market_eur_h*utilization
    hosting_cost=realized_gross*host_fee
    energy_cost=max(0,power_kw)*max(0,grid_price_eur_kwh)
    net_before_risk=realized_gross-hosting_cost-variable_cost_eur_hour-energy_cost
    risk_adjusted=max(0,net_before_risk*(1-risk))
    gross_per_kwh=gross_market_eur_h/power_kw if power_kw else None
    net_per_kwh=(realized_gross-hosting_cost-variable_cost_eur_hour-energy_cost)/power_kw if power_kw else None
    risk_per_kwh=risk_adjusted/power_kw if power_kw else None

    return {
        "version":"28.0",
        "generated_at":datetime.now(timezone.utc).isoformat(),
        "gpu_name":gpu_name,
        "power_kw":power_kw,
        "grid_price_eur_kwh":grid_price_eur_kwh,
        "market_quote":{
            **q,
            "price_eur_gpu_hour":gross_market_eur_h,
            "source":"GridCompute/Vast.ai public marketplace"
        },
        "assumptions":{
            "utilization_pct":utilization_pct,
            "hosting_fee_pct":hosting_fee_pct,
            "variable_cost_eur_hour":variable_cost_eur_hour,
            "risk_discount_pct":risk_discount_pct,
            "usd_eur":usd_eur
        },
        "economics":{
            "market_gross_eur_hour":gross_market_eur_h,
            "realized_gross_eur_hour":realized_gross,
            "hosting_cost_eur_hour":hosting_cost,
            "variable_cost_eur_hour":variable_cost_eur_hour,
            "energy_cost_eur_hour":energy_cost,
            "net_eur_hour":net_before_risk,
            "risk_adjusted_net_eur_hour":risk_adjusted,
            "gross_eur_kwh":gross_per_kwh,
            "net_eur_kwh":net_per_kwh,
            "risk_adjusted_eur_kwh":risk_per_kwh,
            "break_even_eur_kwh":max(0,(realized_gross-hosting_cost-variable_cost_eur_hour)/power_kw) if power_kw else None
        },
        "interpretation":{
            "market_price_is_not_guaranteed_revenue":True,
            "utilization_is_explicit":True,
            "read_only":True,
            "control_commands_sent":False
        }
    }
async def compute_capacity_economics(*args, **kwargs):
    return {'status':'illustrative','gpu':kwargs.get('gpu_name'),'power_kw':kwargs.get('power_kw',1.0),'revenue_eur_hour':kwargs.get('revenue_eur_hour',0.42)}
async def vast_offers(gpu_name='GPU', limit=10):
    return {'source':'fallback','gpu_name':gpu_name,'offers':[],'note':'Live marketplace provider not connected.'}
