SEEN={}
def once(key, result):
    if key in SEEN: return {"duplicate":True,"result":SEEN[key]}
    SEEN[key]=result
    return {"duplicate":False,"result":result}
