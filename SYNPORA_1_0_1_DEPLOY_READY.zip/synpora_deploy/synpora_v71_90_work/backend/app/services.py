from dataclasses import dataclass
import httpx
MEMPOOL="https://mempool.space/api"
@dataclass
class Decision:
 action:str;reason:str;btc_day:float;revenue_eur_day:float;electricity_eur_day:float;profit_eur_day:float;efficiency_j_th:float;break_even_eur_kwh:float;break_even_btc_eur:float;margin_pct:float
def mining_decision(hashrate_ths,power_w,btc_eur,network_eh,block_reward_btc,pool_fee_pct,uptime_pct,electricity_eur_kwh,opex_eur_day=0):
 share=hashrate_ths/(network_eh*1_000_000);btc=share*144*block_reward_btc*(1-pool_fee_pct/100)*(uptime_pct/100)
 revenue=btc*btc_eur;energy=power_w/1000*24*electricity_eur_kwh*(uptime_pct/100);profit=revenue-energy-opex_eur_day
 eff=power_w/hashrate_ths;be=max(0,(revenue-opex_eur_day)/(power_w/1000*24*(uptime_pct/100)));bebtc=(energy+opex_eur_day)/btc if btc>0 else float("inf");margin=profit/revenue*100 if revenue else -100
 if profit>0 and margin>=20:a,r="BETREIBEN","Positiver Tagesgewinn mit ausreichender Marge."
 elif profit>0:a,r="UNDERCLOCK_PRUEFEN","Positiver, aber dünner Puffer. Effizienz/Tarif prüfen."
 else:a,r="ABSCHALTEN","Unter den aktuellen Annahmen ist der Betrieb nicht profitabel."
 return Decision(a,r,btc,revenue,energy,profit,eff,be,bebtc,margin)
async def market_data():
 async with httpx.AsyncClient(timeout=10) as c:
  p=(await c.get(f"{MEMPOOL}/v1/prices")).json();h=(await c.get(f"{MEMPOOL}/v1/mining/hashrate/1d")).json();d=(await c.get(f"{MEMPOOL}/v1/mining/difficulty-adjustments")).json()
 return {"btc_usd":p.get("USD"),"btc_eur":p.get("EUR"),"network_hashrate_eh":(h.get("currentHashrate") or 0)/1e18,"difficulty":d[0].get("difficulty") if d else None}
