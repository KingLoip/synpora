from copy import deepcopy

def simulate_step(state, decision, hours=1):
    s=deepcopy(state)
    energy_price=float(s.get("energy_price_eur_kwh",0))
    pv_kw=float(s.get("pv_kw",0))
    battery_kwh=float(s.get("battery_kwh",0))
    soc=float(s.get("soc_pct",50))
    mining_kw=float(s.get("mining_kw",0))
    compute_kw=float(s.get("compute_kw",0))
    batt_power=float(s.get("battery_power_kw",5))
    if decision=="BTC_MINING": compute_kw=0
    elif decision=="AI_COMPUTE": mining_kw=0
    elif decision=="HOLD": mining_kw=compute_kw=0
    load=mining_kw+compute_kw
    net_grid=max(0,load-pv_kw)
    net_export=max(0,pv_kw-load)
    battery_change=0
    if pv_kw>load and soc<90:
        battery_change=min(batt_power,pv_kw-load,(100-soc)*battery_kwh/100)
        battery_kwh+=battery_change; soc+=100*battery_change/max(battery_kwh,0.001)
    elif pv_kw<load and soc>20:
        battery_change=-min(batt_power,load-pv_kw,battery_kwh)
        battery_kwh+=battery_change; soc+=100*battery_change/max(battery_kwh,0.001)
    return {"decision":decision,"grid_import_kw":net_grid,
            "grid_export_kw":net_export,"battery_kwh":battery_kwh,
            "soc_pct":max(0,min(100,soc)),
            "energy_cost_eur":net_grid*energy_price*hours}

def run_scenario(initial_state, decisions):
    rows=[]; state=initial_state
    for d in decisions:
        row=simulate_step(state,d)
        rows.append(row); state={**state,**row}
    return {"rows":rows,"total_energy_cost_eur":sum(r["energy_cost_eur"] for r in rows)}
def build_twin(db, farm):
    return {'farm_id':farm.id,'farm_name':farm.name,'mode':'digital_twin','assets':len(getattr(farm,'miners',[]) or []),'state':'simulated','control_enabled':False}
