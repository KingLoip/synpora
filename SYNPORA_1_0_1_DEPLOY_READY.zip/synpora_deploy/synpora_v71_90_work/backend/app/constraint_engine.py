def check(constraints, state):
    violations=[]
    for k,rule in constraints.items():
        if k not in state: continue
        x=float(state[k])
        if "min" in rule and x<float(rule["min"]): violations.append({"field":k,"type":"min","value":x,"limit":rule["min"]})
        if "max" in rule and x>float(rule["max"]): violations.append({"field":k,"type":"max","value":x,"limit":rule["max"]})
    return {"pass":not violations,"violations":violations}
