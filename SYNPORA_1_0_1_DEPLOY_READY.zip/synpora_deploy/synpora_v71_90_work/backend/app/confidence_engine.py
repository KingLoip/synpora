def confidence(data_quality, historical_accuracy, market_stability, safety_margin=1.0):
    vals=[float(data_quality),float(historical_accuracy),float(market_stability),float(safety_margin)]
    return max(0,min(1,sum(vals)/len(vals)))

def gate(conf, minimum=0.70):
    return {"confidence":conf,"pass":conf>=minimum,"minimum":minimum,
            "action_allowed":conf>=minimum}
