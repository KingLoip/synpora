from datetime import datetime, timezone, timedelta

def _f(v):
    try:return float(v or 0)
    except:return 0.0

def build_live_optimizer(hours, energy_slots, mining_values, compute_value, mining_cap_kw, compute_cap_kw, grid_limit_kw=0, pv_cap_kw=0, risk_aversion=.25):
    rows=[]; total=0
    for i in range(max(1,min(hours,168))):
        e=energy_slots[i] if i<len(energy_slots) else (energy_slots[-1] if energy_slots else {})
        grid=_f(e.get('grid_price_eur_kwh')); pv=_f(e.get('pv_kw')); conf=_f(e.get('confidence_pct') or 70)
        mv=max(0,_f(mining_values[i] if i<len(mining_values) else 0)); cv=max(0,_f(compute_value[i] if i<len(compute_value) else 0))
        # conservative value: confidence and risk haircut only affect comparison, not displayed gross values
        penalty=max(.05,min(.95,risk_aversion))
        mv_r=mv*(1-penalty*(1-conf/100)); cv_r=cv*(1-penalty*(1-conf/100))
        candidates=[('BTC_MINING',mv_r,mv,mining_cap_kw),('AI_COMPUTE',cv_r,cv,compute_cap_kw),('IDLE',-grid,0,0)]
        decision,score,gross,cap=max(candidates,key=lambda x:x[1])
        site_limit=max(0,grid_limit_kw)+max(0,pv_cap_kw,pv)
        load=min(cap,site_limit) if decision!='IDLE' and gross>grid else 0
        net=(gross-grid)*load
        downside=abs(gross-grid)*penalty
        total+=net
        rows.append({'timestamp':(datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)+timedelta(hours=i)).isoformat(),
          'decision':decision,'chosen_source':decision,'grid_price_eur_kwh':grid,'pv_kw':pv,'mining_value_eur_kwh':mv,
          'compute_value_eur_kwh':cv,'chosen_value_eur_kwh':gross if load else 0,'load_kw':load,
          'expected_net_margin_eur':net,'downside_eur_kwh':downside,'confidence_pct':conf,
          'reason':f'{decision} has the highest risk-adjusted value versus grid at this hour.' if load else 'No dispatch value exceeds the grid opportunity cost.',
          'approval_required':True,'control_commands_sent':False})
    return {'version':'34.0','generated_at':datetime.now(timezone.utc).isoformat(),'horizon_hours':len(rows),
      'total_expected_net_margin_eur':total,'rows':rows,'mode':'recommendation_only','approval_required':True,'control_commands_sent':False}
