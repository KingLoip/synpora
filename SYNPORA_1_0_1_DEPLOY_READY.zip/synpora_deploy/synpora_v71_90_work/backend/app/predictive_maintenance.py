from datetime import datetime, timezone, timedelta
from statistics import mean
from sqlalchemy.orm import Session
from .models import Miner, Telemetry

def maintenance_risk(db: Session, farm_id: int, lookback_hours: int = 24*30):
    since = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
    out=[]
    for m in db.query(Miner).filter(Miner.farm_id==farm_id).all():
        rows=db.query(Telemetry).filter(Telemetry.miner_id==m.id, Telemetry.timestamp>=since).order_by(Telemetry.timestamp).all()
        valid=[r for r in rows if r.hashrate_ths is not None]
        if not valid:
            out.append({'miner_id':m.id,'name':m.name,'risk_score':0,'risk_level':'UNKNOWN','samples':0,'signals':['insufficient_telemetry']}); continue
        first=valid[:max(1,len(valid)//4)]; last=valid[-max(1,len(valid)//4):]
        early=mean([r.hashrate_ths for r in first]); late=mean([r.hashrate_ths for r in last]); perf_drop=max(0,(early-late)/max(early,0.001)*100)
        temps=[r.temperature_c for r in valid if r.temperature_c is not None]; avg_temp=mean(temps) if temps else None; hot_pct=(sum(t>=38 for t in temps)/len(temps)*100) if temps else 0
        offline=sum(1 for r in rows if r.error_message); availability=len(valid)/max(1,len(rows))*100
        risk=min(100, perf_drop*2.2 + max(0,(avg_temp or 0)-32)*2 + hot_pct*.35 + max(0,95-availability)*1.2 + offline*.5)
        signals=[]
        if perf_drop>=5: signals.append('hashrate_decline')
        if hot_pct>=10: signals.append('thermal_stress')
        if availability<95: signals.append('availability')
        if offline: signals.append('connector_errors')
        level='LOW' if risk<25 else 'MEDIUM' if risk<50 else 'HIGH' if risk<75 else 'CRITICAL'
        out.append({'miner_id':m.id,'name':m.name,'risk_score':round(risk,1),'risk_level':level,'samples':len(valid),'availability_pct':round(availability,1),'hashrate_drop_pct':round(perf_drop,2),'avg_temp_c':round(avg_temp,2) if avg_temp else None,'hot_sample_pct':round(hot_pct,1),'signals':signals})
    return {'farm_id':farm_id,'lookback_hours':lookback_hours,'assets':out,'generated_at':datetime.now(timezone.utc).isoformat()}
