from statistics import mean

def run_backtest(rows,model='value_rank',transaction_cost=0):
    outcomes=[]
    for r in rows:
        btc=float(r.get('btc_value_eur_kwh') or 0); ai=float(r.get('ai_value_eur_kwh') or 0); actual=float(r.get('realized_value_eur_kwh') or max(btc,ai));
        pred=btc if model=='btc' else ai if model=='ai' else max(btc,ai)
        action='BTC_MINING' if model=='btc' else 'AI_COMPUTE' if model=='ai' else ('BTC_MINING' if btc>=ai else 'AI_COMPUTE')
        outcomes.append({'action':action,'predicted':pred,'realized':actual,'error':actual-pred,'net':actual-transaction_cost})
    return {'model':model,'samples':len(outcomes),'mean_predicted':mean([x['predicted'] for x in outcomes]) if outcomes else 0,'mean_realized':mean([x['realized'] for x in outcomes]) if outcomes else 0,'mean_error':mean([x['error'] for x in outcomes]) if outcomes else 0,'total_net':sum(x['net'] for x in outcomes),'rows':outcomes}
