from statistics import mean, pstdev
from datetime import datetime, timezone

def probabilistic_slots(rows):
    out=[]
    for r in rows:
        pv=float(r.get('pv_kw',0)); price=float(r.get('grid_price_eur_kwh',0))
        conf=float(r.get('confidence_pct') or 70)
        uncertainty=max(5.0,min(40.0,(100-conf)*0.55))
        out.append({**r,'pv_low_kw':round(pv*(1-uncertainty/100),3),'pv_high_kw':round(pv*(1+uncertainty/100),3),
                    'price_low_eur_kwh':round(price*(1-uncertainty/200),5),'price_high_eur_kwh':round(price*(1+uncertainty/200),5),
                    'forecast_confidence_pct':round(conf,1)})
    return out

def ensemble_summary(rows):
    if not rows: return {'confidence_pct':0,'pv_mean_kw':0,'pv_std_kw':0,'price_mean_eur_kwh':0,'price_std_eur_kwh':0}
    p=[float(r.get('pv_kw',0)) for r in rows]; e=[float(r.get('grid_price_eur_kwh',0)) for r in rows]
    c=[float(r.get('confidence_pct') or 70) for r in rows]
    return {'confidence_pct':round(mean(c),1),'pv_mean_kw':round(mean(p),3),'pv_std_kw':round(pstdev(p),3),'price_mean_eur_kwh':round(mean(e),5),'price_std_eur_kwh':round(pstdev(e),5)}
