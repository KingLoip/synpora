def readiness(samples, min_samples=50):
    n=len(samples)
    quality_good=sum(1 for s in samples if s.get("quality")=="GOOD")
    ratio=quality_good/max(n,1)
    ready=n>=min_samples and ratio>=0.90
    return {"ready":ready,"samples":n,"good_quality_ratio":ratio,
            "required_samples":min_samples,
            "requirements":{"minimum_samples":min_samples,"good_quality_ratio":0.90}}
