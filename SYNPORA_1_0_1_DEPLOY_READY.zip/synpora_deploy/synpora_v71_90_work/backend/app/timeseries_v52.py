from datetime import datetime, timezone
from sqlalchemy import text

def ensure(db):
    if db.bind.dialect.name=='postgresql':
        sql='''CREATE TABLE IF NOT EXISTS synpora_timeseries (id BIGSERIAL PRIMARY KEY,farm_id BIGINT NOT NULL,ts TIMESTAMPTZ NOT NULL,metric VARCHAR(100) NOT NULL,value DOUBLE PRECISION,unit VARCHAR(30),source VARCHAR(100),quality DOUBLE PRECISION,metadata_json TEXT)'''
    else:
        sql='''CREATE TABLE IF NOT EXISTS synpora_timeseries (id INTEGER PRIMARY KEY AUTOINCREMENT,farm_id INTEGER NOT NULL,ts DATETIME NOT NULL,metric VARCHAR(100) NOT NULL,value REAL,unit VARCHAR(30),source VARCHAR(100),quality REAL,metadata_json TEXT)'''
    db.execute(text(sql)); db.execute(text('CREATE INDEX IF NOT EXISTS idx_syn_ts_farm_metric_ts ON synpora_timeseries(farm_id,metric,ts)')); db.commit()

def write(db,farm_id,metric,value,unit=None,source='unknown',quality=1.0,metadata=None,ts=None):
    ensure(db); ts=ts or datetime.now(timezone.utc)
    r=db.execute(text('INSERT INTO synpora_timeseries(farm_id,ts,metric,value,unit,source,quality,metadata_json) VALUES(:f,:t,:m,:v,:u,:s,:q,:x)'),{'f':farm_id,'t':ts,'m':metric,'v':value,'u':unit,'s':source,'q':quality,'x':__import__('json').dumps(metadata or {})}); db.commit(); return {'id':r.lastrowid,'timestamp':ts.isoformat()}

def read(db,farm_id,metric=None,limit=1000):
    ensure(db); q='SELECT * FROM synpora_timeseries WHERE farm_id=:f'; p={'f':farm_id,'n':min(limit,10000)}
    if metric:q+=' AND metric=:m'; p['m']=metric
    q+=' ORDER BY ts DESC LIMIT :n'; return [dict(x) for x in db.execute(text(q),p).mappings().all()]
