
from datetime import datetime, timezone

def _q(v): 
    try:return float(v or 0)
    except:return 0.0

def build_dispatch_plan(hours, grid_prices, pv_forecast, mining_value_kwh,
                        compute_value_kwh, battery=None, grid_limit_kw=0,
                        mining_cap_kw=0, compute_cap_kw=0, risk_aversion=.25,
                        step_kw=1.0):
    battery=battery or {}
    soc_kwh=_q(battery.get("soc_kwh"))
    capacity_kwh=_q(battery.get("capacity_kwh"))
    min_soc_kwh=_q(battery.get("min_soc_kwh"))
    charge_kw=_q(battery.get("max_charge_kw"))
    discharge_kw=_q(battery.get("max_discharge_kw"))
    eta=max(.01,min(1,_q(battery.get("roundtrip_efficiency",.9))))
    rows=[]; total=0

    for i in range(max(1,min(hours,168))):
        gp=_q(grid_prices[i] if i<len(grid_prices) else grid_prices[-1] if grid_prices else 0)
        pv=_q(pv_forecast[i] if i<len(pv_forecast) else 0)
        mv=max(0,_q(mining_value_kwh[i] if i<len(mining_value_kwh) else 0))
        cv=max(0,_q(compute_value_kwh[i] if i<len(compute_value_kwh) else 0))
        # risk penalty makes uncertain compute less attractive than a similar mining value
        mv_r=mv*(1-risk_aversion)
        cv_r=cv*(1-risk_aversion)

        available_pv=max(0,pv)
        site_limit=max(0,grid_limit_kw)+available_pv
        mk=ck=0
        if max(mv_r,cv_r) > gp:
            if mv_r >= cv_r:
                mk=min(max(0,mining_cap_kw),site_limit)
                rem=max(0,site_limit-mk)
                ck=min(max(0,compute_cap_kw),rem)
            else:
                ck=min(max(0,compute_cap_kw),site_limit)
                rem=max(0,site_limit-ck)
                mk=min(max(0,mining_cap_kw),rem)

        used=mk+ck
        pv_to_load=min(available_pv,used)
        grid=max(0,used-pv_to_load)
        surplus=max(0,available_pv-used)
        batt_ch=min(charge_kw,surplus, max(0,(capacity_kwh-soc_kwh)/eta) if capacity_kwh else 0)
        batt_dis=0
        if used==0 and capacity_kwh and soc_kwh>min_soc_kwh and gp>0:
            batt_dis=min(discharge_kw,soc_kwh-min_soc_kwh)
        soc_kwh=max(min_soc_kwh,min(capacity_kwh or 1e12,soc_kwh+batt_ch*eta-batt_dis/eta))

        margin=(mv*mk+cv*ck)-gp*grid-gp*batt_ch+gp*batt_dis
        total+=margin
        rows.append({
            "timestamp":(datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)).isoformat(),
            "grid_price_eur_kwh":gp,"pv_kw":pv,"mining_kw":mk,"compute_kw":ck,
            "grid_import_kw":grid,"battery_charge_kw":batt_ch,"battery_discharge_kw":batt_dis,
            "battery_soc_kwh":soc_kwh,"curtail_kw":max(0,surplus-batt_ch),
            "mining_value_eur_kwh":mv,"compute_value_eur_kwh":cv,
            "expected_net_margin_eur":margin,
            "decision":"BTC_MINING" if mk and not ck else "AI_COMPUTE" if ck and not mk else "MIXED" if mk and ck else "IDLE",
            "approval_required":True,"control_commands_sent":False
        })
    return {"version":"30.0","generated_at":datetime.now(timezone.utc).isoformat(),
            "horizon_hours":len(rows),"total_expected_net_margin_eur":total,
            "rows":rows,"mode":"simulation_only","approval_required":True,"control_commands_sent":False}
