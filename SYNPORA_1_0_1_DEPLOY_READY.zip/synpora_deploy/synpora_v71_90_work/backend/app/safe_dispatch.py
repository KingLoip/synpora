from datetime import datetime, timezone

def build_safe_plan(prob):
    hourly=prob.get('hourly',[])
    rec=prob.get('recommendation','CONSERVATIVE_DISPATCH')
    confidence=float(prob.get('forecast_confidence_pct') or 0)
    # Human approval is mandatory; this module never sends control commands.
    plan=[]
    for x in hourly:
        if x.get('robust'):
            action='RUN_RECOMMENDED'
            gate='low-scenario-positive'
        elif (x.get('base_margin_eur') or 0)>0:
            action='RUN_WITH_REVIEW'
            gate='base-positive-only'
        else:
            action='HOLD_OR_STOP_RECOMMENDED'
            gate='negative-base-margin'
        plan.append({'timestamp':x['timestamp'],'action':action,'approval_required':True,'gate':gate,'base_margin_eur':x.get('base_margin_eur'),'low_margin_eur':x.get('low_margin_eur'),'assets':x.get('base_assets',[])})
    return {'generated_at':datetime.now(timezone.utc),'mode':'human_approval_read_only','recommendation':rec,'forecast_confidence_pct':confidence,'approval_required':True,'control_commands_sent':False,'risk_policy':{'minimum_confidence_pct':60,'low_scenario_hurdle':'non_negative_for_RUN_RECOMMENDED'},'hourly':plan}
