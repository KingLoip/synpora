def simulate_24h(energy_price=.11, btc_value=.118, ai_value=.142, pv_kw=0, battery_soc_pct=50, utilization_pct=85):
    base={'BTC Mining':btc_value,'AI Compute':ai_value,'Battery':max(.04,energy_price*.85),'Grid Export':max(.03,energy_price*.65)}
    adj_ai=base['AI Compute']*(utilization_pct/100)
    rows=[('AI Compute',adj_ai),('BTC Mining',base['BTC Mining']),('Battery',base['Battery']+pv_kw*.0002),('Grid Export',base['Grid Export'])]
    rows.sort(key=lambda x:x[1],reverse=True)
    return {'hours':24,'battery_soc_pct':battery_soc_pct,'pv_kw':pv_kw,'utilization_pct':utilization_pct,'ranked':[{'strategy':n,'value_eur_kwh':round(v,4)} for n,v in rows],'best_strategy':rows[0][0],'best_value_eur_kwh':round(rows[0][1],4),'delta_vs_btc_eur_kwh':round(rows[0][1]-base['BTC Mining'],4)}
