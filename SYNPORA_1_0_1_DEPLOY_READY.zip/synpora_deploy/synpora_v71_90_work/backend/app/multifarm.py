from sqlalchemy import text
from datetime import datetime, timezone

def fleet_snapshot(db):
    farms=db.execute(text('SELECT id,name,electricity_price_eur_kwh FROM farms ORDER BY id')).mappings().all()
    return [{'farm_id':r['id'],'name':r['name'],'electricity_price_eur_kwh':r['electricity_price_eur_kwh']} for r in farms]

def aggregate_decisions(decisions):
    counts={}; values=[]
    for d in decisions:
        src=d.get('decision') or 'NO_DATA'; counts[src]=counts.get(src,0)+1
        if d.get('value_eur_kwh') is not None: values.append(float(d['value_eur_kwh']))
    return {'farm_count':len(decisions),'decision_counts':counts,'best_value_eur_kwh':max(values) if values else None,'average_value_eur_kwh':sum(values)/len(values) if values else None}
