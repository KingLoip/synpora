from datetime import datetime, timezone
from sqlalchemy import text
from sqlalchemy.orm import Session


def ensure_revenue_table(db: Session):
    db.execute(text('''CREATE TABLE IF NOT EXISTS compute_revenue (
      id INTEGER PRIMARY KEY AUTOINCREMENT, asset_id INTEGER NOT NULL, timestamp DATETIME NOT NULL,
      workload VARCHAR(120), provider VARCHAR(80), booked_eur_hour FLOAT, realized_eur_hour FLOAT,
      utilization_pct FLOAT, uptime_pct FLOAT, energy_cost_eur_hour FLOAT, hosting_fee_eur_hour FLOAT,
      variable_cost_eur_hour FLOAT, gross_revenue_eur_hour FLOAT, net_revenue_eur_hour FLOAT,
      status VARCHAR(20) NOT NULL DEFAULT 'estimated', source VARCHAR(80)
    )'''))
    db.commit()


def record_revenue(db, asset_id, data):
    ensure_revenue_table(db)
    util=float(data.get('utilization_pct') or 0); uptime=float(data.get('uptime_pct') if data.get('uptime_pct') is not None else 100)
    booked=data.get('booked_eur_hour'); realized=data.get('realized_eur_hour')
    rate=float(realized if realized is not None else booked or 0)
    gross=rate*(util/100)*(uptime/100)
    hosting=float(data.get('hosting_fee_eur_hour') or 0); variable=float(data.get('variable_cost_eur_hour') or 0); energy=float(data.get('energy_cost_eur_hour') or 0)
    net=gross-hosting-variable-energy
    status='realized' if realized is not None else 'estimated'
    ts=data.get('timestamp') or datetime.now(timezone.utc).isoformat()
    db.execute(text('''INSERT INTO compute_revenue
      (asset_id,timestamp,workload,provider,booked_eur_hour,realized_eur_hour,utilization_pct,uptime_pct,energy_cost_eur_hour,hosting_fee_eur_hour,variable_cost_eur_hour,gross_revenue_eur_hour,net_revenue_eur_hour,status,source)
      VALUES (:asset_id,:timestamp,:workload,:provider,:booked,:realized,:util,:uptime,:energy,:hosting,:variable,:gross,:net,:status,:source)'''),
      {'asset_id':asset_id,'timestamp':ts,'workload':data.get('workload'),'provider':data.get('provider'),
       'booked':booked,'realized':realized,'util':util,'uptime':uptime,'energy':energy,'hosting':hosting,'variable':variable,
       'gross':gross,'net':net,'status':status,'source':data.get('source','api')})
    db.commit()
    return {'status':status,'gross_revenue_eur_hour':gross,'net_revenue_eur_hour':net}


def revenue_rows(db, asset_id=None, farm_id=None, limit=200):
    ensure_revenue_table(db); params={'limit':max(1,min(int(limit),1000))}
    if asset_id is not None: q='SELECT r.* FROM compute_revenue r WHERE r.asset_id=:id ORDER BY r.timestamp DESC LIMIT :limit'; params['id']=asset_id
    elif farm_id is not None: q='SELECT r.* FROM compute_revenue r JOIN compute_assets a ON a.id=r.asset_id WHERE a.farm_id=:id ORDER BY r.timestamp DESC LIMIT :limit'; params['id']=farm_id
    else: q='SELECT * FROM compute_revenue ORDER BY timestamp DESC LIMIT :limit'
    return [dict(x._mapping) for x in db.execute(text(q),params)]


def revenue_summary(db, farm_id):
    ensure_revenue_table(db)
    r=db.execute(text('''SELECT COUNT(*) n, SUM(gross_revenue_eur_hour) gross, SUM(net_revenue_eur_hour) net,
      AVG(utilization_pct) util, AVG(CASE WHEN status='realized' THEN realized_eur_hour END) realized_rate,
      AVG(CASE WHEN booked_eur_hour>0 AND realized_eur_hour IS NOT NULL THEN realized_eur_hour/booked_eur_hour END) realized_ratio
      FROM compute_revenue r JOIN compute_assets a ON a.id=r.asset_id WHERE a.farm_id=:id'''),{'id':farm_id}).first()
    return {'samples':int(r.n or 0),'gross_eur_hour_sum':float(r.gross or 0),'net_eur_hour_sum':float(r.net or 0),
            'avg_utilization_pct':float(r.util or 0),'avg_realized_rate_eur_hour':float(r.realized_rate or 0),
            'realized_vs_booked_ratio':float(r.realized_ratio or 0),'note':'Estimated rows use booked/market rate; realized rows use measured revenue.'}
