# SYNPORA Fullstack v2.7

## Start
python -m venv .venv
pip install -r requirements.txt
uvicorn app.main:app --reload

API docs: http://127.0.0.1:8000/docs

## Miner connector
The connector is READ-ONLY and uses a configurable CGMiner-compatible TCP endpoint (default 4028).
It can:
- test a miner
- poll summary/stats
- normalize hashrate/power/temp/fan
- save telemetry

It deliberately does NOT implement restart, pool changes, firmware changes, overclocking, or shutdown.

Not every firmware exposes identical fields. The adapter therefore treats some values as optional.

## Safety
Only connect to miners you own/administer. Do not expose port 4028 directly to the public internet. Put the backend on the same trusted LAN/VPN as the miners.

## v3.0 Alerts + Optimization
- `GET /api/v1/farms/{farm_id}/alerts?active=true`
- `POST /api/v1/alerts/{alert_id}/resolve`
- `GET /api/v1/farms/{farm_id}/health`
- `GET /api/v1/farms/{farm_id}/optimization`
- Automatic alert evaluation runs after the telemetry polling cycle.
- Rules: offline, stale telemetry, connector error, high/critical temperature, hashrate anomaly, power anomaly.
- Optimization is read-only and recommends RUN / UNDERCLOCK REVIEW / SHUTDOWN / EFFICIENCY REVIEW based on current farm tariff and market data.
