# v24 – Unified Value-per-kWh Optimizer
- Compares Bitcoin mining and AI compute on a common €/kWh basis.
- Separates grid cost from PV surplus opportunity cost.
- Risk-adjusted ranking.
- Read-only recommendation layer; no miner control commands.
