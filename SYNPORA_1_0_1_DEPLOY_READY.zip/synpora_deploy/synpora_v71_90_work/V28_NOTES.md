# SYNPORA v28 — Compute Capacity Economics

v28 turns public GPU market asks into an explicit realizable-revenue model.

## New endpoints
- GET `/api/v1/farms/{farm_id}/compute/capacity-economics`
- GET `/api/v1/compute/vast/offers`

## Model
Market median -> utilization -> hosting/marketplace fee -> variable costs -> electricity -> risk discount.

Important: marketplace asking prices are NOT guaranteed realized revenue.

## Optional Vast.ai integration
Set `SYNPORA_VAST_API_KEY` to enable authenticated live offer lookup. Without it, SYNPORA still uses the public GridCompute snapshot.

No automatic provisioning or control is performed.
