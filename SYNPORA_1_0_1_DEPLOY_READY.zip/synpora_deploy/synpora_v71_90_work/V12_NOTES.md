# SYNPORA v12.0

## Probabilistic Energy Optimizer
- Low/base/high scenarios over up to 168h
- Risk-adjusted objective with configurable risk_aversion
- Downside-risk metric
- Robust hourly dispatch flag
- Read-only: no miner control commands

## aWATTar
The existing AT provider remains supported. For production tariff accuracy, configure provider markup/VAT to match the customer's actual contract; aWATTar HOURLY currently describes EPEX Spot AT + 1.5 ct/kWh + 20% VAT, with network charges/levies billed separately.
