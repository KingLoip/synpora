# SYNPORA v13.0

Self-Learning Forecast Optimizer.

- provider-level forecast calibration
- learned bias correction after >=8 matched observations
- adaptive provider weights
- calibrated confidence and error dispersion
- forecast-learning API
- v12 probabilistic optimization retained
- read-only miner control retained
