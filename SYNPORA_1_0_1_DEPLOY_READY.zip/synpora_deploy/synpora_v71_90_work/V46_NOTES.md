# v46 Hardware Protocol Layer
Read-only REST device probing and protocol registry. Modbus is deliberately not enabled unless an optional driver is installed later.
