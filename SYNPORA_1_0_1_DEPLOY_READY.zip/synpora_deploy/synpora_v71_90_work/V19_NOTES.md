# v19 — Predictive Maintenance
Learns miner degradation signals from telemetry: hashrate decline, thermal stress, availability and connector errors. Produces maintenance risk, not automatic service actions.
