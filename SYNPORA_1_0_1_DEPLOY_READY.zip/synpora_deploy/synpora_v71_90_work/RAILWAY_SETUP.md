# SYNPORA 1.0 — Einfaches Online-Setup

## Du brauchst nur
1. GitHub-Konto
2. Railway-Konto
3. Domain `synpora.com`

## GitHub
Neues Repository `synpora` anlegen und den kompletten Inhalt dieses Ordners hochladen.

## Railway
1. New Project → Deploy from GitHub Repo → `synpora`
2. Add PostgreSQL
3. Beim Web-Service unter Variables setzen:

`SYNPORA_BOOTSTRAP_EMAIL` = deine E-Mail-Adresse
`SYNPORA_BOOTSTRAP_PASSWORD` = ein langes, eigenes Passwort
`SYNPORA_CORS_ORIGINS` = `*`

Die Datenbank-Variable `DATABASE_URL` wird von Railway automatisch bereitgestellt und von SYNPORA erkannt.

4. Deploy abwarten.
5. Unter Networking → Generate Domain öffnen.
6. Die URL im Browser öffnen.
7. Im Dashboard unten bei Account & Pilot Access einmal `Owner einmalig einrichten` wählen. E-Mail und Passwort müssen den Railway-Variablen entsprechen.
8. Danach `Anmelden`.

## Eigene Domain
Railway Service → Settings → Networking → Custom Domain → `synpora.com`.
Railway zeigt dir danach den DNS-Eintrag, den du beim Domainanbieter setzen musst.

## Wichtig
- Keine Passwörter/API-Keys in GitHub speichern.
- Hardware-Schreibzugriff bleibt deaktiviert.
- Demo-Farm ist ohne Hardware nutzbar.
