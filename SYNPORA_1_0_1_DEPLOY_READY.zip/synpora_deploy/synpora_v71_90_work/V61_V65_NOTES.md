# SYNPORA v61-v65

v61 Real hardware device profiles
v62 Pilot ingestion + normalized energy telemetry
v63 Pilot calibration against actual measurements
v64 Portfolio optimizer across farms
v65 Pilot readiness gate

All device interfaces remain read-only. Persistent production DB and actual device credentials are intentionally not hard-coded.
