# SYNPORA v18 — Safe Dispatch Plan
- Converts probabilistic optimization into an explicit hourly operating plan.
- Every action requires human approval.
- No miner control commands are sent.
- Includes downside gates and forecast-confidence context.
