# SYNPORA v8.0 – Forecast & Real Data Layer

## Neue Kernfunktionen
- Österreichische Day-Ahead-Preise über Energy-Charts (`AT`) als Standardquelle.
- Optionaler ENTSO-E-Konfigurationspfad ist vorbereitet; der XML-Adapter bleibt bewusst getrennt.
- Open-Meteo GTI-basierte PV-Prognose mit PV-Neigung/Azimut und Farm-Koordinaten.
- Automatischer Forecast-Refresh im Hintergrund.
- 24h bis 168h Dispatch-Simulation nutzt gespeicherte Forecast-Slots.
- Battery Reserve und forecast-aware Dispatch.
- Quellen werden je Slot gespeichert.
- Bei fehlenden externen Daten greift SYNPORA auf konservative Fallbacks zurück.

## Energieprofil
Über `PUT /api/v1/farms/{farm_id}/energy` können zusätzlich gesetzt werden:
- `latitude`, `longitude`
- `pv_tilt_deg`, `pv_azimuth_deg`
- `timezone`

## Manuell aktualisieren
`POST /api/v1/farms/{farm_id}/energy/forecast/refresh?hours=168`

## Hinweise
Day-Ahead-Daten sind Marktprognosen, keine Endkundenstromrechnung. Netzentgelte, Abgaben, Steuern, Lieferantenaufschläge und ggf. negative/variable Margen müssen im Farm-Tarifmodell separat berücksichtigt werden.
