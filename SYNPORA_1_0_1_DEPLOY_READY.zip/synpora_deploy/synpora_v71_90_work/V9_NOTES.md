# v9.0 — Global Forecasting

- Removed Austria-only forecast logic.
- Farm energy profile now stores country_code, market_zone, currency and timezone.
- PV forecast is worldwide by latitude/longitude. Open-Meteo supports global models and GTI.
- Price forecast: ENTSO-E where supported; optional custom global price endpoint; otherwise configured farm tariff is retained.
- Forecast horizon defaults to 168 hours.
- Added `/api/v1/farms/{farm_id}/energy/providers`.
- Read-only simulation remains unchanged.
