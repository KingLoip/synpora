Risk-aware dispatch engine for 24–168h. Uses PV/grid/battery placeholders and registered compute capacity. Simulation-only.
