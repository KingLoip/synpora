# v47 Time-Series Intelligence Store
Lightweight SQL time-series table for intelligence metrics, quality and provenance. Designed to migrate to Timescale/PostgreSQL later.
