# v21 — Scenario Lab
Adds what-if scenario analysis for power price and compute-demand changes across the farm portfolio. Results are decision-support proxies and must be calibrated with verified revenue models before production use.
