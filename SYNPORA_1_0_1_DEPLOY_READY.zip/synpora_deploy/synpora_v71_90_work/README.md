# SYNPORA FULLSTACK v10.0 — Global Energy OS

International forecasting and economic dispatch for Bitcoin mining, AI/GPU compute, PV and batteries.

## Global scope
- PV/weather forecasts use Open-Meteo and are location-based worldwide; GTI is supported with configurable panel tilt/azimuth.
- Day-ahead electricity prices use ENTSO-E for supported European bidding zones when an API token is configured.
- Outside supported zones, farms can use their local tariff or a custom global price API via `SYNPORA_GLOBAL_PRICE_URL`.
- All energy prices are normalized to EUR/kWh in the optimization layer; local-currency normalization can be added once an FX provider is configured.

## Safety
SYNPORA remains read-only toward miners. v9 is forecast/simulation only; it does not issue shutdown, pool-change, firmware or overclock commands.


## v13 Self-Learning
SYNPORA scores forecast providers against actual observations, learns provider bias/error dispersion, and exposes adaptive weights/confidence.

## v14.0
Learned time-aware forecast ensemble combining provider weights, bias calibration and same-hour performance.


## v29–v31
- v29 concrete GPU/ASIC asset registry
- v30 risk-aware portfolio dispatch
- v31 data provenance / quality scoring
