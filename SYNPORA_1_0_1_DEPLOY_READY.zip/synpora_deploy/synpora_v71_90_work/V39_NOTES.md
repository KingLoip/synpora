# SYNPORA v39 – Profitability Intelligence
- Added normalized profitability scoring for mining and AI compute.
- Calculates gross, net and risk-adjusted €/kWh plus break-even energy price.
- Compares candidates using the live optimizer inputs.
- Market asks remain explicitly non-guaranteed revenue.
