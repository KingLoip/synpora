# SYNPORA v38 – Learning Loop
- Added `learning_loop.py` and persistent optimization feedback table.
- Stores predicted vs realized €/kWh, model, confidence and error.
- Provides mean error, MAE and confidence summary.
- This creates the feedback channel required for future model calibration.
