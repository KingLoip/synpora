GPU/ASIC asset registry. Concrete hardware can now be registered and matched against market quotes.
