# SYNPORA v10.0 — Global Market Intelligence & Forecast Learning

v10 changes the energy intelligence layer from an Austria/EU-first design to a global provider architecture.

## New capabilities
- Global provider capability endpoint.
- ENTSO-E adapter where a supported European bidding zone and API token are available.
- Custom global electricity-price adapter for any external market/tariff provider.
- Local tariff fallback when no wholesale market feed is available.
- Global Open-Meteo solar forecast with GTI and 168-hour horizon.
- FX rates endpoint using Frankfurter for currency normalization.
- Forecast metadata: provider, currency, FX rate, confidence and forecast run ID.
- Energy observations API for actual price/PV values.
- Forecast-vs-actual accuracy scoring: MAE/MAPE, bias and score.
- Automatic forecast refresh now runs per farm (fixes the v9 worker's shared-profile bug).

## API additions
- GET `/api/v1/farms/{farm_id}/energy/market-capabilities`
- GET `/api/v1/fx/rates?base=EUR`
- POST `/api/v1/farms/{farm_id}/energy/observations`
- GET `/api/v1/farms/{farm_id}/energy/forecast-accuracy`
- POST `/api/v1/farms/{farm_id}/energy/forecast-accuracy/recalculate`

## Production notes
- Global electricity prices are never fabricated. If no provider exists for a location, SYNPORA uses the configured local tariff.
- ENTSO-E requires an API token for its platform API.
- For US/Australia/Asia/etc., configure `SYNPORA_GLOBAL_PRICE_URL` to a provider that returns hourly `price_eur_kwh` values, or use local tariffs until a market adapter is configured.
- Open-Meteo supports worldwide coordinates and global weather models; GTI is used for PV forecasting.
- Automatic control remains disabled: dispatch is simulation/recommendation only.
