# SYNPORA v40 – AI Decision Engine
- Added `ai_decision.py`.
- Chooses the highest risk-adjusted value only when confidence and economic spread are sufficient.
- Otherwise returns HOLD and requests more data.
- Every result is recommendation-only with `approval_required=true` and `control_commands_sent=false`.
