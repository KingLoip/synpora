# SYNPORA v36 – Energy Telemetry Layer
- Added `energy_assets.py` with smart-meter/inverter/battery reading ingestion.
- Stores grid import/export, PV, battery power/SOC, voltage, frequency, source and quality.
- Routes: `/energy/meter`, `/energy/live-state`.
- Read-only after ingestion; no device write/control.
- Designed so Modbus/HTTP/vendor adapters can feed the same normalized schema later.
