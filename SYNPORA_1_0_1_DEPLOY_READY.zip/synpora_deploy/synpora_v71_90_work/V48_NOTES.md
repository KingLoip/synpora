# v48 Backtesting
Historical rows can be replayed through BTC, AI and value-ranking strategies with explicit prediction error and transaction cost.
