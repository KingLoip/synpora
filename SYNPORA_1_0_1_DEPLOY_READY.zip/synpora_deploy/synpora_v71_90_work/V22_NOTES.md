# v22 – Bitcoin Mining Revenue & Hashprice Engine
- Real-time Mempool BTC/EUR + network hashrate input.
- Hashprice per TH/s/day and PH/s/day.
- Per-miner BTC/day, revenue/day, energy/day and gross value/kWh.
- Transaction fees explicitly excluded unless a verified fee feed is added.
