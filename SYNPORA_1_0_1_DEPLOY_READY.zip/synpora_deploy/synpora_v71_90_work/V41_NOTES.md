# SYNPORA v41 — Hardware Adapter Layer
Generic read-only adapter registry for smart meters, inverters, batteries and compute controllers. No outbound control commands.
