# SYNPORA v37 – Battery Intelligence
- Added `battery_optimizer.py`.
- Hourly charge/discharge recommendation based on forecast price, PV, SOC and reserve.
- Supports configurable capacity, charge/discharge limits and reserve.
- `approval_required=true`; no control commands are sent.
