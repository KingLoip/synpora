# v50 Autonomous Planner
Planner converts the AI recommendation into a safety-gated proposed action. Manual approval, minimum confidence and kill-switch remain mandatory. No hardware commands are sent.
