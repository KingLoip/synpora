# SYNPORA v41–v45

## v41 — Hardware Adapter Layer
Read-only registry/ingestion abstraction for smart meters, inverters, batteries, compute hosts and generic HTTP adapters. Adapter state can be ingested but SYNPORA does not send control commands.

## v42 — Historical Optimization Intelligence
Adds a queryable optimization history layer so predicted vs realized economics can be reviewed and reused by higher-level intelligence.

## v43 — ML Calibration
Adds transparent, bounded calibration factors from predicted vs realized €/kWh. Calibration is statistical and explainable; it is not autonomous model training.

## v44 — Multi-Farm Intelligence
Adds fleet snapshots and aggregate decision statistics for multiple farms. The fleet endpoint is deliberately read-only.

## v45 — SYNPORA AI Core
Combines risk-adjusted economics, data quality and historical model error into a conservative final recommendation. Confidence is reduced when historical error is high. Any control action remains approval-gated.

### Safety posture
- Read-only by default
- `approval_required=true`
- `control_commands_sent=false`
- No automatic inverter/battery/miner/GPU control introduced
- Calibration factors bounded to 0.5–1.5
