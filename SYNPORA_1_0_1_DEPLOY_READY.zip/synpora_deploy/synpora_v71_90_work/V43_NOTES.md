# SYNPORA v43 — ML Calibration
Prediction-vs-realized samples produce bounded calibration factors. This is a transparent statistical calibration layer, not autonomous model training.
