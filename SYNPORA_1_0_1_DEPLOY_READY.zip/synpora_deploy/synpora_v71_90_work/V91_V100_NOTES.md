# SYNPORA v91–v100 — SYNPORA 1.0

## Productization
- v91 persistent SQLAlchemy database/status layer
- v92 existing user/farm/membership/auth foundation exposed through SaaS flow
- v93 new professional Control Center frontend
- v94 deterministic Demo Farm — no hardware required
- v95 vendor-neutral Connector Center (read-only)
- v96 unified Market Center with explicit fallback/illustrative labeling
- v97 Value-per-kWh ranking
- v98 AI Decision Center with confidence/reasons and recommendation-only mode
- v99 What-if simulation lab
- v100 release manifest and pilot-ready product surface

## Core UX
Login → Farm → Assets → Live Data → Economics → AI Decision → Simulation → Reports

## Safety
`hardware_write=false` and `autonomous_control=false` remain enforced. No endpoint added in v91–v100 sends hardware commands.

## Demo
Open `frontend/index.html` through a static server/proxy configured to the API origin. The dashboard automatically loads the deterministic demo farm.
