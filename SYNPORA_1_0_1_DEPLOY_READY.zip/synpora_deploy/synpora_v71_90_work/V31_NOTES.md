Data provenance and quality scoring. Every market-derived decision can expose source, live flag, age and warning.
